
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import tkinter.font as tkfont
import csv, copy, re, os, sys, json, math
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, List, Optional, Set, Tuple

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except ImportError:
    DND_FILES = None
    TkinterDnD = None
    DND_AVAILABLE = False

# ---- 基本設定 ----
MAX_DEPTH = 10
APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
MODULE_DIR = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else APP_DIR
CONFIG_PATH = os.path.join(APP_DIR, "anbun_config.json")
SAMPLE_DIR = os.path.join(MODULE_DIR, "sample")
SAMPLE_TREE_CSV_PATH = os.path.join(SAMPLE_DIR, "構成CSV_サンプル.csv")
SAMPLE_MEASURE_CSV_PATH = os.path.join(SAMPLE_DIR, "実測値・按分比率CSV_サンプル.csv")
SAMPLE_BUDGET_CSV_PATH = os.path.join(SAMPLE_DIR, "予算単位CSV_サンプル.csv")
MAX_NODE_NAME_WIDTH = 520
MAX_MEASURE_NAME_WIDTH= 520
MAX_ASSIGN_NAME_WIDTH = 460
MAX_DETAIL2_WIDTH = 520
PADDING = 28
SAMPLE_ROWS_FOR_MEASURE = 2000
APP_NAME = 'あんぶんくん'
APP_SUBTITLE = '電力系統構造化・解析・配賦支援ツール'
# v1.8.0: 計測評価対象外・診断上の末端・解析結果サマリー・PDF・統合解析Excel。
APP_VERSION = "1.8.0"
APP_RELEASE_DATE = "2026-10-18"
APP_BUILD_NAME = "試用版"
APP_VERSION_LABEL = f"{APP_NAME} v{APP_VERSION}（{APP_BUILD_NAME}）"
DEVELOPER_COMPANY = "パナソニック ファシリティーズ株式会社"
DEVELOPER_NAME = "Inoue Akira（井上 昭）"
DEVELOPER_EMAIL = "inoue.akira002@jp.panasonic.com"
saved_node_name_width: Optional[int] = None
saved_measure_name_width: Optional[int] = None
saved_assign_name_width: Optional[int] = None
saved_detail2_width: Optional[int] = None
MGMT_CFG_DEFAULTS = {
    "parent_child_difference_threshold_kwh": 10.0,
    "over_power_threshold_percent_of_max": 40.0,
    "negative_anbun_threshold_kwh": -0.1,
    "measurement_candidate_threshold_kwh": 1000.0,
    "measurement_group_threshold_kwh": 3000.0,
    "estimation_accumulation_candidate_threshold": 1.0,
    "estimation_accumulation_reference_kwh": 1000.0,
    "measurement_boundary_threshold_kwh": 2000.0,
}
MGMT_CFG_LABELS = {
    "parent_child_difference_threshold_kwh": "親子差分しきい値(kWh)",
    "over_power_threshold_percent_of_max": "過大電力しきい値(理論最大比率%)",
    "negative_anbun_threshold_kwh": "負按分しきい値(kWh)",
    "measurement_candidate_threshold_kwh": "個別推定量 表示しきい値(kWh)",
    "measurement_group_threshold_kwh": "下流未確定量 表示しきい値(kWh)",
    "estimation_accumulation_candidate_threshold": "経路推定累積度 表示しきい値",
    "estimation_accumulation_reference_kwh": "経路推定累積度 基準量(kWh)",
    "measurement_boundary_threshold_kwh": "計測推奨境界しきい値(kWh)",
}
MGMT_CFG = dict(MGMT_CFG_DEFAULTS)
CALC_METHOD_CHOICES = ('実測', '按分', '合算')
DISPLAY_METHOD_CHOICES = ('', '実測', '合算', '按分', '残差算出（確定）', '残差算出（推定継承）')
TREE_ROW_LABEL = 'ツリー行'
MEASURE_BASIS_NOTE_HEADER = '根拠・計算条件'

# ノードの開閉状態（階層単位）
depth_open_state: Dict[int, bool] = {d: True for d in range(MAX_DEPTH + 1)}

def _depth_color(d:int)->str:
    colors=['#e8f0ff','#e0ffe0','#fff0cc','#f0e0ff','#d0f0d0','#f5f5f5','#e8fff8']
    return colors[d % len(colors)]

# ---- データモデル ----
def parse_measurement_evaluation_excluded(value: Any) -> bool:
    if value is None or value is False:
        return False
    if value is True:
        return True
    text = str(value).strip().lower()
    if text in ('', '0', '0.0', 'false', 'no', '□'):
        return False
    if text in ('1', '1.0', 'true', 'yes', '☑', '✓'):
        return True
    raise ValueError('計測評価対象外には0/1またはFalse/Trueを指定してください。')

class FlatNode:
    def __init__(self, name, calc_method="実測", at="", measure_name="", ratio="", unit="",
                 energy=0, depth=0, assign_name="", budget_unit="",
                 electric_room="", transformer="", notes="",
                 detail1="", detail2="", category1="", category2="", category3="",
                 sankey_category="", reference_measure_name="", reference_value=0.0, reference_unit="",
                 measurement_evaluation_excluded: bool = False):
        self.name=name; self.calc_method=calc_method; self.at=at
        self.measure_name=measure_name; self.unit=unit
        try:
            self.ratio=float(ratio) if ratio not in (None, "") else 0.0
        except (TypeError, ValueError):
            self.ratio=0.0
        try:
            self.energy=float(energy) if energy not in (None, "") else 0.0
        except (TypeError, ValueError):
            self.energy=0.0
        self.depth=depth; self.assign_name=assign_name; self.budget_unit=budget_unit
        self.electric_room=electric_room; self.transformer=transformer; self.notes=notes
        self.detail1=detail1; self.detail2=detail2
        self.category1=category1; self.category2=category2; self.category3=category3
        self.sankey_category=sankey_category
        self.reference_measure_name=reference_measure_name
        try:
            self.reference_value=float(reference_value) if reference_value not in (None, "") else 0.0
        except (TypeError, ValueError):
            self.reference_value=0.0
        self.reference_unit=reference_unit
        self.measurement_evaluation_excluded = bool(measurement_evaluation_excluded)

@dataclass
class TreeStructureIndex:
    parent_by_index: Dict[int, Optional[int]]
    direct_children_by_index: Dict[int, List[int]]
    has_child_by_index: Dict[int, bool]
    subtree_end_by_index: Dict[int, int]
    structure_issues: List[Dict[str, Any]]
    critical_issues: List[Dict[str, Any]]
    critical_issue_by_index: Dict[int, List[Dict[str, Any]]]
    aggregation_parent_issue_by_index: Dict[int, Dict[str, Any]]
    signature: Tuple[Any, ...]

@dataclass
class ManagementContext:
    estimation_state_by_index: Dict[int, str]
    downstream_confirmed_by_index: Dict[int, Optional[float]]
    group_uncertainty_by_index: Dict[int, Optional[float]]
    terminal_theoretical_max_by_index: Dict[int, Optional[float]]
    terminal_region_boundary_by_index: Dict[int, Optional[int]]
    measurement_recommended_boundary_by_index: Dict[int, bool]
    estimation_accumulation_by_index: Dict[int, Optional[float]]
    estimation_accumulation_negative_by_index: Dict[int, bool]
    budget_units_under_node_by_index: Dict[int, Set[str]]
    at_allocation_group_budget_unit_count_by_index: Dict[int, int]
    diagnostic_terminal_indices: Set[int] = field(default_factory=set)
    aggregated_diagnostic_terminal_indices: Set[int] = field(default_factory=set)
    diagnostic_region_boundary_by_index: Dict[int, Optional[int]] = field(default_factory=dict)
    diagnostic_theoretical_min_by_index: Dict[int, Optional[float]] = field(default_factory=dict)
    diagnostic_theoretical_max_by_index: Dict[int, Optional[float]] = field(default_factory=dict)
    diagnostic_uncertainty_width_by_index: Dict[int, Optional[float]] = field(default_factory=dict)
    management_values_by_index: Dict[int, Tuple[str, str, str]] = field(default_factory=dict)
    management_notice_data_by_index: Dict[int, List[Dict[str, str]]] = field(default_factory=dict)
    management_notice_display_by_index: Dict[int, str] = field(default_factory=dict)
    power_notice_data_by_index: Dict[int, List[Dict[str, str]]] = field(default_factory=dict)

_tree_structure_index_cache: Optional[TreeStructureIndex] = None
_tree_structure_cache_version = 0
_management_context_cache: Optional[ManagementContext] = None
BUDGET_UNIT_AGGREGATE = '集約'
BUDGET_UNIT_POWER = '電源'

def invalidate_tree_structure_cache():
    global _tree_structure_index_cache, _tree_structure_cache_version
    _tree_structure_index_cache = None
    _tree_structure_cache_version += 1
    invalidate_management_cache()

def invalidate_management_cache():
    global _management_context_cache
    _management_context_cache = None

def invalidate_all_runtime_caches():
    invalidate_tree_structure_cache()

SAMPLE_TREE_DATA = [
    {"depth": 0, "name": "○○盤_主幹", "calc_method": "実測", "at": "500", "measure_name": "○○盤_主幹", "budget_unit": BUDGET_UNIT_POWER, "electric_room": "第一電気室", "transformer": "TR-01", "sankey_category": "○○盤_主幹", "notes": ""},
    {"depth": 1, "name": "A課設備①", "calc_method": "実測", "at": "100", "measure_name": "○○盤_A課設備①", "budget_unit": "AAA", "electric_room": "第一電気室", "transformer": "TR-01", "category1": "生産", "sankey_category": "生産設備"},
    {"depth": 1, "name": "××盤送り", "calc_method": "合算", "at": "75", "measure_name": "", "budget_unit": "集約", "electric_room": "第一電気室", "transformer": "TR-01", "category1": "盤送り", "sankey_category": ""},
    {"depth": 2, "name": "A課設備②", "calc_method": "実測", "at": "30", "measure_name": "××盤_A課設備②", "budget_unit": "AAA", "electric_room": "第二電気室", "transformer": "TR-02", "category1": "生産", "sankey_category": "生産設備"},
    {"depth": 2, "name": "B課設備①", "calc_method": "実測", "at": "50", "measure_name": "××盤_B課設備①", "budget_unit": "BBB", "electric_room": "第二電気室", "transformer": "TR-02", "category1": "生産", "sankey_category": "生産設備"},
    {"depth": 1, "name": "B課設備②", "calc_method": "按分", "at": "15", "measure_name": "", "budget_unit": "BBB", "electric_room": "第一電気室", "transformer": "TR-01", "category1": "生産", "sankey_category": "生産設備"},
    {"depth": 1, "name": "共用コンプレッサー", "calc_method": "按分", "at": "300", "measure_name": "", "budget_unit": "集約", "electric_room": "第一電気室", "transformer": "TR-01", "category1": "ユーティリティ", "sankey_category": ""},
    {"depth": 2, "name": "仮想ノード_コンプレッサー_按分01", "calc_method": "按分", "at": "1", "measure_name": "圧縮空気流量_A課", "budget_unit": "AAA", "electric_room": "第一電気室", "transformer": "TR-01", "category1": "ユーティリティ", "sankey_category": "圧縮空気", "measurement_evaluation_excluded": True},
    {"depth": 2, "name": "仮想ノード_コンプレッサー_按分02", "calc_method": "按分", "at": "1", "measure_name": "圧縮空気流量_B課", "budget_unit": "BBB", "electric_room": "第一電気室", "transformer": "TR-01", "category1": "ユーティリティ", "sankey_category": "圧縮空気", "measurement_evaluation_excluded": True},
]

SAMPLE_MEASURE_DATA = [
    ("○○盤_主幹", 9800, "kWh", "主幹メーター実測値"),
    ("○○盤_A課設備①", 1040, "kWh", "既設メーター実測値"),
    ("××盤_A課設備②", 420, "kWh", "既設メーター実測値"),
    ("××盤_B課設備①", 810, "kWh", "既設メーター実測値"),
    ("〇〇盤_共用コンプレッサー", 7300, "kWh", "共用コンプレッサーの実測化を試すための電力量"),
    ("圧縮空気流量_A課", 1732, "m3", "共用コンプレッサー按分比率"),
    ("圧縮空気流量_B課", 7499, "m3", "共用コンプレッサー按分比率"),
]

SAMPLE_BUDGET_DATA = [
    ("AAA", "A課"),
    ("BBB", "B課"),
]

def create_sample_flat_nodes() -> List[FlatNode]:
    return [
        FlatNode(
            item.get("name", ""),
            item.get("calc_method", "実測"),
            item.get("at", ""),
            item.get("measure_name", ""),
            0.0,
            "",
            0.0,
            item.get("depth", 0),
            budget_unit=item.get("budget_unit", ""),
            electric_room=item.get("electric_room", ""),
            transformer=item.get("transformer", ""),
            notes=item.get("notes", ""),
            detail1=item.get("detail1", ""),
            detail2=item.get("detail2", ""),
            category1=item.get("category1", ""),
            category2=item.get("category2", ""),
            category3=item.get("category3", ""),
            sankey_category=item.get("sankey_category", ""),
            measurement_evaluation_excluded=item.get("measurement_evaluation_excluded", False),
        )
        for item in SAMPLE_TREE_DATA
    ]

def create_sample_measure_master() -> Dict[str, Dict[str, Any]]:
    return {
        name: {
            "量・比率(元)": float(quantity),
            "単位(元)": unit,
            MEASURE_BASIS_NOTE_HEADER: note,
        }
        for name, quantity, unit, note in SAMPLE_MEASURE_DATA
    }

def create_sample_budget_unit_master() -> Dict[str, str]:
    return {code: name for code, name in SAMPLE_BUDGET_DATA}

# 公式サンプル（起動時表示用）
flat_nodes = create_sample_flat_nodes()

# マスタ（キーは normalize_key 済みで保存する）
measure_master: Dict[str, Dict[str, Any]] = {}
budget_unit_master: Dict[str, str] = {}
measure_name_options = {n.measure_name for n in flat_nodes if n.measure_name}
measure_master.update(create_sample_measure_master())
budget_unit_master.update(create_sample_budget_unit_master())
is_sample_mode = True
sample_status_var: Optional[tk.StringVar] = None
current_input_files: Dict[str, Any] = {
    "tree": None,
    "measure": [],
    "budget": None,
}
config_input_file_candidates: Dict[str, Any] = {
    "tree": None,
    "measure": [],
    "budget": None,
}
bulk_input_window: Optional[tk.Toplevel] = None
budget_csv_auto_loaded = False
budget_csv_auto_load_message = ''

def get_sample_status_text() -> str:
    if is_sample_mode:
        return 'サンプルデータ表示中'
    return ''

def update_sample_status_label():
    if sample_status_var is not None:
        sample_status_var.set(get_sample_status_text())

def set_sample_mode(enabled: bool):
    global is_sample_mode
    is_sample_mode = enabled
    update_sample_status_label()

def reset_to_sample_data(redraw: bool = True, show_message: bool = True):
    global budget_csv_auto_loaded, budget_csv_auto_load_message
    flat_nodes.clear()
    flat_nodes.extend(create_sample_flat_nodes())
    measure_master.clear()
    measure_master.update(create_sample_measure_master())
    budget_unit_master.clear()
    budget_unit_master.update(create_sample_budget_unit_master())
    measure_name_options.clear()
    measure_name_options.update(n.measure_name for n in flat_nodes if n.measure_name)
    current_input_files["tree"] = None
    current_input_files["measure"] = []
    current_input_files["budget"] = None
    budget_csv_auto_loaded = False
    budget_csv_auto_load_message = ''
    invalidate_all_runtime_caches()
    set_sample_mode(True)
    apply_masters_from_csv()
    calculate_energy()
    if redraw:
        redraw_preserving_state()

@dataclass
class CsvFileStatus:
    path: str
    status: str = '選択済み'
    result: str = ''
    row_count: Optional[int] = None
    error: Optional[str] = None
    duplicate_count: int = 0

@dataclass
class TreeCsvLoadResult:
    nodes: List[FlatNode]
    measure_name_options: Set[str]
    row_count: int

@dataclass
class MeasureCsvLoadResult:
    master: Dict[str, Dict[str, Any]]
    total_rows: int
    unique_count: int
    duplicate_count: int
    file_statuses: List[CsvFileStatus] = field(default_factory=list)

@dataclass
class BudgetCsvLoadResult:
    master: Dict[str, str]
    total_rows: int
    unique_count: int

# ---- 設定（幅・管理条件） ----
def load_config():
    global saved_node_name_width, saved_measure_name_width, saved_assign_name_width, saved_detail2_width, MGMT_CFG, config_input_file_candidates
    global reporting_settings
    from anbun_reporting import load_reporting_settings
    reporting_settings = load_reporting_settings(CONFIG_PATH)
    try:
        data = {}
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
        for key, var, cap in [
            ('node_name_width','saved_node_name_width',MAX_NODE_NAME_WIDTH),
            ('measure_name_width','saved_measure_name_width',MAX_MEASURE_NAME_WIDTH),
            ('assign_name_width','saved_assign_name_width',MAX_ASSIGN_NAME_WIDTH),
            ('detail2_width','saved_detail2_width',MAX_DETAIL2_WIDTH)
        ]:
            w = data.get(key, None)
            if isinstance(w, int) and w>0:
                globals()[var] = min(w, cap)
        mg = data.get('management', {})
        if isinstance(mg, dict):
            tmp = dict(MGMT_CFG)
            for k in MGMT_CFG_DEFAULTS:
                if k in mg and isinstance(mg[k], (int,float)):
                    value = float(mg[k])
                    if k == 'measurement_boundary_threshold_kwh' and (not math.isfinite(value) or value < 0):
                        value = MGMT_CFG_DEFAULTS[k]
                    tmp[k] = value
            MGMT_CFG = tmp
            invalidate_management_cache()
        input_files = data.get('input_files', {})
        if isinstance(input_files, dict):
            measure_paths = input_files.get('measure', [])
            if isinstance(measure_paths, str):
                measure_paths = [measure_paths]
            elif not isinstance(measure_paths, list):
                measure_paths = []
            config_input_file_candidates = {
                "tree": input_files.get('tree') if isinstance(input_files.get('tree'), str) else None,
                "measure": [p for p in measure_paths if isinstance(p, str)],
                "budget": input_files.get('budget') if isinstance(input_files.get('budget'), str) else None,
            }
    except Exception as e:
        print('[CONFIG] 読み込み失敗:', e)

def save_config():
    try:
        base = {}
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH,'r',encoding='utf-8') as f: base = json.load(f) or {}
            except Exception: base={}
        if 'management' not in base or not isinstance(base['management'], dict):
            base['management'] = {}
        if tree is not None:
            def _w(nm, default):
                try: return int(tree.column(nm,'width'))
                except: return default or 0
            base['node_name_width'] = _w('#0', saved_node_name_width)
            base['measure_name_width'] = _w('計量名称', saved_measure_name_width)
            base['assign_name_width'] = _w('予算単位コード', saved_assign_name_width)
            base['detail2_width'] = _w('詳細２', saved_detail2_width)
            base['management'].pop('parent_child_tolerance_percent', None)
            base['management'].pop('measurement_candidate_top_percent', None)
            base['management'].pop('path_uncertainty_threshold_kwh', None)
            for key, default in MGMT_CFG_DEFAULTS.items():
                base['management'][key] = float(MGMT_CFG.get(key, default))
        base['input_files'] = {
            "tree": current_input_files.get("tree") or config_input_file_candidates.get("tree"),
            "measure": list(current_input_files.get("measure") or config_input_file_candidates.get("measure") or []),
            "budget": current_input_files.get("budget") or config_input_file_candidates.get("budget"),
        }
        with open(CONFIG_PATH,'w',encoding='utf-8') as f:
            json.dump(base,f,ensure_ascii=False,indent=2)
        print('[CONFIG] 保存:', CONFIG_PATH)
    except Exception as e:
        print('[CONFIG] 保存失敗:', e)

# ---- ユーティリティ ----
_num_pattern = re.compile(r"[\+\-]?\d*\.?\d+(?:[eE][\+\-]?\d+)?")

def extract_number(val, default=None):
    if val is None: return default
    if isinstance(val, (int,float)): return float(val)
    m = _num_pattern.search(str(val)); return float(m.group()) if m else default

def format_at_display(val):
    num = extract_number(val, None)
    return str(int(round(num))) if num is not None else ("" if val is None else str(val))

def is_ratio_called_allocation_node(node: FlatNode)->bool:
    return (
        node.calc_method == '按分'
        and normalize_value(node.measure_name).strip() != ''
    )

def format_at_tree_display(node: FlatNode)->str:
    if is_ratio_called_allocation_node(node):
        return '外部比率'
    return format_at_display(node.at)

def format_energy_display(val):
    try:
        num = float(val)
        if not math.isfinite(num):
            return "計算不能"
        return f"{num:,.1f} kWh"
    except (TypeError, ValueError):
        return ""

def format_ratio_display(val):
    try:
        num = float(val)
        if not math.isfinite(num):
            return "不正"
        return f"{num:.1f}"
    except (TypeError, ValueError):
        return ""

def format_reference_value_display(node: FlatNode):
    if normalize_value(node.reference_measure_name).strip() == '':
        return ''
    key = normalize_key(node.reference_measure_name).strip()
    if key not in measure_master:
        return ''
    try:
        return f"{float(node.reference_value):,.1f}"
    except (TypeError, ValueError):
        return ''

def get_reference_value_export_value(node: FlatNode):
    if normalize_value(node.reference_measure_name).strip() == '':
        return ''
    key = normalize_key(node.reference_measure_name).strip()
    if key not in measure_master:
        return ''
    try:
        return float(node.reference_value)
    except (TypeError, ValueError):
        return ''

def is_kwh_ratio_reference_node(node: FlatNode)->bool:
    return (
        is_ratio_called_allocation_node(node)
        and normalize_value(node.unit).strip().lower() == 'kwh'
    )

def compute_allocation_kwh_reference_difference(node: FlatNode)->Any:
    if not is_kwh_ratio_reference_node(node):
        return ''
    try:
        ratio = float(node.ratio)
        energy = float(node.energy)
    except (TypeError, ValueError):
        return ''
    if not math.isfinite(ratio) or not math.isfinite(energy):
        return ''
    return energy - ratio

def format_signed_kwh_reference_difference(node: FlatNode)->str:
    diff = compute_allocation_kwh_reference_difference(node)
    if diff == '':
        return ''
    return f'{float(diff):+,.1f} kWh'

def normalize_value(v):
    if v is None: return ""
    s=str(v).replace('\ufeff','').replace('\u00A0',' ')
    s=s.replace('\r\n',' ').replace('\r',' ').replace('\n',' ')
    s=re.sub(r"\s+"," ",s)
    return s.strip()

def normalize_key(v):
    s=normalize_value(v)
    s=s.replace('（','(').replace('）',')')
    return s

_excel_date_like = re.compile(r'^\d{1,4}([\-/]\d{1,2}){1,2}$')

def excel_safe_text(v):
    if v is None: return ""
    s=str(v)
    if s[:1] in ('=','+','-','@') or _excel_date_like.match(s): s="'"+s
    return s

# ---- CSVユーティリティ ----
def normalize_header(s:str)->str:
    if s is None: return ''
    s=s.replace('\ufeff','').replace('（','(').replace('）',')'); return s.strip()

def read_csv_dicts_with_fallback(path:str)->List[Dict[str,Any]]:
    for enc in ('utf-8-sig','cp932','utf-8'):
        try:
            with open(path,'r',encoding=enc,newline='') as f:
                reader=csv.DictReader(f); rows=[]
                for row in reader:
                    if not row: continue
                    norm={}; empty=True
                    for k,v in row.items():
                        if k is None: continue
                        nk=normalize_header(k)
                        if nk == MEASURE_BASIS_NOTE_HEADER:
                            # AI分析用メモは計算に使わず、CSV内の改行を保った文字列として扱う。
                            nv='' if v is None else str(v).replace('\ufeff','').replace('\r\n','\n').replace('\r','\n').strip()
                        else:
                            nv=normalize_value(v)
                        if nv!='': empty=False; norm[nk]=nv
                    if not empty: rows.append(norm)
                print(f"[CSV] '{path}' 読み込み成功（{enc}）: {len(rows)}行"); return rows
        except Exception as e:
            print(f"[CSV] '{path}' 読み込み失敗（{enc}）: {e}")
    print(f"[CSV] '{path}' 読み込みに失敗しました。"); return []

# ---- 量・比率CSV / 予算単位CSV の参照 ----
def get_measure_master_amount(measure_name: str, default: float = 0.0) -> float:
    key = normalize_key(measure_name).strip()
    if not key or key not in measure_master:
        return default
    try:
        return float(measure_master[key].get('量・比率(元)', default))
    except (TypeError, ValueError):
        return default

def apply_measure_value_to_node(node: FlatNode):
    key = normalize_key(node.measure_name).strip()
    if node.calc_method == '実測':
        node.energy = get_measure_master_amount(node.measure_name, 0.0)
    elif node.calc_method == '按分':
        if key and key in measure_master:
            src = measure_master[key]
            node.ratio = float(src.get('量・比率(元)', 0.0))
            node.unit = normalize_value(src.get('単位(元)', ''))
        elif not key:
            # 計量名称未入力時だけ、ATを暫定の按分比率として使う。
            node.ratio = extract_number(node.at, 0.0) or 0.0
            node.unit = 'AT'
        else:
            node.ratio = 0.0
            node.unit = ''

def apply_measure_values_before_recalc():
    for n in flat_nodes:
        apply_measure_value_to_node(n)

def apply_reference_measure_value_to_node(node: FlatNode):
    key = normalize_key(node.reference_measure_name).strip()
    if key and key in measure_master:
        src = measure_master[key]
        try:
            node.reference_value = float(src.get('量・比率(元)', 0.0))
        except (TypeError, ValueError):
            node.reference_value = 0.0
        node.reference_unit = normalize_value(src.get('単位(元)', ''))
    else:
        node.reference_value = 0.0
        node.reference_unit = ''

def apply_reference_measure_values():
    for n in flat_nodes:
        apply_reference_measure_value_to_node(n)

def apply_masters_from_csv():
    apply_measure_values_before_recalc()
    apply_reference_measure_values()
    apply_budget_unit_structure_rules()

def normalize_calc_method_for_import(value: Any) -> str:
    method = normalize_value(value)
    # 旧CSVの複数字アイコン、短縮表示名、アイコン単独も内部の「按分」へ戻す。
    residual_icons = ('＝✓', '=✓', '＝~', '=~', '＝～', '=～', '≈', '✓')
    if method in residual_icons:
        return '按分'
    for icon in sorted([*METHOD_ICON.values(), *residual_icons, '📊✅'], key=len, reverse=True):
        if icon:
            method = method.replace(icon, '')
    method = normalize_value(method)
    method = method.replace('（', '(').replace('）', ')')
    if method in ('按分(確定)', '残差算出(確定)', '残差算出(推定継承)',
                  '残差(確定)', '残差(推定継承)'):
        return '按分'
    if method in CALC_METHOD_CHOICES:
        return method
    return method

def sanitize_calc_method(value: str) -> str:
    method = normalize_calc_method_for_import(value)
    return method if method in CALC_METHOD_CHOICES else ''

def validate_tree_calc_method(value: Any, row_no: int) -> Tuple[Optional[str], Optional[str]]:
    raw = normalize_value(value)
    method = normalize_calc_method_for_import(raw)
    if raw == '':
        return None, f'{row_no}行目: 算出方法が空です'
    if method not in CALC_METHOD_CHOICES:
        return None, (
            f'{row_no}行目: 算出方法が不正です（{raw}）。'
            '「実測」「按分」「合算」「按分(確定)」のいずれかを入力してください。'
            'なお、「按分(確定)」は読込時に「按分」として扱います。'
        )
    return method, None

def apply_measure_master_to_node(node: FlatNode):
    apply_measure_value_to_node(node)
    apply_reference_measure_value_to_node(node)

def calculate_energy():
    apply_budget_unit_structure_rules()
    apply_measure_values_before_recalc()
    apply_reference_measure_values()
    invalidate_structure = globals().get('invalidate_tree_structure_cache')
    if callable(invalidate_structure):
        invalidate_structure()
    else:
        globals()['_tree_structure_index_cache'] = None
    structure = get_tree_structure_index()
    if structure.critical_issues:
        for node in flat_nodes:
            node.energy = math.nan
        invalidate_management = globals().get('invalidate_management_cache')
        if callable(invalidate_management):
            invalidate_management()
        return False
    for node in flat_nodes:
        node.energy = 0.0
    for node in flat_nodes:
        if node.calc_method == '実測':
            node.energy = get_measure_master_amount(node.measure_name, 0.0)
    # 合算（深→浅）
    for depth in reversed(range(MAX_DEPTH+1)):
        for i,node in enumerate(flat_nodes):
            if node.depth==depth and node.calc_method=='合算':
                node.energy=sum(flat_nodes[j].energy for j in structure.direct_children_by_index.get(i, []))
    # 按分（浅→深）
    for depth in range(MAX_DEPTH+1):
        for i,node in enumerate(flat_nodes):
            if node.depth==depth:
                children=[flat_nodes[j] for j in structure.direct_children_by_index.get(i, [])]
                anb=[c for c in children if c.calc_method=='按分']
                settled=[c for c in children if c.calc_method in ['実測','合算']]
                fixed_total=sum(c.energy for c in settled)
                ratio_total=sum(c.ratio for c in anb)
                remaining=node.energy-fixed_total
                for c in anb:
                    c.energy = (remaining * c.ratio / ratio_total) if ratio_total>0 else math.nan
    invalidate_management = globals().get('invalidate_management_cache')
    if callable(invalidate_management):
        invalidate_management()
    return True

# ---- ツリー構造の索引 ----
def get_tree_structure_signature(nodes:Optional[List[FlatNode]]=None)->Tuple[Any, ...]:
    if nodes is None:
        nodes = flat_nodes
    if nodes is flat_nodes and '_tree_structure_cache_version' in globals():
        return ('flat_nodes', len(flat_nodes), globals().get('_tree_structure_cache_version', 0))
    return tuple(
        (
            getattr(node, 'depth', 0),
            getattr(node, 'calc_method', ''),
            getattr(node, 'name', ''),
            getattr(node, 'at', ''),
            getattr(node, 'measure_name', ''),
            getattr(node, 'ratio', 0.0),
            getattr(node, 'unit', ''),
        )
        for node in nodes
    )

def make_critical_issue(code:str, node_index:int, nodes:List[FlatNode], message:str,
                        detail:str, display:str, **extra)->Dict[str, Any]:
    issue = {
        'severity': 'critical',
        'code': code,
        'row': node_index + 1,
        'node_index': node_index,
        'node_name': nodes[node_index].name if 0 <= node_index < len(nodes) else '',
        'message': message,
        'detail': detail,
        'display': display,
    }
    issue.update(extra)
    return issue

def format_critical_issue_display(issue:Dict[str, Any])->str:
    return issue.get('display') or issue.get('message') or '計算不能'

def format_critical_issue_detail(issue:Dict[str, Any])->str:
    display = format_critical_issue_display(issue)
    message = issue.get('message', '')
    detail = issue.get('detail', '')
    if detail and message and detail != message:
        return f'{display}\n{message}\n\n{detail}'
    if detail:
        return f'{display}\n{detail}'
    if message:
        return f'{display}\n{message}'
    return display

def format_severity_for_display(severity:str)->str:
    return 'クリティカル' if severity == 'critical' else severity

def coerce_finite_number(value:Any)->Optional[float]:
    try:
        num = float(value)
    except (TypeError, ValueError):
        return None
    return num if math.isfinite(num) else None

def format_node_ref(index:int, nodes:List[FlatNode])->str:
    if 0 <= index < len(nodes):
        return f'{index + 1}行目「{nodes[index].name}」'
    return f'{index + 1}行目'

def format_cycle_path(cycle:List[int], nodes:List[FlatNode])->str:
    return ' → '.join(format_node_ref(index, nodes) for index in cycle)

def _cycle_key(cycle:List[int])->Tuple[int, ...]:
    core = cycle[:-1] if len(cycle) > 1 and cycle[0] == cycle[-1] else cycle
    if not core:
        return tuple()
    rotations = [tuple(core[i:] + core[:i]) for i in range(len(core))]
    return min(rotations)

def find_directed_graph_cycles(edges:Dict[int, List[int]], limit:int=20)->List[List[int]]:
    cycles: List[List[int]] = []
    seen: Set[Tuple[int, ...]] = set()
    visiting: Set[int] = set()
    visited: Set[int] = set()
    stack: List[int] = []
    stack_pos: Dict[int, int] = {}

    def dfs(node:int):
        if len(cycles) >= limit:
            return
        visiting.add(node)
        stack_pos[node] = len(stack)
        stack.append(node)
        for next_node in edges.get(node, []):
            if next_node not in edges:
                continue
            if next_node in visiting:
                start = stack_pos[next_node]
                cycle = stack[start:] + [next_node]
                key = _cycle_key(cycle)
                if key not in seen:
                    seen.add(key)
                    cycles.append(cycle)
                    if len(cycles) >= limit:
                        break
            elif next_node not in visited:
                dfs(next_node)
                if len(cycles) >= limit:
                    break
        stack.pop()
        stack_pos.pop(node, None)
        visiting.discard(node)
        visited.add(node)

    for node in list(edges.keys()):
        if node not in visited:
            dfs(node)
            if len(cycles) >= limit:
                break
    return cycles

def find_parent_reference_cycle_issues(parent_by_index:Dict[int, Optional[int]],
                                       nodes:List[FlatNode])->List[Dict[str, Any]]:
    issues: List[Dict[str, Any]] = []
    edges: Dict[int, List[int]] = {i: [] for i in range(len(nodes))}
    for index in range(len(nodes)):
        parent_index = parent_by_index.get(index)
        if parent_index is None:
            continue
        if parent_index == index:
            issues.append(make_critical_issue(
                'self_parent_reference',
                index,
                nodes,
                '親子関係で自分自身を親として参照しています',
                (
                    f'{format_node_ref(index, nodes)} が自分自身を親として参照しています。\n'
                    '親子関係をたどると同じノードへ戻るため、ツリー構造を修正してください。'
                ),
                '計算不能:構造循環',
                cycle_indices=[index, index],
            ))
            continue
        if 0 <= parent_index < len(nodes):
            edges[index].append(parent_index)
        else:
            issues.append(make_critical_issue(
                'invalid_parent_reference',
                index,
                nodes,
                '親子関係が存在しないノードを参照しています',
                (
                    f'{format_node_ref(index, nodes)} の親参照が存在しないノードを指しています。\n'
                    '親子関係を修正してください。'
                ),
                '計算不能:親参照不正',
                parent_index=parent_index,
            ))

    for cycle in find_directed_graph_cycles(edges):
        issues.append(make_critical_issue(
            'parent_reference_cycle',
            cycle[0],
            nodes,
            '親子関係に循環があります',
            (
                '親子関係をたどると同じノードへ戻ります。\n'
                f'循環: {format_cycle_path(cycle, nodes)}\n'
                'ツリー構造を修正してください。'
            ),
            '計算不能:構造循環',
            cycle_indices=cycle,
        ))
    return issues

def build_value_dependency_graph(nodes:List[FlatNode],
                                 direct_children_by_index:Dict[int, List[int]])->Dict[int, List[int]]:
    """x = Mm + Gx + PRDx の値依存関係だけを表す軽量グラフを作る。"""
    edges: Dict[int, List[int]] = {i: [] for i in range(len(nodes))}
    for parent_index, child_indices in direct_children_by_index.items():
        parent = nodes[parent_index]
        if getattr(parent, 'calc_method', '') == '合算':
            edges[parent_index].extend(child_indices)

        allocation_children = [
            child_index for child_index in child_indices
            if getattr(nodes[child_index], 'calc_method', '') == '按分'
        ]
        if allocation_children:
            settled_children = [
                child_index for child_index in child_indices
                if getattr(nodes[child_index], 'calc_method', '') in ('実測', '合算')
            ]
            for child_index in allocation_children:
                deps = [parent_index] + settled_children
                edges[child_index].extend(dep for dep in deps if dep != child_index)

    return {
        index: sorted(set(dep for dep in deps if 0 <= dep < len(nodes)))
        for index, deps in edges.items()
    }

def cycle_has_aggregation_allocation_edge(cycle:List[int], aggregation_pairs:Set[Tuple[int, int]])->bool:
    for left, right in zip(cycle, cycle[1:]):
        if (left, right) in aggregation_pairs or (right, left) in aggregation_pairs:
            return True
    return False

def find_value_dependency_cycle_issues(nodes:List[FlatNode],
                                       dependency_graph:Dict[int, List[int]],
                                       aggregation_pairs:Set[Tuple[int, int]])->List[Dict[str, Any]]:
    issues: List[Dict[str, Any]] = []
    for cycle in find_directed_graph_cycles(dependency_graph):
        if cycle_has_aggregation_allocation_edge(cycle, aggregation_pairs):
            continue
        issues.append(make_critical_issue(
            'calculation_dependency_cycle',
            cycle[0],
            nodes,
            '計算依存関係が循環しています',
            (
                'あるノードの電力量を求めるために別ノードを参照し、'
                'その依存関係をたどると元のノードへ戻ります。\n'
                f'依存関係: {format_cycle_path(cycle, nodes)}\n'
                '現行の実測・合算・按分ルールでは、この閉ループにより電力量を正常に決定できません。'
            ),
            '計算不能:一意解なし',
            cycle_indices=cycle,
        ))
    return issues

def find_allocation_ratio_issues(nodes:List[FlatNode],
                                 direct_children_by_index:Dict[int, List[int]])->List[Dict[str, Any]]:
    issues: List[Dict[str, Any]] = []
    eps = 1e-12
    for parent_index, child_indices in direct_children_by_index.items():
        allocation_children = [
            child_index for child_index in child_indices
            if getattr(nodes[child_index], 'calc_method', '') == '按分'
        ]
        if not allocation_children:
            continue

        ratios: List[Tuple[int, float]] = []
        invalid_children: List[int] = []
        for child_index in allocation_children:
            ratio = coerce_finite_number(getattr(nodes[child_index], 'ratio', 0.0))
            if ratio is None:
                invalid_children.append(child_index)
            else:
                ratios.append((child_index, ratio))

        if invalid_children:
            child_text = '、'.join(format_node_ref(child_index, nodes) for child_index in invalid_children)
            issues.append(make_critical_issue(
                'allocation_ratio_invalid',
                parent_index,
                nodes,
                '按分対象に有限数ではない按分比率があります',
                (
                    f'{format_node_ref(parent_index, nodes)} の直属子に、'
                    f'有限数ではない按分比率の按分ノードがあります（{child_text}）。\n'
                    'NaN、Inf、数値として扱えない比率では按分係数を構成できません。\n'
                    '量・比率CSV、計量名称、ATを確認してください。'
                ),
                '計算不能:按分比率不正',
                parent_index=parent_index,
                child_indices=invalid_children,
                child_rows=[child_index + 1 for child_index in invalid_children],
            ))
            continue

        ratio_total = sum(ratio for _child_index, ratio in ratios)
        has_nonzero_ratio = any(abs(ratio) > eps for _child_index, ratio in ratios)
        if not has_nonzero_ratio or ratio_total <= eps:
            child_text = '、'.join(
                f'{format_node_ref(child_index, nodes)}={ratio:g}'
                for child_index, ratio in ratios
            )
            issues.append(make_critical_issue(
                'allocation_ratio_total_zero',
                parent_index,
                nodes,
                '按分対象がありますが、有効な按分比率の合計が0以下です',
                (
                    f'{format_node_ref(parent_index, nodes)} には按分対象の直属子がありますが、'
                    '有効な按分比率の合計が0以下です。\n'
                    f'按分対象: {child_text}\n'
                    'この状態では親ノードの残電力量を按分する係数を構成できません。'
                    '暗黙的な均等按分や0kWh代替は行わず、比率、計量名称、ATを修正してください。'
                ),
                '計算不能:按分比率不正',
                parent_index=parent_index,
                child_indices=allocation_children,
                child_rows=[child_index + 1 for child_index in allocation_children],
                ratio_total=ratio_total,
            ))
    return issues

def build_tree_structure_index(nodes:Optional[List[FlatNode]]=None)->TreeStructureIndex:
    if nodes is None:
        nodes = flat_nodes
    signature = get_tree_structure_signature(nodes)
    parent_by_index: Dict[int, Optional[int]] = {}
    direct_children_by_index: Dict[int, List[int]] = {i: [] for i in range(len(nodes))}
    subtree_end_by_index: Dict[int, int] = {}
    issues: List[Dict[str, Any]] = []
    ancestor_by_depth: Dict[int, int] = {}
    open_stack: List[int] = []

    for index, node in enumerate(nodes):
        depth = node.depth
        while open_stack and nodes[open_stack[-1]].depth >= depth:
            ended = open_stack.pop()
            subtree_end_by_index[ended] = index

        parent_index = ancestor_by_depth.get(depth - 1) if depth > 0 else None
        parent_by_index[index] = parent_index
        if parent_index is not None:
            direct_children_by_index[parent_index].append(index)
        elif depth > 0:
            expected_depth = depth - 1
            issues.append(make_critical_issue(
                'missing_parent_depth',
                index,
                nodes,
                f'親となる{expected_depth}層ノードが存在しない{depth}層ノードです',
                (
                    f'{index + 1}行目「{node.name}」は{depth}層ですが、'
                    f'直前の上位構造内に親となる{expected_depth}層ノードがありません。\n'
                    '編集途中の状態としては許容されますが、完成データとして出力する前に'
                    '階層構造を修正してください。'
                ),
                '計算不能:親階層なし',
            ))
        elif getattr(node, 'calc_method', '') == '按分':
            issues.append(make_critical_issue(
                'root_allocation_without_parent',
                index,
                nodes,
                '0層の按分ノードには親ノードが存在しません',
                (
                    f'{index + 1}行目「{node.name}」は0層の按分ノードです。\n'
                    '「按分」は親ノードの電力量を基準として子ノードの電力量を算出します。\n'
                    'このノードは0層にあり親ノードが存在しないため、自身の電力量を正常に決定できません。\n'
                    '0層ノードの算出方法またはツリー構成を確認してください。'
                ),
                '計算不能:親なし按分',
            ))

        ancestor_by_depth[depth] = index
        for stale_depth in [d for d in ancestor_by_depth if d > depth]:
            del ancestor_by_depth[stale_depth]
        open_stack.append(index)

    for index in open_stack:
        subtree_end_by_index[index] = len(nodes)

    issues.extend(find_parent_reference_cycle_issues(parent_by_index, nodes))

    aggregation_parent_issue_by_index: Dict[int, Dict[str, Any]] = {}
    aggregation_pairs: Set[Tuple[int, int]] = set()
    for parent_index, parent in enumerate(nodes):
        if getattr(parent, 'calc_method', '') != '合算':
            continue
        child_indices = [
            child_index
            for child_index in direct_children_by_index.get(parent_index, [])
            if getattr(nodes[child_index], 'calc_method', '') == '按分'
        ]
        if not child_indices:
            continue
        child_names = [nodes[child_index].name for child_index in child_indices]
        child_rows = [child_index + 1 for child_index in child_indices]
        child_text = '、'.join(
            f'{row}行目「{name}」'
            for row, name in zip(child_rows, child_names)
        )
        issue = make_critical_issue(
            'aggregation_parent_has_allocation_child',
            parent_index,
            nodes,
            '合算ノードの直属子に按分ノードがあります',
            (
                f'{parent_index + 1}行目「{parent.name}」は合算ノードですが、'
                f'直属子に按分ノード（{child_text}）があります。\n'
                '合算は子ノードから親ノードを算出し、按分は親ノードから子ノードを算出します。\n'
                '同じ親子関係で両者が共存すると、P = S + A、A = P - S のように'
                '絶対値を決める情報が失われるため、電力量を正常に決定できません。'
            ),
            '構造エラー:合算子に按分',
            parent_index=parent_index,
            parent_name=parent.name,
            parent_row=parent_index + 1,
            child_indices=child_indices,
            child_names=child_names,
            child_rows=child_rows,
        )
        issues.append(issue)
        aggregation_parent_issue_by_index[parent_index] = issue
        for child_index in child_indices:
            aggregation_pairs.add((parent_index, child_index))

    issues.extend(find_allocation_ratio_issues(nodes, direct_children_by_index))
    dependency_graph = build_value_dependency_graph(nodes, direct_children_by_index)
    issues.extend(find_value_dependency_cycle_issues(nodes, dependency_graph, aggregation_pairs))

    critical_issues = [issue for issue in issues if issue.get('severity') == 'critical']
    critical_issue_by_index: Dict[int, List[Dict[str, Any]]] = {}
    for issue in critical_issues:
        node_index = issue.get('node_index')
        if isinstance(node_index, int):
            critical_issue_by_index.setdefault(node_index, []).append(issue)
    has_child_by_index = {
        index: bool(children)
        for index, children in direct_children_by_index.items()
    }
    return TreeStructureIndex(
        parent_by_index=parent_by_index,
        direct_children_by_index=direct_children_by_index,
        has_child_by_index=has_child_by_index,
        subtree_end_by_index=subtree_end_by_index,
        structure_issues=issues,
        critical_issues=critical_issues,
        critical_issue_by_index=critical_issue_by_index,
        aggregation_parent_issue_by_index=aggregation_parent_issue_by_index,
        signature=signature,
    )

def get_tree_structure_index()->TreeStructureIndex:
    global _tree_structure_index_cache
    if '_tree_structure_cache_version' not in globals():
        signature = get_tree_structure_signature()
        if _tree_structure_index_cache is None or _tree_structure_index_cache.signature != signature:
            _tree_structure_index_cache = build_tree_structure_index()
        return _tree_structure_index_cache
    if _tree_structure_index_cache is None:
        _tree_structure_index_cache = build_tree_structure_index()
    return _tree_structure_index_cache

def get_parent_index(index:int)->Optional[int]:
    return get_tree_structure_index().parent_by_index.get(index)

def get_direct_child_indices(index:int) -> List[int]:
    return list(get_tree_structure_index().direct_children_by_index.get(index, []))

def get_direct_children(index:int)->List[FlatNode]:
    return [flat_nodes[i] for i in get_direct_child_indices(index)]

def has_child(index):
    return bool(get_tree_structure_index().has_child_by_index.get(index, False))

def get_subtree_end_index(index:int)->int:
    return get_tree_structure_index().subtree_end_by_index.get(index, index + 1)

def get_subtree_indices(index:int)->range:
    return range(index, get_subtree_end_index(index))

def validate_calc_method_change(index:int, new_method:str)->Tuple[bool, str]:
    if new_method == '按分':
        if 0 <= index < len(flat_nodes) and flat_nodes[index].depth == 0:
            return False, (
                '0層ノードは「按分」には変更できません。\n\n'
                '「按分」は親ノードの電力量を基準として算出しますが、\n'
                '0層ノードには親ノードが存在しません。\n\n'
                '0層ノードの算出方法には、実測または計算根拠を持つ適切な方法を設定してください。'
            )
        parent_index = get_parent_index(index)
        if parent_index is not None and flat_nodes[parent_index].calc_method == '合算':
            return False, (
                '親ノードが「合算」のため、このノードを「按分」には変更できません。\n\n'
                '「合算」は子ノードから親ノードを算出し、\n'
                '「按分」は親ノードから子ノードを算出するため、\n'
                'この組み合わせでは現行ルール上、計算構造が自己参照的になります。\n\n'
                '按分に変更する場合は、先に親ノードの算出方法を見直してください。'
            )
    if new_method == '合算':
        allocation_children = [
            child_index for child_index in get_direct_child_indices(index)
            if flat_nodes[child_index].calc_method == '按分'
        ]
        if allocation_children:
            child_text = '、'.join(f'{child_index + 1}行目「{flat_nodes[child_index].name}」' for child_index in allocation_children)
            return False, (
                '直属子に「按分」ノードがあるため、このノードを「合算」には変更できません。\n\n'
                f'按分子: {child_text}\n\n'
                '「合算」は子ノードから親ノードを算出し、\n'
                '「按分」は親ノードから子ノードを算出するため、\n'
                'この組み合わせでは現行ルール上、電力量を正常に決定できません。\n\n'
                '合算に変更する場合は、先に子ノードの算出方法やツリー構成を見直してください。'
            )
    return True, ''

def move_selected_nodes(indices:List[int], up:bool=True)->Tuple[bool, List[int], str]:
    selected = sorted(set(indices))
    if not selected:
        return False, [], ''
    blocks: List[List[int]] = []
    current: List[int] = []
    for index in selected:
        if current and index == current[-1] + 1:
            current.append(index)
        else:
            if current:
                blocks.append(current)
            current = [index]
    if current:
        blocks.append(current)

    if up:
        if blocks[0][0] <= 0:
            return False, selected, '一番上のノードはこれ以上上へ移動できません。'
        new_selected: List[int] = []
        for block in blocks:
            before_index = block[0] - 1
            before_node = flat_nodes.pop(before_index)
            insert_index = block[-1]
            flat_nodes.insert(insert_index, before_node)
            new_selected.extend(index - 1 for index in block)
        return True, sorted(new_selected), ''
    if blocks[-1][-1] >= len(flat_nodes) - 1:
        return False, selected, '一番下のノードはこれ以上下へ移動できません。'
    new_selected: List[int] = []
    for block in reversed(blocks):
        after_index = block[-1] + 1
        after_node = flat_nodes.pop(after_index)
        insert_index = block[0]
        flat_nodes.insert(insert_index, after_node)
        new_selected.extend(index + 1 for index in block)
    return True, sorted(new_selected), ''

def change_subtree_depth(index:int, increase:bool=True)->bool:
    current_depth = flat_nodes[index].depth
    delta = 1 if increase else -1
    new_depth = current_depth + delta
    if new_depth < 0 or new_depth > MAX_DEPTH:
        return False
    flat_nodes[index].depth = new_depth
    return True

def change_selected_nodes_depth(indices:List[int], increase:bool=True)->Tuple[bool, str]:
    if not indices:
        return False, ''
    if not increase and any(flat_nodes[index].depth <= 0 for index in indices):
        return False, '0層より上へ変更できないノードが含まれています。'
    if increase and any(flat_nodes[index].depth >= MAX_DEPTH for index in indices):
        return False, f'{MAX_DEPTH}層より下へ変更できないノードが含まれています。'
    return True, ''

def insert_node_after_selection(selected_index: Optional[int])->int:
    if selected_index is None:
        depth = 0
        pos = len(flat_nodes)
    else:
        depth = flat_nodes[selected_index].depth
        pos = get_subtree_end_index(selected_index)
    new = FlatNode('新規ノード','実測','1', '', 0, '', 0.0, depth)
    flat_nodes.insert(pos,new)
    return pos

def delete_selected_nodes(indices:List[int])->int:
    unique_indices = sorted(set(indices), reverse=True)
    for index in unique_indices:
        if 0 <= index < len(flat_nodes):
            del flat_nodes[index]
    return len(unique_indices)

def get_display_method(index:int)->str:
    node=flat_nodes[index]
    if node.calc_method != '按分':
        return node.calc_method
    state = get_node_estimation_state(index)
    if state == 'confirmed':
        return '残差算出（確定）'
    if state == 'inherited':
        return '残差算出（推定継承）'
    return '按分'

METHOD_ICON={'実測':'🧿','合算':'➕','按分':'📊','残差算出（確定）':'✓','残差算出（推定継承）':'≈'}

def method_with_icon(m):
    # ツリーのセルだけ短縮し、状態名・説明文・ツールチップは正式名称を使う。
    label = {'残差算出（確定）': '残差（確定）',
             '残差算出（推定継承）': '残差（推定継承）'}.get(m, m)
    return f"{METHOD_ICON.get(m,'')} {label}".strip()

def notes_with_icon(n):
    n=normalize_value(n); return f"📄 {n}" if n else ""

def format_ratio_unit_display(node: FlatNode) -> str:
    if node.calc_method != '按分':
        return ''
    unit = normalize_value(node.unit)
    try:
        if unit != '' and float(unit) == 0.0:
            return ''
    except (TypeError, ValueError):
        pass
    return unit

def show_text_window(title: str, body: str, copy_button: bool = False):
    top = tk.Toplevel(root)
    top.title(title)
    top.geometry('900x700')
    top.minsize(700, 500)

    frame = ttk.Frame(top)
    frame.pack(fill='both', expand=True, padx=8, pady=8)

    text = tk.Text(frame, wrap='word')
    vsb = ttk.Scrollbar(frame, orient='vertical', command=text.yview)
    text.configure(yscrollcommand=vsb.set)

    text.grid(row=0, column=0, sticky='nsew')
    vsb.grid(row=0, column=1, sticky='ns')

    frame.rowconfigure(0, weight=1)
    frame.columnconfigure(0, weight=1)

    text.insert('1.0', body)
    text.configure(state='disabled')

    def copy_to_clipboard():
        root.clipboard_clear()
        root.clipboard_append(body)
        root.update_idletasks()
        messagebox.showinfo(title, '全文をクリップボードにコピーしました。')

    button_frame = ttk.Frame(top)
    button_frame.pack(fill='x', padx=8, pady=(0, 8))
    ttk.Button(button_frame, text='閉じる', command=top.destroy).pack(side='right')
    if copy_button:
        ttk.Button(
            button_frame,
            text='クリップボードにコピー',
            command=copy_to_clipboard,
        ).pack(side='right', padx=(0, 8))

    return top

def show_help_usage():
    show_text_window('使い方・設計思想', get_help_usage_text() + '\n\n' + get_design_philosophy_text(), copy_button=True)


def show_ai_analysis_spec():
    show_text_window('AI解析用仕様', get_ai_analysis_spec_text(), copy_button=True)

def get_help_usage_text() -> str:
    return """【使い方】

■ あんぶんくんとは

あんぶんくんは、工場・事業所の電力系統をツリー構造として構造化し、実測・合算・按分によって、設備別・用途別・予算単位別の電力量配賦を支援するアプリです。

すべての設備を完全に実測するのではなく、限られた実測値、設備構成、ブレーカー定格電流、流量・生産量などの外部比率を組み合わせ、説明可能・再現可能な月次配賦を行います。

電力量の計算だけでなく、受電点、変圧器、盤、ブレーカー、設備、電気室、予算単位、用途分類などを関連付けた、設備管理・省エネ分析・AI解析のための構造化データとして利用できます。

起動時には、実測、合算、AT按分、外部比率按分、予算単位配賦の流れを確認できる公式サンプルデータを表示します。実際の計算を行う場合は、入力CSVを読み込んでサンプルデータを置き換えてください。同梱の sample フォルダにある3種類のサンプルCSVを読み込むと、起動時サンプルと同等の構成を再現できます。

■ 基本的な作業の流れ

通常は、次の順に操作します。

1. 「入力データをまとめて読み込む」を開く
2. 前回CSVまたは構成CSV、実測値・按分比率CSV、予算単位CSVを指定する
3. 「読み込み・計算」を実行する
4. 管理行を確認する
5. 分析CSVまたは分析Excelを出力する
6. 必要に応じてSankey図CSVを出力する

月次運用では、設備構成や組織に変更がなければ、前回出力した分析CSVまたは構成CSVからツリー構成・属性・設定を引き継げます。前回CSVの電力量や管理フラグを今回の計算結果として使うのではなく、対象月の実測値や按分比率を記録した量・比率CSVを読み込んで再計算します。予算単位CSVは変更頻度が低いマスター的な情報であるため、前回正常に読み込んだCSVを次回起動時に自動読込できます。必要に応じて、入力データの読み込み画面や「読込」メニューから別の予算単位CSVへ変更できます。
各CSVはドラッグ＆ドロップ、または「ファイルを選択」ボタンで指定できます。実測値・按分比率CSVは複数指定できます。構成CSVと予算単位CSVは、変更がなければ現在使用中のものを継続利用できます。読み込み前に、ファイル名、更新日時、保存場所を確認してください。
個別に構成CSV、実測値・按分比率CSV、予算単位CSVだけを読み直したい場合は、「読込」メニューから個別読込を利用できます。ドラッグ＆ドロップが利用できない環境でも、ファイル選択ボタンから同じ操作ができます。

■ CSVの役割

ここでいう「構成CSV」「量・比率CSV」「予算単位CSV」「分析CSV」「Sankey図CSV」「SankeyログCSV」は、固定されたファイル名ではなく、データの役割を表す名称です。実際のファイル名は、工場名、対象年月、部署名などに合わせて変更できます。あんぶんくんで使用する入力データは一般的なCSV形式です。専用形式に閉じず、Excelなど任意のソフトウェアから参照・編集できます。

構成CSVは、受電点から末端設備・仮想ノードまでのツリー構造を定義します。主な項目は、階層、ノード名、算出方法、AT、計量名称、予算単位コード、電気室、変圧器、分類、属性（Sankey分類）、備考、参考計量名称などです。あんぶんくんが出力した分析CSVにも、その時点の構成・属性・設定・計算結果が保存されているため、翌月の構成CSVとして読み込めます。ただし、読み込み時に引き継ぐのは構成・属性・設定であり、前回CSVに記録された電力量、按分計算結果、管理フラグなどは今回の計算結果として使用しません。読込後に量・比率CSVなどを参照して再計算します。

量・比率CSVは、実測電力量、按分比率、参考値を呼び出すためのデータです。計量名称をキーとして、実測ノードでは電力量を、按分ノードでは流量、生産量、稼働率、人数、面積、固定比率、システム別電力量などを呼び出します。数値列は「量・比率」を基本としますが、構成CSVや分析CSVではない簡易マスターでは「按分比率」列も同じ値として読み込めます。単位が空欄の場合も、単位なしの按分比率として利用できます。量・比率に値が入力されているのに有限の数値として読めない場合は、0へ自動変換せず読込エラーにします。「根拠・計算条件」列がある場合は、計算式、対象期間、除外条件、補正条件、暫定値である理由などを記録できます。この列はアプリの計算には使用せず、現在のマスタ表示や分析CSV・分析Excelにも出力しません。AI解析で利用する場合は、分析CSV・分析Excelとは別に量・比率CSVも渡してください。

携帯ロガーなどで短期間だけ測定した値を外部で30日換算し、按分単位kWhの按分比率として量・比率CSVに登録すると、現在の按分結果との差を参考列で比較できます。ただし、短期測定は必ず行う工程ではありません。盤の開閉や充電部近傍での作業を伴う場合があるため、安全性、設備への影響、作業工数、社内ルールを考慮して実施を判断してください。設備の運転特性が季節や年度末などで変わる場合は、過去の測定実績、設備運転条件、既存データなどをもとに、夏季、冬季、中間期、年度末などの比率を量・比率CSV側で用意し、対象期間に合うCSVや計量名称を選んで使い分ける運用も可能です。あんぶんくんが季節を自動判断して比率を切り替えるわけではありません。

予算単位CSVは、予算単位コードと予算単位名称の対応表です。原則として、予算単位コードは電力量を最終的に受け持つ末端ノードまたは仮想ノードに設定します。予算単位CSVは構成CSVへ埋め込まず、外部CSVとして参照します。これにより、名称の表記揺れを抑え、将来の組織マスターや原価センターマスターとの接続にも備えます。

分析CSV・分析Excelは、アプリで再計算した電力量、按分比率、管理列、参考列、対象年月、出力日時などを含む分析用データです。AIやBIが親子関係を扱いやすいよう、ノードID、親ノードID、親ノード名、ノードパス、ノードIDパス、末端判定、子ノード数も出力します。ノードIDは、その出力ファイル内でのみ有効な一時IDです。翌月や別ファイルで同じ設備に同じIDが付くことは保証されません。

Sankey図CSVは、配賦結果を「電源 → 電源ミックス → 電気室 → 用途 → 予算単位」という非負の流れに変換した描画用データです。補器・損失がある場合は、「電源ミックス → 補器・損失」の枝も出力されます。SankeyログCSVには、負値除外、しきい値除外、その他化、補器・損失、警告、集計条件などを記録します。Sankey図CSVは元の分析CSVを置き換えるものではなく、全体の太い流れを把握するための要約データです。

■ 算出方法

実測は、計量名称に対応する値を量・比率CSVから電力量として呼び出します。計量名称が空欄、または量・比率CSVに存在しない場合は0kWhとなり、管理列に呼出不可が表示されます。実測という名称であっても、物理メーター1台の値とは限りません。量・比率マスターで複数設備を合計した「システム電力量」を、仮想ノードで実測値として呼び出すこともできます。

合算は、直下の子ノードの電力量を合計します。合算ノードの直下に按分ノードが含まれる状態は、子から親を決める合算と、親から子を決める按分が同じ親子関係で自己参照的になるため、現行ルールではクリティカルな不整合として扱います。通常の画面操作ではこの構成を作れないようにし、CSVから読み込まれた場合は読込時警告、管理列表示、出力停止で可視化します。アプリは既存ノードの算出方法を自動変更しないため、算出方法やツリー構成の変更はユーザーが明示的に行ってください。

按分は、親ノードの電力量から、実測・合算済みの子ノードの電力量を差し引き、残った電力量を按分比率に応じて配分します。親を持たない0層ノードは、按分に必要な親側の電力量が存在しないため「按分」にはできません。計量名称が空欄の場合はATを暫定的な按分比率として使用し、計量名称が入力されている場合は量・比率CSVから外部比率と単位を呼び出します。按分対象があるのに按分比率が有限数でない場合や、比率合計が0以下の場合は、按分係数を構成できないためクリティカルな不整合として扱います。按分ノードの計量名称を呼び出せない場合、按分比率は0として扱われるため、量・比率CSV側も確認してください。

残差算出は、同じ親配下に按分ノードが1つだけある場合の自動状態表示です。正式名称は、親が確定していれば「残差算出（確定）」、上流の推定に依存していれば「残差算出（推定継承）」です。この段では新しい比率推定を発生させません。実測・正常な合算は確定境界です。確定残差の子も確定残差となり、途中で複数先への比率按分が入ると新しい推定依存が発生します。内部算出方法とCSV・Excel保存値は「按分」のままです。旧データの「按分(確定)」や残差算出の表示名も読込時に「按分」として扱います。

■ 仮想ノード・参考値・予約語

仮想ノードは、物理的なブレーカーや設備が存在しなくても、配賦や分析上必要なまとまりを表すためのノードです。部門別・予算単位別の仮想配賦先、複数設備のシステム化、親子差分の表面化、大型設備や共通設備停止時の影響範囲整理などに使います。物理構成を残しながら、配賦計算だけを仮想システムノードで行う場合、元の実在設備ノードを0kWh扱いにすることがあります。0kWhであることだけを理由に未使用設備と判断しないでください。

参考計量名称・参考値・参考単位は、配賦計算には使用しない補助情報です。実在設備ノードの電力量を0kWh扱いにしつつ、参考計量名称から実際のメーター値を呼び出すことで、システム合計の確認、省エネ診断、異常監視、AI解析に利用できます。参考値は、実測、合算、按分、親子差分、Sankey図CSV集計には使用しません。

按分単位がkWhの外部比率按分ノードでは、按分比率として入力されたkWh値と、実際に按分計算で算出された電力量との差を参考列に表示します。携帯ロガー等の短期実測値を外部で30日換算して按分比率に使う場合などに比較できますが、アプリはそのkWh値が30日換算実測値であることを保証しません。差が大きい場合でも異常とは限らず、按分根拠の見直し、必要に応じた再測定、常設計測への切替などを検討するための参考情報です。

予約語「集約」は子ノードを持つ構造上のまとめノードです。子ノードを持つノードは「集約」⇔「電源」だけ編集できます。明示された「電源」は表示・出力・Sankey集計でも保持し、それ以外は有効予算単位コードを「集約」として扱いますが、ノードに保存された予算単位コードやSankey分類の入力値自体は自動変更しません。編集後に再び末端ノードへ戻れば、保存されていた値を再利用できます。予約語「電源」は供給側の電源ノードで、Sankey図では電力量がマイナスの場合も絶対値を正の供給電力量として使用します。電源ノードは属性（Sankey分類）が供給側ラベルになるため、空欄のままではSankey図CSVを出力できません。

■ アプリ内で監視していること

あんぶんくんは、計算不能につながる構造的不整合と、計算はできるが現場確認が必要な物理的不自然さを分けて監視しています。管理列は異常を断定するものではなく、専門家が確認すべき箇所を見つけるための補助表示です。実際の列は、管理（親子差大）、管理（過大電力）、管理（負按分）、管理（確認事項）です。

1つ目は、計算が成立するかの監視です。これは数学的整合性の監視であり、正常な電力量として扱ってよいかを見ています。具体的には、親子関係の循環、存在しない親への参照、親階層が欠けているノード、0層なのに按分になっているノード、合算ノードの直属子に按分ノードがある構造、計算依存関係の循環、按分比率がNaN・Inf・数値不能である状態、按分対象があるのに比率合計が0以下である状態を監視しています。

特に重要なのは、合算と按分の向きが衝突する構造です。合算は子ノードから親ノードを決め、按分は親ノードから子ノードを決めます。これが同じ親子関係で混ざると、電力量を決めるための式が閉じず、値が一意に定まらない場合があります。そのため、アプリでは通常の確認フラグではなく、計算不能につながるクリティカル不整合として扱います。

2つ目は、計算はできるが物理的に怪しい値の監視です。これは物理的妥当性の監視です。親ノードの電力量と直属子ノード合計の差がしきい値以上なら管理（親子差大）に表示します。ATから見た理論最大電力量に対して算出電力量が大きすぎる場合は、管理（過大電力）に表示します。この判定は三相210V、24時間×30日連続運転を基準にした簡易判定であり、単相、電圧差、力率、負荷率、実運転時間を反映した厳密な容量評価ではありません。按分結果が設定しきい値以下の負値になる場合は、管理（負按分）に表示します。

管理（確認事項）には、実測ノードの計量名称の空欄・呼出不可、外部比率按分ノードの按分比率呼出不可、電力量がある末端ノードの予算単位の未設定・呼出不可、親AT小、異予算按分、合算候補、クリティカル不整合などをまとめて表示します。親AT小は、親ノードのATが直属子の最大ATより小さい場合の簡易確認であり、保護協調不良の断定ではありません。

■ 推定指標：点・群・経路・領域

推定指標列は起動時には非表示です。「推定指標列 表示/非表示」で表示できます。画面の列順は、計測評価対象外、個別推定量、下流確定量、下流未確定量、末端理論最大値、経路推定累積度、計測推奨境界です。CSV・Excelの列順は従来どおりです。

確定境界は、実測・合算・残差算出（確定）です。配賦上の値に自由度が残らないことを意味し、実際にメーターで測ったかどうかでは区別しません。通常按分と残差算出（推定継承）は上流からの帰属未確定性を継承します。確定性は算出方法の表示と全推定指標で共通判定します。

点：個別推定量は、そのノード自身に現在割り当てられている推定電力量(kWh)です。計測評価対象外でない未確定按分を対象とし、AT・外部比率を問わず既存の表示しきい値を適用します。
群：下流確定量D_iは、直属子がconfirmedなら子の電力量を、そうでなければ子のDを加算します。最初の確定境界で枝を打ち切る確定フロンティアなので、合算300の下に実測100・200があっても300だけを数えます。末端のD=0も意味のある値です。下流未確定量U_i = E_i - D_iは、その按分ノード配下でまだ確定値により説明されていない量です。通常按分・外部比率按分・推定継承残差で算出し、confirmedでは対象外です。下流未確定量は兄弟の合計ではありません。入れ子の領域は重なるため全ノードのUを単純合計しないでください。
経路：経路推定累積度は、最後の確定境界から末端まで推定をどの程度、何段重ねてきたかを表す無次元指標です。allocatedの段で score_i = score_parent + log10(1 + max(U_i, 0) / U0) とし、U0は既存の基準量設定を使用します。実測・合算・残差算出（確定）で0へリセットし、残差算出（推定継承）は加算せず継承します。外部比率按分も対象です。負按分・負のU・算出不能な上流値がある経路は算出不能とし、次の確定境界でリセットします。各段の規模係数の積の常用対数に相当し、誤差率や統計的な信頼区間ではありません。
領域：領域未確定量は、上流で確定している電力量から、その下流の確定フロンティアの電力量を差し引いた残り（R = E_b - D_b）です。複数の按分先が共有する未閉領域全体の値であり、個々のノードを起点とする下流未確定量とは区別します。診断対象の推定幅はこの領域未確定量に対応します。末端理論最大値M_tは、直属子のない未確定な按分ノードだけを対象とします。最も近いconfirmedの祖先bを上流確定境界とし、M_t = b.energy - D_bで、領域未確定量に対応します。同じ未閉領域の末端は原則同じ最大値を持ちます。上流1000、下流フロンティアが実測300・合算200なら、残る按分末端A/B/Cはそれぞれ0～500kWhです。同時に全末端が500になるわけではなく、未確定量全体に保存則があります。予測値や統計的信頼区間ではありません。確定祖先がない場合やNaN・Inf等は算出不能です。

計測推奨境界は、診断対象の推定幅がしきい値（初期値2000kWh）を超える場合に、診断上の末端から上流をたどり、下流未確定量が同しきい値を厳密に超える最初の非除外・未確定按分へ●を表示します。AT・外部比率とも候補です。推定継承残差は通過可能、confirmedで探索終了、同じ候補は1点に統合します。

下流確定量・下流未確定量は全階層の未確定按分で表示します。下流未確定量には表示しきい値を適用しますが、負値は常時表示します。末端理論最大値は0・負値もしきい値で隠さず表示します。経路推定累積度は従来どおり末端のみ表示し、表示しきい値を適用します。CSV・Excelでは個別推定量の既存しきい値を維持し、それ以外の数値は対象ノードのしきい値未満・0・負値も出力します。計測推奨境界は該当=1、非該当=0です。空欄は対象外・算出不能、または画面の表示しきい値未満を含みます。下流未確定量・末端理論最大値の負値は管理（確認事項）にも通知し、期間不一致、計測境界不整合、構造不整合等の調査材料として保持します。

すべてのブレーカーを実測化することが目的ではありません。末端按分ノードを含む未閉領域を定量化し、計測効果・工事費・停電影響・施工性を比較しながら、必要十分な大きさまで未閉領域を縮小することが目的です。計測推奨境界は具体的なCT設置位置を自動決定するものではありません。フラグ位置またはそれより下流で、既設メーター、多回路モニター、CT空きチャンネル、通信設備、兄弟回路の測定や全子回路の合算を含め、最も施工性・費用対効果のよい確定境界の作り方を検討する目安です。

計測推奨境界は、設置後に必ずしきい値以下になる数学的保証ではありません。新しい実測値は現在の推定値と異なる可能性があるため、設置後に再計算して下流未確定量と末端理論最大値の減少を再評価します。管理しきい値設定には、計測推奨境界のユニーク数と診断対象の推定幅の最大を表示します。境界数が少ないだけではデータ品質を保証せず、計測完了・投資停止を自動判定しません。これらは診断専用で、電力量計算・予算配賦へフィードバックしません。

■ 計測評価対象外・診断上の末端・出力

計測評価対象外は末端の按分ノードのセルをダブルクリックして□/☑を切り替えます。Undo/Redoに対応し、分析CSVで保存・復元します。除外ノードの推定指標は画面では隠しますが、電力量・予算配賦・確定性・管理通知は変えず、CSV・Excelには内部診断値を保持します。
非除外の構造末端は診断対象です。除外末端は最も近い非除外の未確定按分祖先へ集約し、同じ祖先は1対象に統合します。確定祖先に到達したら対象を作りません。外部比率の物理ブレーカーも除外しなければ計測候補です。
構造上の末端理論最大値と、診断上の内部末端の理論最大値は区別します。内部対象iの下流確定量D_i、最も近い上流確定境界bの残余R=E_b-D_bに対し、理論最小値D_i、理論最大値D_i+R、推定幅Rです。KPIは推定幅を使用し、対象間で合計しません。構造末端の元の末端理論最大値も別に保持します。
解析結果サマリーはKPI・計算統計・管理フラグ・設定と、その後に用語・前提・注意事項を表示します。推定幅算出不能、評価対象なし、未確定な診断対象なしを区別し、除外数・集約数を併記します。除外によるKPI低下は計測改善を意味せず、境界0でも投資完了とは自動判定しません。
PDF出力は同じサマリーデータを使用します。統合解析Excelはツリー、上位接続、Sankeyフロー、Sankeyログ、解析結果サマリーの5シートです。Sankey生成不能時は理由を記録します。翌月の構成引継ぎには分析CSVを使い、保存された電力量を再利用せず当月のマスタを適用します。

■ 測定位置の考え方

個別推定量が大きいノードでも、必ずそのノード自身の主幹にメーターを取り付ける必要はありません。既設の実測点を利用し、未実測の子回路へCTを追加して全子回路を実測化し、親ノードを「合算」で確定する方法も検討できます。合算では、物理的な子回路が対象範囲を漏れ・重複なくカバーし、同じ期間で集計できることを確認してください。流量按分などの仮想ノードとは区別します。

多回路モニターでは、1点目は通信線配線、通信機器のスペース確保と取付、電源・電圧要素取り込み、停電調整などの固定的な施工負担が大きく、2点目・3点目はCT追加中心で比較的施工しやすい場合があります。大きな主幹ブレーカー1個を測るより、既設モニターを利用して複数の子ブレーカーを測る方が容易な場合もあります。

推定指標は「どこへメーターを付けるか」を自動決定するものではなく、「どの推定領域を改善する価値が大きいか」を示します。推定指標、管理フラグ、既設メーター、多回路モニター、CT空きチャンネル、通信設備、停電可否、施工性、費用、予算単位を合わせて判断してください。既存データ、流量・生産量・運転時間などの外部比率、仮想ノード、ツリー構成の見直しも改善手段です。

異予算按分は、同じ親の残電力量を異なる予算単位に属するAT按分ノード間で配分している場合に、その群に属する各AT按分子ノードの管理（確認事項）へ繰り返し表示します。同じ群についての確認表示であり、表示件数が別々の群の数を意味するものではありません。原動配賦上の負担先に影響するため、対象の子回路の実測化、按分根拠、設備構成、予算単位を確認するための表示です。異常を断定するものではありません。

つまり、アプリ内では、値が一意に決まる構造か、決まった値が物理的に不自然でないか、計量名称・按分比率・予算単位などの根拠データが欠けていないかを監視しています。ただし、管理列は構造の正しさを証明するものではありません。特に、按分子だけで構成された階層では、不足や余分な按分ノードがあっても残差が按分対象内で再配分されるだけで、親子差大や負按分として表面化しない場合があります。フラグの有無だけで判断せず、図面、ブレーカー名称、設備台帳、予算単位、現場確認と合わせて確認してください。

■ 管理列が表示されたときの確認方法

管理列は、構造誤りを自動判定する機能ではありません。子ノードの不足、不要な子ノードの混入、計測範囲の不一致、入力値の誤り、按分条件の問題、未計測負荷、損失、計測境界差などによって生じる不自然な電力量を、全階層から探すための補助機能です。ただし、0層按分のように値を決める根拠が存在しない場合、合算親の直属子に按分がある場合、現行ルールで一意性を失う計算依存関係の閉ループがある場合、按分比率から係数を構成できない場合は、正常な計算そのものが成立しないクリティカル不整合として別に表示します。

基本的には、親ノードの電力量から、直属の実測・合算子ノードの合計を差し引いた残りを見ます。按分子がない場合は、親電力量と子ノード合計との差が親子差として現れます。按分子がある場合は、その残りが按分子へ配られるため、構造データの不整合が親子差ではなく、按分ノードの過大電力や負按分として現れることがあります。

親子差大が表示された場合は、本来存在する子ノードが抜けていないか、本来この親に属さない子ノードが入っていないか、親と子で計測範囲や対象期間が一致しているかを確認してください。あわせて、未計測負荷、補機・損失、計測境界差、実測値、計量名称の対応も確認候補です。子ノードがすべて実測・合算の場合、構造上の不足や過剰は親子差として表面化しやすくなります。ただし、設定されたkWhしきい値以上の場合のみ表示されるため、構造上の不整合が必ず表示されるわけではありません。

過大電力が表示された場合は、そのノード自身のAT、運転時間、電力量、計量名称、仮想ノード設定、按分比率を確認してください。この判定は三相210V、24時間×30日連続運転を基準とした簡易判定であり、単相回路、異なる電圧、実際の力率・負荷率・運転時間などを考慮した厳密な設備容量評価ではありません。特に按分ノードでは、本来存在する兄弟ノードが抜けた結果、その兄弟ノードが受け持つはずだった電力量まで吸収して過大になっている可能性があります。過大電力は、そのノード自身だけでなく、兄弟ノードの不足を示している場合があります。

負按分が表示された場合は、親ノード電力量より、実測・合算済みの子ノード合計が大きい可能性があります。同じ親配下に本来属さない実測・合算ノードが入っていないか、同じ設備や同じ実測値を二重登録していないか、親子で計測範囲や対象期間が一致しているか、実測値や計量名称が正しいか、親ノードの実測値または按分値が過小になっていないかを確認してください。負按分は、負になった按分ノード自身だけでなく、余分な実測・合算の兄弟ノードを疑う入口になります。ただし、不要な子ノードが追加されても、実測・合算子合計が親電力量を超えなければ、按分値が小さくなるだけで負按分にならない場合があります。

合算ノードでは、親ノード自身の電力量が直属子ノードの合計として再計算されます。そのため、本来あるべき合算子ノードが不足していても、その階層だけを見ると親子差は0になることがあります。合算ノードの子ノード不足は、その階層の親子差だけでは検出できないため、さらに上位階層の親子差、合算ノード自身の過大電力、合算ノード配下の管理フラグ、孫以下の親子関係を確認してください。合算ノードの妥当性は、その子ノードを親として同じ検証を再帰的に繰り返すことで確認します。

本来ある子ノードが不足している場合、不足した電力量は、親子差として残る、按分ノードが吸収する、合算親ノード自身が小さくなる、のいずれかになる可能性があります。そのため、親子差大、按分ノードの過大電力、上位階層の親子差などを確認します。不要な子ノードが入っている場合は、子合計を大きくする、按分可能な残差を小さくする、按分残差を負にする、合算親ノード自身を大きくする可能性があります。そのため、親子差大、負按分、過大電力、上位階層の親子差などを確認します。

構造が誤っていても、その誤った構造の中で電力量収支が成立している場合は、管理列にフラグが立たないことがあります。特に、不要な按分ノードの追加、按分ノードの不足、按分ノード間で残差が再配分されるだけの構造不整合は検出できない場合があります。一方で、合算親の直属子に按分がある構造は、値の異常ではなく計算モデルの循環として検出します。管理列は構造の正しさを証明するものではなく、専門家が確認すべき方向を示す補助情報として扱ってください。

■ 収支確認用の区間損失ノード

電源側と負荷側の収支を確認するため、0層に0kWhの収支ノードを置く方法があります。その直下に、マイナス値の電源ミックス、プラス値の負荷合計、按分比率1の区間損失ノードを置くと、電源と負荷の差額が区間損失ノードへ配賦されます。例えば、電源ミックスが－10,000kWh、負荷合計が＋9,500kWhの場合、差分の500kWhが区間損失ノードへ入ります。この値には、ケーブル損失、変圧器損失、電気室空調、制御電源、排水ポンプ、蓄電池コンテナ空調、計測境界差分、未計測負荷などが含まれる可能性があります。

■ 表示・編集

セルをダブルクリックすると、ノード名、AT、算出方法、計量名称、予算単位コード、属性、備考、参考計量名称などを編集できます。参考値と参考単位は、参考計量名称をキーとして量・比率CSVから呼び出すため、直接編集できません。全展開、指定階層まで表示、属性列・管理列・参考列の表示／非表示、ノード追加、削除、階層変更、上下移動、元に戻す、やり直しも行えます。CtrlクリックやShiftクリックで複数ノードを選択し、選択ノードだけを一括削除・階層変更・上下移動できます。複数選択中のノード追加は、フォーカスされている行を基準に追加します。削除は選択ノードだけが対象であり、親ノードを削除しても選択していない子ノードは自動削除されません。階層変更も選択ノードだけを変更し、選択していない子孫は追従しません。新規ノードは「実測・AT1・計量名称未設定・電力量0kWh」で追加され、計量名称または算出方法が設定されるまで管理列に呼出不可が表示されます。

編集中は、一時的な階層飛びや親階層の欠損を許容します。アプリは構造不整合を自動修正しません。計算前と出力前には共通の構造検証を行い、クリティカル不整合がある場合は電力量を「計算不能」として表示し、分析CSV・分析Excel・Sankey図CSVの出力を停止します。

■ AIへ渡す推奨データ

AI解析を行う場合は、AI解析用仕様、分析CSVまたは分析Excel、Sankey図CSV、量・比率CSV、必要に応じてSankeyログCSVを渡すことを推奨します。AIの回答は確定判断ではありません。現場状況、安全、品質、生産影響、設備仕様、法令、工事費、投資対効果を確認するための仮説として利用してください。

■ 動作環境・追加ライブラリ

配布されたEXEを使用する場合、通常は追加ライブラリのインストール操作は不要です。

Pythonファイルを直接起動する場合は、コマンドプロンプトで必要な追加ライブラリをインストールしてください。

Pythonの確認：
python --version

ドラッグ＆ドロップ機能：
python -m pip install tkinterdnd2

Excel出力機能：
python -m pip install openpyxl

まとめてインストールする場合：
python -m pip install tkinterdnd2 openpyxl

tkinterdnd2がインストールされていない場合もアプリは起動できますが、ドラッグ＆ドロップは利用できません。その場合は「ファイルを選択」ボタンを使用してください。

openpyxlがインストールされていない場合、Excel出力は利用できません。CSV出力など、その他の機能は利用できます。
"""

def get_design_philosophy_text() -> str:
    return """【設計思想】

■ あんぶんくんが目指すもの

あんぶんくんは、単に今月の電力量を各部門へ配るための計算ソフトではありません。

工場の電力系統、設備、用途、組織、予算単位、計測境界、算出方法、按分根拠を一つの計算可能なツリー構造として結び付け、現場、管理者、経営、DX、AIが共通のデータを基に議論できる状態を作ることを目指しています。

一言で表せば、「工場のエネルギー構造と現場知見を、見直し可能なデータ資産に変えるツール」です。

■ 全点メーター化と大まかな按分の間を埋める

すべてのブレーカーへ電力量計を設置することは、設置費、停電調整、通信、保守、校正、更新まで考えると、現実的でない場合があります。一方、面積、人数、固定比率などだけによる大まかな配賦では、実際の設備運用と乖離し、改善した部署の努力が配賦結果へ反映されないことがあります。

あんぶんくんは、実測できる部分は実測し、子ノードから積み上げられる部分は合算し、残る部分を設備情報や外部指標によって合理的に按分します。重要なのは、推定値を真値のように見せることではありません。どこが実測で、どこが合算で、どこが按分かを明示し、その根拠と計算条件を残し、同じ条件で再現し、後から改善できることです。

メーター不足を担当者判断の配賦ルールだけで補うと、設備更新、生産条件、組織変更、負荷構成の変化によって、年数を経るほど実際の電力使用実態からずれていくことがあります。そのたびに新しいルールを追加すると、計算は複雑になっても、物理的な電力の流れとの対応が見えにくくなります。

あんぶんくんが目指すのは、担当者ごとの配賦ルールを積み重ねることではなく、物理的な構成と電力の流れをできるだけ正しく表現することです。料金計算や経理提出用の調整は別工程で扱えるようにし、その前段として、受電点、変圧器、盤、ブレーカー、設備、仮想ノードの関係と、電力量の算出根拠を確認可能な形で整理します。

■ AT按分を改善の入口として使う

親ノードに1,000kWhがあり、実測・合算で確定した子ノードが400kWhある場合、残りの600kWhは未確定の按分子へ配分されます。計量名称が空欄の按分ノードでは、ブレーカー定格電流（AT）を暫定的な按分比率として使います。

AT按分は、メーターがないため仕方なく使う低精度な代替手段ではなく、最初に配電系統全体を欠落なくツリー化するための初期推定です。まず未計測箇所をAT按分などの合理的な方法で推定し、工場全体の構造を成立させます。その後、既存メーターによる実測値や、下位ノードから求められる合算値へ順次置き換えます。

さらに、あんぶんくんでは、個別推定量（点）、下流確定量・下流未確定量（群）、経路推定累積度（経路）、末端理論最大値・計測推奨境界（領域）を表示します。確定フロンティアに囲まれた未閉領域を定量化し、計測投資の効果と施工条件を比較できます。

精度改善が必要な箇所では、対象設備や現場条件に応じて、AT按分のまま使用する、既存情報から按分比率を見直す、携帯ロガーなどで短期測定する、常設電力メーターを設置する、といった方法を選択します。短期測定値を外部で30日換算し、量・比率CSVの按分比率として登録することもできます。設備の負荷特性が季節で変わる場合は、過去の測定実績、設備運転条件、既存データなどをもとに、夏季、冬季、中間期、年度末などの比率をCSV側で用意し、対象期間に応じて使い分ける運用もできます。

ただし、携帯ロガー等による短期測定は、常設計測の前に必ず通る工程ではありません。盤の開閉や充電部近傍での作業を伴う場合があるため、安全性、作業頻度、設備への影響、作業工数、必要な資格や社内手順を考慮して判断します。繰り返し測定が必要な箇所や、継続的に高い精度が必要な箇所では、何度も短期測定を行うより、最初から常設メーターを設置する方が合理的な場合もあります。

あんぶんくんは、測定を最大化するための仕組みではなく、必要な測定を選ぶための仕組みです。すべてを測定すること自体を目的にせず、必要十分な精度が得られている箇所では推定値を使い続ける判断もできます。全部を測るか、大まかな人数按分・面積按分だけで済ませるかの二択ではなく、必要な精度と測定コスト・安全性・作業負担のバランスを取りながら改善できることが、あんぶんくんの特徴の一つです。

推定指標は、点・群・経路・領域のどこに推定が残っているかを示します。すべてのブレーカーを実測化することが目的ではなく、計測効果・工事費・停電影響・施工性を比較し、未閉領域を必要十分な大きさへ縮小することが目的です。末端理論最大値は予測値や信頼区間ではありません。計測推奨境界はCT設置位置の自動決定ではなく、フラグ位置または下流で既設設備も含めて費用対効果のよい確定境界を作る目安です。設置後に再計算し、下流未確定量・末端理論最大値を再評価します。

この考え方では、SCADAやEMSとの無理な統合を前提にしません。リアルタイム監視や制御は専用システムに任せ、あんぶんくんは月次・期間単位で、物理的な電力ツリー、受電点の電力量、限られた実測値、外部比率を組み合わせ、説明可能な配賦構造を作るための軽量な分析レイヤーとして扱います。

逆に言えば、フラグを確認候補として受け止める前提なら、物理的な電力ツリーと受電点の電力量だけでも、末端ブレーカーまで初期推定を展開できます。この導入ハードルの低さと、後から精度を上げられることが、あんぶんくんの重要な特徴です。

一方で、全体をAT按分だけで配り切った状態は、最も粗い推定でありながら、フラグが最も立ちにくい状態でもあります。按分子だけで構成された階層では、不足や余分な按分ノードがあっても、残差が按分対象内で再配分されるだけで、親子差や負按分として表面化しない場合があります。だからこそ、AT按分は検証済みの答えではなく、改善の出発点として扱います。

また、入力途中のデータをそれらしい正常値へ自動補完しないことも重視します。構造変化によって親ノードが一時的に集約扱いになる場合でも、ユーザーが入力した予算単位コードやSankey分類そのものは消しません。量・比率CSVに不正な数値がある場合も、0やATへ置き換えず、読み込みを止めて修正を促します。

■ 配賦よりも、データモデルを重視する

従来の原動配賦は、「今月の電力量をどの部門へいくら配るか」が中心でした。あんぶんくんでは、その前提となる「工場の電力系統を、どのような構造として表現するか」を重視します。

配賦結果、Sankey図、設備検索、省エネ分析、AI解析は、すべてこの構造化されたツリーデータから生まれる成果です。価値の中心はプログラムそのものではなく、受電点から末端設備までの親子関係と、各ノードの意味、計算根拠、設備属性を蓄積したデータにあります。

■ 数十個の属人的な根拠から、数千・数万個の合理的な根拠へ

従来は、担当者が作成したExcelの中に、少数の大きな配賦式や個別判断が置かれ、その中身を作成者以外が理解しにくいことがありました。あんぶんくんでは、受電点、変圧器、盤、ブレーカー、設備、仮想ノードごとに、親子関係と算出方法を設定します。ノード数が増えること自体が目的ではありません。大きく曖昧な計算根拠を、細かく分解された合理的で確認可能な根拠に置き換えることが目的です。

■ 物理構成と配賦単位を分ける

物理的なブレーカー構成と、原価配賦や省エネ分析で見たい単位は、必ずしも一致しません。あんぶんくんでは、実在設備をツリー上に残しながら、仮想ノードによって用途・システム単位へ再構成できます。これにより、物理設備台帳としての正しさ、原価配賦上の分かりやすさ、省エネ分析上のまとまりを両立させます。

例えば空調では、室内機ブレーカー、室外機ブレーカー、対応する部屋名称、面積、容積、用途などを結び付けることで、部屋別の空調電力量を整理できます。室外機の電力量を、対応する室内機、部屋面積、容積、能力、運転時間などで按分すれば、kWh/m2、kWh/m3、用途別原単位などの分析につなげられます。これにより、断熱、外調機の調整、未使用室の運転、設定温度、フィルター、ゾーニングなど、現場で検討すべき対策候補を、設備構造と結び付けて議論できます。

■ 親子差分を隠さない

親ノードの実測値と子ノード合計が一致しない場合、その差を単なる誤差として消してしまうと、未計測負荷、補機電力、損失、計測境界の違いが見えなくなります。あんぶんくんでは、親子差を管理列で表示し、必要に応じて仮想損失ノードとして明示します。親子差は必ずしも異常ではありません。しかし、差が存在すること自体を表面化し、説明可能な値として扱うことが重要です。

子ノード不足は親子差や按分ノードの過大電力として、余分な子ノードは親子差や負按分として現れることがあります。合算ノードの構造不整合は、その階層ではなく上位階層に現れる場合があります。ただし、合算親の直属子に按分がある場合は、子→親と親→子の計算方向が同じ親子関係で自己参照的になり、現行ルールでは電力量を一意に決定できないクリティカル不整合として扱います。0層按分や親階層なしのように値を決める根拠が存在しない構造も、同じくクリティカル不整合です。各ノードの直属親子関係を局所的に確認し、それをツリー全体で再帰的に繰り返すことが重要です。管理列は構造の正しさを証明するものではなく、専門家が確認すべき方向を示す補助情報です。

■ 専門家の判断を知識資産に変える

あんぶんくんは、アプリを導入すれば自動的に正しいツリーが作られるものではありません。どこを実測とするか、どこを合算するか、どこを按分するか、どの設備をどの親へ置くか、どの外部比率を使うかは、電気系統と設備運用を理解した担当者が判断する必要があります。本ツールは専門家を置き換えるのではなく、その判断を、ツリー構造、算出方法、計量名称、按分比率、備考、量・比率CSV側の根拠・計算条件、管理列として残します。編集中は人間が明示的に選択したノードだけを変更し、一時的な不整合を許容します。完成データとして出力する段階でツリー全体の整合性を検証し、コンピューターは不整合を検出しても算出方法や構造を自動変更せず、計算モデルの意味を変更する判断は人間に返します。特に、計算式から電力量 x が一意に決まらない状態は、通常警告ではなくクリティカル不整合として扱います。

■ CSVとExcelを採用する理由

専用形式に閉じ込めず、CSVとExcelを基本とするのは、入力、計算条件、出力結果を人間が確認できる状態で残すためです。元データと結果をExcelや手計算で追跡できることを重視し、計算をブラックボックスにしません。将来、別のアプリやデータ基盤へ移行する場合も、CSVとして残したツリーデータを利用できます。

前月から引き継ぐのは答えではなく、答えを作るための構造です。分析CSVにはその月の計算状態を確認するスナップショットとしての意味がありますが、翌月に読み込むときは、構成・属性・設定を引き継ぎ、新しい実測値・按分比率から再計算します。

構成CSV、量・比率CSV、予算単位CSVは、役割や更新頻度が異なるため分けて管理します。予算単位CSVは前回使用したファイルを自動読込できますが、これは3種類のCSVを統合するものではなく、データは分離したまま人間の操作だけを減らすための仕組みです。

■ 電力量配賦を設備管理へつなげる

配賦のために整備したツリーは、設備管理にも利用できます。設備名やブレーカー名から給電元を調べる、対象変圧器や盤の配下を確認する、停電影響範囲を確認する、大型設備停止時に影響する部署を確認する、といった用途に展開できます。

実際に、電気設備更新工事の打ち合わせ中、ブレーカー追加工事のためにある電気室内の変圧器を一時停止する必要が生じた際、あんぶんくんの分析Excelから、その変圧器の停止で影響を受ける配下ブレーカーを、数百個ある末端ブレーカーまでその場で一覧化できた事例があります。末端ブレーカーには予算単位も紐づいていたため、停止調整が必要な関係部署や連絡先を検討する際の参考情報としても利用できました。

これは、あんぶんくんが配賦結果だけを保存するのではなく、変圧器、盤、ブレーカー、末端負荷、予算単位、属性がつながった「集計可能な構造」を保存しているためです。一度構造化した電気系統データは、原動配賦だけでなく、工事計画、停電範囲確認、停止調整、設備影響範囲の確認にも再利用できます。ただし、正式な停電調整先を自動決定したり、関係者へ自動連絡したり、停電計画書を自動生成する機能ではありません。

■ Sankey図の位置付け

Sankey図は、複雑なツリーを視覚的に要約するための派生表現です。Sankey図だけでは、按分根拠、管理列、個別設備、除外された負値などは確認できません。そのため、Sankey図を入口として全体の流れを把握し、詳細は分析CSV・分析Excelへ戻って確認する運用を前提とします。

■ AI時代のセマンティックレイヤー

AIが工場データを解析するには、数値だけでなく、その数値が何を意味するかを理解できる情報が必要です。あんぶんくんでは、設備の親子関係、実在ノードか仮想ノードか、実測・合算・按分の区別、按分根拠、計測境界、用途、予算単位、参考実測値、管理上の注意点を一つの構造へ結び付けます。

■ 将来像

現在の主対象はkWhによる電力量配賦です。将来的には、ガス、水、蒸気、圧縮空気、冷温水、温度、面積、製造数量、生産計画、設備状態、費用情報などを組み合わせることで、工場専用のAI解析基盤へ発展できる可能性があります。ただし、現行アプリがそれらを自動計算するわけではありません。

■ 注意事項

配賦結果には、実測値だけでなく推定値が含まれます。結果は、入力データ、設備構成、計測境界、按分比率、対象期間、運用条件に依存し、真値を保証するものではありません。重要な原価判断、設備投資、安全・保安上の判断では、元資料、現場状況、設備仕様、専門家の確認と合わせて使用してください。
"""

def get_ai_analysis_spec_text() -> str:
    return """【AI解析用仕様】

あなたは、電力量配賦アプリ「あんぶんくん」の出力データを解析するAIです。以下の仕様を前提として、CSVまたはExcelを解釈してください。

■ 最初に確認すること

解析の冒頭で、読み込んだファイルの種類、対象年月、データ件数、複数月を含む場合は対象年月の一覧と月別件数、対象年月が空欄の行数を確認し、明示してください。「対象年月」列を優先し、「出力日時」を対象年月として扱わないでください。対象年月列が存在しない場合は、「対象年月列は確認できません」と明記してください。

■ データの基本構造

あんぶんくんは、受配電系統を親子関係のあるツリーで表現します。分析CSV・分析Excelに親ノードIDがある場合は、親子関係の確認に親ノードIDを優先してください。親ノードIDがない場合は、階層と行順から親子関係を読み取ってください。ノードIDは出力ファイル内だけで一意な一時IDであり、設備の永続IDではありません。

分析CSVは、その月の構成・設定・属性・計算結果を含むスナップショットです。翌月の入力として読み込む場合は、前回の電力量や管理フラグを今回値として使うのではなく、構成・設定・属性を引き継ぎ、新しい量・比率CSVなどから再計算する前提で解釈してください。子ノードを持つノードは、明示された「電源」を出力・再読込でも保持し、それ以外の有効予算単位コードは構造上の派生値「集約」とします。電源指定は算出方法・確定性・推定幅を変更しません。祖先・子孫の電源指定、同じ実測計量名称の電源指定は管理上の重複候補であり、クリティカル不整合ではありません。供給範囲の一致を完全に自動判定するものではなく、自動除外もしません。

■ ファイル種別の判定

ファイル名だけで種別を判断せず、ヘッダーと内容から判断してください。階層、ノード名、算出方法、AT、計量名称などを持つ場合は構成データまたは分析データ、対象年月、出力日時、管理列、参考列、再計算後の電力量を持つ場合は分析データ、計量名称、量・比率、単位、根拠・計算条件を中心に持つ場合は量・比率データ、予算単位コード、予算単位名称を中心に持つ場合は予算単位データ、source_id、target_id、valueなどを持つ場合はSankeyリンクデータ、負値除外、しきい値、その他化、補器・損失、警告などを記録する場合はSankeyログデータの可能性が高いです。判断できない場合は断定せず、候補と確認項目を示してください。

■ 算出方法の解釈

実測は量・比率CSVの計量名称に対応する電力量を使用します。ただし、物理メーター1台の値とは限りません。合算は直下子ノードの電力量を合計した値です。按分は親ノードの電力量から実測・合算済みの子ノードを差し引いた残りを、按分比率に応じて配分した推定値です。按分比率は電力量そのものではありません。単位がkWhでも、それが最終電力量とは限りません。残差算出（確定）・残差算出（推定継承）は自動状態表示であり、内部とCSV・Excelの算出方法は按分です。旧「按分(確定)」も按分として読み込みます。

内部状態confirmedは実測・合算・確定残差、allocatedは複数の按分先への比率推定、inheritedは親の推定を引き継ぐ単一の残差按分、unavailableは判定できない状態です。inheritedでは新しい推定を経路推定累積度へ加算せず、confirmedでは累積度を0へ戻します。

あんぶんくんでは、計算系を概念的に x = Mm + Gx + PRDx と見なし、(I - G - PRD)x = Mm に整理したとき、電力量 x が一意に決まることを正常な計算構造の条件とします。巨大な密行列を毎回作るのではなく、現行の実測・合算・按分ルールについて、各ノードに値を決定する根拠が存在すること、および一意性を失う自己参照的な閉ループがないことを、親子関係、算出方法、値の依存関係、按分比率から構造的に検証します。

合算親の直属子に按分ノードがある場合は、通常の数値確認フラグではなくクリティカル不整合です。合算は子ノードから親ノードを算出し、按分は親ノードから子ノードを算出するため、同じ親子関係で共存すると P = S + A、A = P - S のように絶対値を決める情報が失われます。0層按分は親となる電力量が存在しないためクリティカル不整合です。親子参照の循環、現行ルールで一意性を失う計算依存関係の閉ループ、按分対象があるのに按分比率が有限数でない、または比率合計が0以下である状態も、正常な計算構造として扱いません。

■ AT・仮想ノード・参考値

ATは通常、ブレーカー等の定格電流を表します。計量名称が空欄の按分ノードでは、ATが暫定的な按分比率として使われます。仮想ノードのATを、単独の実在ブレーカー定格と即断しないでください。

仮想ノードには、仮想配賦ノード、仮想システムノード、仮想損失ノード、影響範囲を表す仮想ノードがあります。電力量0kWhの実在設備ノードがあっても、未使用設備とは限りません。

参考計量名称、参考値、参考単位は、配賦計算に使用しない補助情報です。参考値を電力量列へ加算しないでください。二重計上になります。

参考_按分kWh差は、按分単位がkWhの外部比率按分ノードについて、按分比率として入力された値と実際の算出電力量の差を見るための参考情報です。異常フラグではなく、差が大きいことだけで設備異常と断定しないでください。短期実測値の代表性、季節差、生産条件、曜日構成、按分根拠の見直し、必要に応じた再測定、常設計測への切替などを検討する材料として扱ってください。

■ 量・比率CSVの根拠・計算条件

量・比率CSVに「根拠・計算条件」列がある場合は、計量名称をキーとして分析CSVのノードと関連付けてください。アプリはこの列を計算に使用しませんが、AIは按分根拠の妥当性、不確実性、改善余地の確認に使用してください。量・比率CSVが提供されていない場合は、詳しい根拠を不明として扱い、推測で補わないでください。量・比率CSVの量・比率に不正な数値がある場合、アプリは0へ自動変換せず読込エラーにします。

■ 予算単位・電源の符号

予算単位コードは、原則として末端ノードまたは仮想配賦ノードに設定されます。上位ノードと末端ノードを重ねて合計すると、二重計上になる可能性があります。予算単位コードが「集約」のノードは構造上のまとめとして、「電源」のノードは供給側として扱ってください。電力量がマイナスでも、需要側の負荷や異常な負按分とは判断しないでください。Sankey図CSVでは、電源ノードの電力量は絶対値で扱われ、属性（Sankey分類）が供給側ラベルになります。

■ 収支確認用の区間損失モデル

0kWhの収支ノード配下に、マイナスの電源、プラスの負荷、按分比率1の区間損失ノードを置く場合があります。区間損失ノードの値は、ケーブル損失、変圧器損失、電気室空調、制御電源、排水ポンプ、オンサイト電源の変換損失、計測境界差分、未計測負荷などを含む可能性があります。通常負荷や入力ミスと即断しないでください。

■ アプリ内で監視していること

あんぶんくんは、計算不能につながる構造的不整合と、計算はできるが現場確認が必要な物理的不自然さを分けて監視しています。管理列は異常の断定ではなく、確認候補です。実際の列は、管理（親子差大）、管理（過大電力）、管理（負按分）、管理（確認事項）です。

計算が成立するかの監視では、親子関係の循環、存在しない親への参照、親階層が欠けているノード、0層按分、合算ノードの直属子に按分ノードがある構造、計算依存関係の循環、有限数ではない按分比率、按分比率合計が0以下の状態を見ます。これらは、値を決める根拠がない、電力量を一意に決定できない、または按分係数を構成できない状態であり、クリティカル不整合として通常の確認フラグより優先して扱います。

物理的妥当性の監視では、親ノードと直属子合計の差を見る親子差大、ATから見た理論最大電力量に対する過大電力、按分結果が負になる負按分、親ATが直属子最大ATより小さい親AT小、計量名称・按分比率・予算単位の呼出不可、異予算按分、合算候補を表示します。過大電力は三相210V、24時間×30日連続運転を基準とした簡易判定であり、単相、電圧差、力率、負荷率、実運転時間を反映した厳密な容量評価ではありません。各理由を確認し、実測追加、外部比率追加、流量・生産量・運転時間の利用、補正比率、仮想ノード、親子構成の見直しを検討してください。

管理（確認事項）に「計算不能」や「構造エラー:合算子に按分」がある場合は、通常の親子差大、過大電力、負按分より重大です。その配下や上位の電力量を確定値として扱う前に、構造、算出方法、按分比率の修正を優先してください。

0層按分や階層欠損、例えば親となる上位階層が存在しないノードもクリティカル不整合です。分析CSVにクリティカル不整合が残っている場合、その配下や関連する上位ノードの電力量を確定値として扱わず、まずツリー構造、算出方法、按分比率の修正を優先してください。

■ 推定指標：点・群・経路・領域

推定指標列は起動時には非表示です。「推定指標列 表示/非表示」で表示できます。画面の列順は、計測評価対象外、個別推定量、下流確定量、下流未確定量、末端理論最大値、経路推定累積度、計測推奨境界です。CSV・Excelの列順は従来どおりです。

確定境界は、実測・合算・残差算出（確定）です。配賦上の値に自由度が残らないことを意味し、実際にメーターで測ったかどうかでは区別しません。通常按分と残差算出（推定継承）は上流からの帰属未確定性を継承します。確定性は算出方法の表示と全推定指標で共通判定します。

点：個別推定量は、そのノード自身に現在割り当てられている推定電力量(kWh)です。計測評価対象外でない未確定按分を対象とし、AT・外部比率を問わず既存の表示しきい値を適用します。
群：下流確定量D_iは、直属子がconfirmedなら子の電力量を、そうでなければ子のDを加算します。最初の確定境界で枝を打ち切る確定フロンティアなので、合算300の下に実測100・200があっても300だけを数えます。末端のD=0も意味のある値です。下流未確定量U_i = E_i - D_iは、その按分ノード配下でまだ確定値により説明されていない量です。通常按分・外部比率按分・推定継承残差で算出し、confirmedでは対象外です。下流未確定量は兄弟の合計ではありません。入れ子の領域は重なるため全ノードのUを単純合計しないでください。
経路：経路推定累積度は、最後の確定境界から末端まで推定をどの程度、何段重ねてきたかを表す無次元指標です。allocatedの段で score_i = score_parent + log10(1 + max(U_i, 0) / U0) とし、U0は既存の基準量設定を使用します。実測・合算・残差算出（確定）で0へリセットし、残差算出（推定継承）は加算せず継承します。外部比率按分も対象です。負按分・負のU・算出不能な上流値がある経路は算出不能とし、次の確定境界でリセットします。各段の規模係数の積の常用対数に相当し、誤差率や統計的な信頼区間ではありません。
領域：領域未確定量は、上流で確定している電力量から、その下流の確定フロンティアの電力量を差し引いた残り（R = E_b - D_b）です。複数の按分先が共有する未閉領域全体の値であり、個々のノードを起点とする下流未確定量とは区別します。診断対象の推定幅はこの領域未確定量に対応します。末端理論最大値M_tは、直属子のない未確定な按分ノードだけを対象とします。最も近いconfirmedの祖先bを上流確定境界とし、M_t = b.energy - D_bで、領域未確定量に対応します。同じ未閉領域の末端は原則同じ最大値を持ちます。上流1000、下流フロンティアが実測300・合算200なら、残る按分末端A/B/Cはそれぞれ0～500kWhです。同時に全末端が500になるわけではなく、未確定量全体に保存則があります。予測値や統計的信頼区間ではありません。確定祖先がない場合やNaN・Inf等は算出不能です。

計測推奨境界は、診断対象の推定幅がしきい値（初期値2000kWh）を超える場合に、診断上の末端から上流をたどり、下流未確定量が同しきい値を厳密に超える最初の非除外・未確定按分へ●を表示します。AT・外部比率とも候補です。推定継承残差は通過可能、confirmedで探索終了、同じ候補は1点に統合します。

下流確定量・下流未確定量は全階層の未確定按分で表示します。下流未確定量には表示しきい値を適用しますが、負値は常時表示します。末端理論最大値は0・負値もしきい値で隠さず表示します。経路推定累積度は従来どおり末端のみ表示し、表示しきい値を適用します。CSV・Excelでは個別推定量の既存しきい値を維持し、それ以外の数値は対象ノードのしきい値未満・0・負値も出力します。計測推奨境界は該当=1、非該当=0です。空欄は対象外・算出不能、または画面の表示しきい値未満を含みます。下流未確定量・末端理論最大値の負値は管理（確認事項）にも通知し、期間不一致、計測境界不整合、構造不整合等の調査材料として保持します。

すべてのブレーカーを実測化することが目的ではありません。末端按分ノードを含む未閉領域を定量化し、計測効果・工事費・停電影響・施工性を比較しながら、必要十分な大きさまで未閉領域を縮小することが目的です。計測推奨境界は具体的なCT設置位置を自動決定するものではありません。フラグ位置またはそれより下流で、既設メーター、多回路モニター、CT空きチャンネル、通信設備、兄弟回路の測定や全子回路の合算を含め、最も施工性・費用対効果のよい確定境界の作り方を検討する目安です。

計測推奨境界は、設置後に必ずしきい値以下になる数学的保証ではありません。新しい実測値は現在の推定値と異なる可能性があるため、設置後に再計算して下流未確定量と末端理論最大値の減少を再評価します。管理しきい値設定には、計測推奨境界のユニーク数と診断対象の推定幅の最大を表示します。境界数が少ないだけではデータ品質を保証せず、計測完了・投資停止を自動判定しません。これらは診断専用で、電力量計算・予算配賦へフィードバックしません。

■ 計測評価対象外・診断上の末端・出力

計測評価対象外は末端の按分ノードのセルをダブルクリックして□/☑を切り替えます。Undo/Redoに対応し、分析CSVで保存・復元します。除外ノードの推定指標は画面では隠しますが、電力量・予算配賦・確定性・管理通知は変えず、CSV・Excelには内部診断値を保持します。
非除外の構造末端は診断対象です。除外末端は最も近い非除外の未確定按分祖先へ集約し、同じ祖先は1対象に統合します。確定祖先に到達したら対象を作りません。外部比率の物理ブレーカーも除外しなければ計測候補です。
構造上の末端理論最大値と、診断上の内部末端の理論最大値は区別します。内部対象iの下流確定量D_i、最も近い上流確定境界bの残余R=E_b-D_bに対し、理論最小値D_i、理論最大値D_i+R、推定幅Rです。KPIは推定幅を使用し、対象間で合計しません。構造末端の元の末端理論最大値も別に保持します。
解析結果サマリーはKPI・計算統計・管理フラグ・設定と、その後に用語・前提・注意事項を表示します。推定幅算出不能、評価対象なし、未確定な診断対象なしを区別し、除外数・集約数を併記します。除外によるKPI低下は計測改善を意味せず、境界0でも投資完了とは自動判定しません。
PDF出力は同じサマリーデータを使用します。統合解析Excelはツリー、上位接続、Sankeyフロー、Sankeyログ、解析結果サマリーの5シートです。Sankey生成不能時は理由を記録します。翌月の構成引継ぎには分析CSVを使い、保存された電力量を再利用せず当月のマスタを適用します。

■ Sankey図CSVの解釈

Sankey図CSVは、分析CSVから作成された非負の要約データです。通常は、電源 → 電源ミックス → 電気室 → 用途 → 予算単位の流れを表します。補器・損失がある場合は、電源ミックス → 補器・損失の枝も出力されます。集約ノードは二重計上防止のため原則として対象外です。需要側の負値は、電気室 × 属性（Sankey分類）× 予算単位コードで符号付き集計した後に判定されます。Sankey図CSVだけで元の配賦合計を判断せず、分析CSVとSankeyログCSVを確認してください。

■ 推奨する分析手順

1. ファイル種別、対象年月、件数を確認する
2. 親子関係とツリー構造を確認する
3. 実測、合算、按分の構成比を確認する
4. 計量名称と予算単位の未設定・呼出不可を確認する
5. 親子差、過大電力、負按分を確認する
6. 点・群・経路・領域の推定指標を確認し、管理フラグや施工条件と合わせて改善する領域を検討する
7. 実在設備と仮想ノードの対応を確認する
8. 0kWh扱い設備と参考値を確認する
9. 仮想損失ノードと収支差分を確認する
10. 電気室、変圧器、用途、予算単位別に構成を整理する
11. Sankey図CSVで全体の流れを把握する
12. SankeyログCSVで除外・警告を確認する
13. 量・比率CSVで配賦根拠を確認する
14. 省エネ、メーター追加、按分改善、設備更新の候補を整理する

■ AIに期待する回答

回答では、データから直接確認できる事実、データから合理的に推定できること、追加確認が必要な仮説、不足している情報、改善候補を区別してください。按分値を実測値と表現しないでください。省エネ効果、削減金額、投資回収などを試算する場合は、使用した条件と仮定を明示してください。

■ 将来的な拡張

現在の主対象は電力量配賦です。ガス、水、蒸気、圧縮空気、冷温水、温度、生産量、生産計画、費用などが提供された場合は、単位、対象期間、計測境界、算出根拠、集計範囲、比較可能性を確認した上で分析してください。現行アプリがこれらを自動計算するわけではありません。
"""

def get_developer_contact_text() -> str:
    return """【開発・質問】

■ アプリ情報

あんぶんくん
電力系統構造化・解析・配賦支援ツール

バージョン、リリース日、試用版などの情報は、アプリ画面に表示されている内容をご確認ください。

■ 開発の目的

あんぶんくんは、すべてのブレーカーに電力量計を設置することが難しい工場において、限られた実測値、設備構成、按分比率、予算単位情報を組み合わせ、説明可能・再現可能な電力量配賦を行うために開発しました。

単にメーター不足を補うだけではなく、物理的な受配電構成と、原価配賦・省エネ分析で確認したい単位を結び付け、工場内のエネルギー使用構造を見える化することを目指しています。

また、電力系統を中心に、設備、盤、変圧器、電気室、予算単位、部署、用途分類をツリーで結び付けることで、設備管理用のデジタル台帳としても利用できるようにしています。

価値の中心はプログラムそのものではなく、工場の電力系統と現場知見を構造化して残すツリーデータです。

アプリは、そのデータを編集・確認し、CSV・Excel出力、Sankey図、BI、AI解析へつなぐための道具です。

■ 開発者・設計者

パナソニック ファシリティーズ株式会社
Inoue Akira（井上 昭）

■ 質問・改善要望・不具合連絡先

inoue.akira002@jp.panasonic.com

ご連絡の際は、可能な範囲で次の情報をお知らせください。

・使用しているアプリのバージョン
・発生した操作
・表示されたメッセージ
・期待していた結果
・実際の結果
・再現手順
・対象データの行番号やノード名
・画面画像
・個人情報、機密情報を除いた再現用データ

■ ご相談いただきたい内容

・操作方法が分からない
・構成CSVや量・比率CSVの作り方を確認したい
・実測、合算、按分の使い分けを相談したい
・仮想ノードの構成を相談したい
・管理列の表示理由を確認したい
・親子差、負按分、過大電力の原因を確認したい
・Sankey図CSVの構成を相談したい
・AI解析用データの渡し方を確認したい
・設備構成や運用に合わせた改善案を提案したい
・不具合や表示上の問題を報告したい

■ 利用上の注意

あんぶんくんの配賦結果には、実測値だけでなく、合算値や按分による推定値が含まれます。

結果は、入力データ、設備構成、計測境界、按分比率、対象期間、運用条件に依存します。

本アプリの表示、分析CSV、Sankey図、AI解析結果は、設備の安全性、法令適合性、原価、投資効果を保証するものではありません。

重要な判断では、元資料、現場状況、設備仕様、関係部署、専門家の確認と合わせて使用してください。

機密情報、個人情報、設備保安上重要な情報を外部のAIサービスや外部関係者へ提供する場合は、所属組織の情報管理ルールに従ってください。
"""

def show_developer_contact():
    show_text_window('開発・質問', get_developer_contact_text(), copy_button=True)

# ---- GUI 構築 ----

if DND_AVAILABLE:
    try:
        root = TkinterDnD.Tk()
    except Exception as e:
        print('[DND] tkinterdnd2 初期化失敗。ドラッグ＆ドロップを無効にします:', e)
        DND_AVAILABLE = False
        root = tk.Tk()
else:
    root = tk.Tk()
root.title(f'{APP_VERSION_LABEL} - {APP_SUBTITLE}')
sample_status_var = tk.StringVar(value=get_sample_status_text())
columns=(
    '詳細１','詳細２','AT','算出方法','計量名称','按分比率','按分単位','電力量',
    '予算単位コード','予算単位名称','電気室','変圧器','分類１','分類２','分類３','属性(Sankey分類)','備考',
    '管理（親子差大）','管理（過大電力）','管理（負按分）','管理（確認事項）',
    '計測評価対象外','個別推定量','下流確定量','下流未確定量','末端理論最大値','経路推定累積度','計測推奨境界',
    '参考計量名称','参考値','参考単位','参考_按分kWh差','行番号'
)
ATTRIBUTE_COLUMNS=('詳細１','詳細２','電気室','変圧器','分類１','分類２','分類３','属性(Sankey分類)')
ESTIMATION_INDICATOR_EXPORT_COLUMNS=('個別推定量','下流確定量','下流未確定量','末端理論最大値','経路推定累積度','計測推奨境界','計測評価対象外')
ESTIMATION_INDICATOR_COLUMNS=('計測評価対象外', *ESTIMATION_INDICATOR_EXPORT_COLUMNS[:-1])
MANAGEMENT_COLUMNS=('管理（親子差大）','管理（過大電力）','管理（負按分）','管理（確認事項）')
REFERENCE_COLUMNS=('参考計量名称','参考値','参考単位','参考_按分kWh差')
show_attribute_columns = False
show_estimation_indicator_columns = False
show_management_columns = False
show_reference_columns = False
column_attr_map={'行番号':None,'詳細１':'detail1','詳細２':'detail2','算出方法':'calc_method','AT':'at','計量名称':'measure_name','按分比率':'ratio','按分単位':'unit','電力量':'energy','備考':'notes','属性(Sankey分類)':'sankey_category','電気室':'electric_room','変圧器':'transformer','分類１':'category1','分類２':'category2','分類３':'category3','予算単位コード':'budget_unit','予算単位名称':None,'個別推定量':None,'下流確定量':None,'下流未確定量':None,'末端理論最大値':None,'経路推定累積度':None,'計測推奨境界':None,'計測評価対象外':None,'管理（親子差大）':None,'管理（過大電力）':None,'管理（負按分）':None,'管理（確認事項）':None,'参考計量名称':'reference_measure_name','参考値':'reference_value','参考単位':'reference_unit','参考_按分kWh差':None}

def get_tree_heading_label(col: str) -> str:
    attr_heading_map = {
        '電気室': '属性（電気室）',
        '変圧器': '属性（変圧器）',
        '分類１': '属性（分類１）',
        '分類２': '属性（分類２）',
        '分類３': '属性（分類３）',
        '詳細１': '属性（詳細１）',
        '詳細２': '属性（詳細２）',
        '属性(Sankey分類)': '属性(Sankey分類)',
    }
    return attr_heading_map.get(col, col)

toolbar_frame=ttk.Frame(root); toolbar_frame.pack(fill='x', padx=6, pady=(6,2))
footer_frame=ttk.Frame(root); footer_frame.pack(side='bottom', fill='x', padx=6, pady=(2,4))
ttk.Label(
    footer_frame,
    text=APP_VERSION_LABEL,
    anchor='e'
).pack(side='right')
main_frame=ttk.Frame(root); main_frame.pack(fill='both',expand=True)
tree=ttk.Treeview(main_frame, columns=columns, show='tree headings', selectmode='extended')
vsb=ttk.Scrollbar(main_frame, orient='vertical', command=tree.yview)
hsb=ttk.Scrollbar(main_frame, orient='horizontal', command=tree.xview)
tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
tree.grid(row=0,column=0,sticky='nsew'); vsb.grid(row=0,column=1,sticky='ns'); hsb.grid(row=1,column=0,sticky='ew')
main_frame.rowconfigure(0,weight=1); main_frame.columnconfigure(0,weight=1)
style=ttk.Style()
base_font = tkfont.nametofont('TkDefaultFont')
tree_row_height = max(30, int(base_font.metrics('linespace')) + 10)
style.configure('Treeview', rowheight=tree_row_height)
style.configure('Treeview.Heading', padding=(4, 4))
tree.heading('#0', text='ノード名')
for c in columns: tree.heading(c, text=get_tree_heading_label(c))
node_ids: Dict[int,str] = {}

def apply_display_columns():
    visible=[]
    for c in columns:
        if c in ATTRIBUTE_COLUMNS and not show_attribute_columns:
            continue
        if c in ESTIMATION_INDICATOR_COLUMNS and not show_estimation_indicator_columns:
            continue
        if c in MANAGEMENT_COLUMNS and not show_management_columns:
            continue
        if c in REFERENCE_COLUMNS and not show_reference_columns:
            continue
        visible.append(c)
    tree['displaycolumns'] = visible

apply_display_columns()

def get_treeview_column_name(tv: ttk.Treeview, column_id: str) -> Optional[str]:
    if column_id == '#0':
        return '#0'
    try:
        display_index = int(str(column_id).replace('#', '')) - 1
    except (TypeError, ValueError):
        return None

    display_columns_raw = tv['displaycolumns']
    if display_columns_raw == '#all':
        display_columns = list(columns)
    elif isinstance(display_columns_raw, str):
        display_columns = list(tv.tk.splitlist(display_columns_raw))
    else:
        display_columns = list(display_columns_raw)
    if len(display_columns) == 1 and display_columns[0] == '#all':
        display_columns = list(columns)

    if display_index < 0 or display_index >= len(display_columns):
        return None
    return display_columns[display_index]

class TreeviewManagementTooltip:
    def __init__(self, tv: ttk.Treeview, delay_ms:int=600):
        self.tv = tv
        self.delay_ms = delay_ms
        self._after_id = None
        self._tip = None
        self._current_key = None
        self._pending = None
        tv.bind('<Motion>', self._on_motion, add='+')
        tv.bind('<Leave>', lambda _e: self.hide(), add='+')
        tv.bind('<ButtonPress>', lambda _e: self.hide(), add='+')
        tv.bind('<MouseWheel>', lambda _e: self.hide(), add='+')
        tv.bind('<Button-4>', lambda _e: self.hide(), add='+')
        tv.bind('<Button-5>', lambda _e: self.hide(), add='+')
        tv.bind('<Configure>', lambda _e: self.hide(), add='+')

    def _on_motion(self, event):
        data = self._tooltip_data(event)
        key = data[:2] if data else None
        if key == self._current_key:
            return
        self.hide()
        self._current_key = key
        self._pending = data
        if data:
            self._after_id = self.tv.after(self.delay_ms, self._show_pending)

    def _tooltip_data(self, event):
        region = self.tv.identify_region(event.x, event.y)
        col_name = get_treeview_column_name(self.tv, self.tv.identify_column(event.x))

        if region == 'heading':
            text = get_heading_tooltip(col_name)
            return ('heading', col_name, text, event.x_root, event.y_root) if text else None

        if col_name not in MANAGEMENT_COLUMNS:
            return None

        if region not in ('cell', 'tree'):
            return None
        iid = self.tv.identify_row(event.y)
        if not iid:
            return None
        try:
            cell_value = normalize_value(self.tv.set(iid, col_name))
        except tk.TclError:
            return None
        if not cell_value:
            return None
        index = next((index for index, item_id in node_ids.items() if item_id == iid), None)
        if index is None:
            return None
        text = get_management_cell_tooltip(index, col_name)
        return (iid, col_name, text, event.x_root, event.y_root) if text else None

    def _show_pending(self):
        self._after_id = None
        if not self._pending:
            return
        _row, _col, text, x_root, y_root = self._pending
        if not text:
            return
        self._tip = tk.Toplevel(self.tv)
        self._tip.withdraw()
        self._tip.overrideredirect(True)
        try:
            self._tip.attributes('-topmost', True)
        except tk.TclError:
            pass
        label = tk.Label(
            self._tip,
            text=text,
            justify='left',
            anchor='w',
            bg='#ffffe0',
            fg='#202020',
            relief='solid',
            borderwidth=1,
            padx=8,
            pady=6,
            wraplength=460,
        )
        label.pack()
        self._tip.update_idletasks()
        width = self._tip.winfo_reqwidth()
        height = self._tip.winfo_reqheight()
        screen_w = self._tip.winfo_screenwidth()
        screen_h = self._tip.winfo_screenheight()
        x = min(x_root + 14, max(0, screen_w - width - 8))
        y = min(y_root + 18, max(0, screen_h - height - 8))
        self._tip.geometry(f'+{x}+{y}')
        self._tip.deiconify()

    def hide(self):
        if self._after_id is not None:
            try:
                self.tv.after_cancel(self._after_id)
            except tk.TclError:
                pass
            self._after_id = None
        if self._tip is not None:
            try:
                self._tip.destroy()
            except tk.TclError:
                pass
            self._tip = None
        self._pending = None
        self._current_key = None

class SimpleTooltip:
    def __init__(self, widget, text_getter, delay_ms:int=500):
        self.widget = widget
        self.text_getter = text_getter
        self.delay_ms = delay_ms
        self._after_id = None
        self._tip = None
        widget.bind('<Enter>', self._schedule, add='+')
        widget.bind('<Leave>', self.hide, add='+')
        widget.bind('<ButtonPress>', self.hide, add='+')

    def _schedule(self, _event=None):
        self.hide()
        self._after_id = self.widget.after(self.delay_ms, self._show)

    def _show(self):
        self._after_id = None
        text = self.text_getter() if callable(self.text_getter) else str(self.text_getter)
        if not text:
            return
        self._tip = tk.Toplevel(self.widget)
        self._tip.withdraw()
        self._tip.overrideredirect(True)
        label = tk.Label(self._tip, text=text, justify='left', anchor='w', bg='#ffffe0',
                         fg='#202020', relief='solid', borderwidth=1, padx=8, pady=5,
                         wraplength=560)
        label.pack()
        self._tip.update_idletasks()
        x = self.widget.winfo_rootx() + 18
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 6
        self._tip.geometry(f'+{x}+{y}')
        self._tip.deiconify()

    def hide(self, _event=None):
        if self._after_id is not None:
            try:
                self.widget.after_cancel(self._after_id)
            except tk.TclError:
                pass
            self._after_id = None
        if self._tip is not None:
            try:
                self._tip.destroy()
            except tk.TclError:
                pass
            self._tip = None

def open_combobox_dropdown(combo: ttk.Combobox):
    combo.focus_set()
    def _open():
        try:
            combo.tk.call('ttk::combobox::Post', combo)
        except tk.TclError:
            try:
                combo.event_generate('<Down>')
            except tk.TclError:
                pass
    combo.after_idle(_open)

def bind_combobox_commit(combo: ttk.Combobox, commit):
    def _commit_and_break(_event=None):
        commit()
        return 'break'
    combo.bind('<<ComboboxSelected>>', _commit_and_break)
    combo.bind('<Return>', _commit_and_break)
    combo.bind('<Escape>', lambda _event: (combo.destroy(), 'break')[1])

# ---- 共通: 予算単位コードの構造ルールと表示値 ----
def apply_budget_unit_structure_rules():
    # 旧仕様では構造に応じて FlatNode の保存値を書き換えていた。
    # 現在はユーザー入力値を保持し、有効値は get_effective_* で派生させる。
    return None

def get_stored_budget_unit_code(index: int) -> str:
    return normalize_value(flat_nodes[index].budget_unit)

def get_effective_budget_unit_code(index: int) -> str:
    code = get_stored_budget_unit_code(index)
    if has_child(index) and code != BUDGET_UNIT_POWER:
        return BUDGET_UNIT_AGGREGATE
    return code

def get_budget_unit_edit_values(index: int) -> List[str]:
    if has_child(index):
        return [BUDGET_UNIT_AGGREGATE, BUDGET_UNIT_POWER]
    return get_budget_unit_combo_display_values()

def set_budget_unit_code(index: int, code: str) -> bool:
    code = normalize_value(code)
    if has_child(index) and code not in (BUDGET_UNIT_AGGREGATE, BUDGET_UNIT_POWER):
        return False
    if get_effective_budget_unit_code(index) == code:
        return False
    push_history()
    flat_nodes[index].budget_unit = code
    invalidate_management_cache()
    return True

def get_effective_sankey_category(index: int) -> str:
    if get_effective_budget_unit_code(index) == BUDGET_UNIT_AGGREGATE:
        return ''
    return normalize_value(flat_nodes[index].sankey_category)

def get_budget_unit_code(index: int) -> str:
    return get_effective_budget_unit_code(index)

def get_budget_unit_name(index: int) -> str:
    code = get_budget_unit_code(index)
    if code in ('', BUDGET_UNIT_AGGREGATE, BUDGET_UNIT_POWER):
        return ''
    return budget_unit_master.get(normalize_key(code), '')

def get_power_budget_unit_node_indices() -> List[int]:
    return [
        index
        for index, _node in enumerate(flat_nodes)
        if get_effective_budget_unit_code(index) == BUDGET_UNIT_POWER
    ]

def has_power_budget_unit_node() -> bool:
    return bool(get_power_budget_unit_node_indices())

def format_missing_power_budget_unit_error(target_name:str) -> str:
    return (
        f'{target_name}を出力できません。\n\n'
        '予算単位コード「電源」のノードが1件もありません。\n\n'
        '電力会社請求書や受電点など、供給側の電力量に相当するノードに'
        '予算単位コード「電源」を設定してから出力してください。'
    )

def compute_budget_unit_management(index: int) -> str:
    if has_child(index):
        return ''
    node = flat_nodes[index]
    code = get_budget_unit_code(index)
    key = normalize_key(code)
    if code == '':
        # 電力量が 0 に等しい末端ノードのみ、微小負荷・一括按分・対象外などとして扱い、
        # 予算単位未設定の警告を出さない。負按分の場合は割り当て確認が必要なため省略しない。
        energy = coerce_finite_number(node.energy)
        if energy is None:
            return ''
        if abs(energy) < 0.000001:
            return ''
        return '未設定'
    if code == BUDGET_UNIT_POWER:
        return ''
    if key in budget_unit_master:
        return ''
    return '呼出不可'

def get_budget_unit_combo_display_values() -> List[str]:
    values = ['']
    for code in sorted(budget_unit_master.keys()):
        name = budget_unit_master.get(code, '')
        values.append(f'{code}：{name}' if name else code)
    values.append(BUDGET_UNIT_POWER)
    return values

def parse_budget_unit_combo_display(display_value: str) -> str:
    value = normalize_value(display_value)
    if value in ('', BUDGET_UNIT_POWER):
        return value
    if '：' in value:
        return normalize_value(value.split('：', 1)[0])
    return value

def format_budget_unit_combo_display(code: str) -> str:
    code = normalize_value(code)
    if code in ('', BUDGET_UNIT_POWER):
        return code
    name = budget_unit_master.get(normalize_key(code), '')
    return f'{code}：{name}' if name else code

def count_budget_unit_calls_in_table():
    cnt={}
    for i, n in enumerate(flat_nodes):
        key=normalize_key(get_effective_budget_unit_code(i))
        if key in ('', BUDGET_UNIT_AGGREGATE):
            continue
        if not key: continue
        cnt[key]=cnt.get(key,0)+1
    return cnt

def build_node_estimation_states(structure) -> Dict[int, str]:
    """計算値を変更せず、親から順に確定性と残差算出の状態を判定する。"""
    allocation_count = {
        parent: sum(flat_nodes[j].calc_method == '按分' for j in children)
        for parent, children in structure.direct_children_by_index.items()
    }
    states: Dict[int, str] = {}
    for i, node in enumerate(flat_nodes):
        parent = structure.parent_by_index.get(i)
        if node.calc_method in ('実測', '合算'):
            states[i] = 'confirmed'
        elif node.calc_method != '按分' or parent is None:
            states[i] = 'unavailable'
        elif allocation_count.get(parent, 0) == 1:
            states[i] = 'confirmed' if states.get(parent) == 'confirmed' else 'inherited'
        else:
            states[i] = 'allocated'
    return states


def get_node_estimation_state(index:int) -> str:
    return get_management_context().estimation_state_by_index.get(index, 'unavailable')


def build_management_context() -> ManagementContext:
    structure = get_tree_structure_index()
    states = build_node_estimation_states(structure)

    at_indices_by_parent: Dict[Optional[int], List[int]] = {}
    at_nodes: Set[int] = set()
    for i, _node in enumerate(flat_nodes):
        if not is_at_allocation_node(i):
            continue
        at_nodes.add(i)
        parent_index = structure.parent_by_index.get(i)
        at_indices_by_parent.setdefault(parent_index, []).append(i)

    # 診断専用。各辺を一度だけ評価するbottom-up DPで確定フロンティアを集計。
    # confirmedの子では子自身の電力量だけを採用し、その下流を二重計上しない。
    downstream_confirmed: Dict[int, Optional[float]] = {}
    for i in reversed(range(len(flat_nodes))):
        total = 0.0
        for child in structure.direct_children_by_index.get(i, []):
            contribution = (
                coerce_finite_number(flat_nodes[child].energy)
                if states[child] == 'confirmed' else downstream_confirmed[child]
            )
            if contribution is None:
                total = None
                break
            total += contribution
        downstream_confirmed[i] = coerce_finite_number(total)

    group_uncertainty: Dict[int, Optional[float]] = {}
    region_uncertainty: Dict[int, Optional[float]] = {}
    nearest_boundary: Dict[int, Optional[int]] = {}
    terminal_theoretical_max: Dict[int, Optional[float]] = {}
    terminal_region_boundary: Dict[int, Optional[int]] = {}
    for i, node in enumerate(flat_nodes):
        energy = coerce_finite_number(node.energy)
        downstream = downstream_confirmed[i]
        remaining = coerce_finite_number(
            energy - downstream if energy is not None and downstream is not None else None
        )
        parent = structure.parent_by_index.get(i)
        nearest_boundary[i] = parent if states.get(parent) == 'confirmed' else nearest_boundary.get(parent)
        if states[i] == 'confirmed':
            group_uncertainty[i] = 0.0
            region_uncertainty[i] = remaining
        elif node.calc_method == '按分' and states[i] in ('allocated', 'inherited'):
            group_uncertainty[i] = remaining
            if not structure.has_child_by_index.get(i, False):
                boundary = nearest_boundary[i]
                terminal_region_boundary[i] = boundary
                terminal_theoretical_max[i] = region_uncertainty.get(boundary)
        else:
            group_uncertainty[i] = None

    # 構造上の末端の生値は保持し、計測投資に用いる評価対象を別に作る。
    diagnostic_terminals: Set[int] = set()
    aggregated_terminals: Set[int] = set()
    nearest_included: Dict[int, Optional[int]] = {}
    for i, node in enumerate(flat_nodes):
        parent = structure.parent_by_index.get(i)
        excluded = bool(getattr(node, 'measurement_evaluation_excluded', False))
        nearest_included[i] = nearest_included.get(parent) if excluded else i
        if structure.has_child_by_index.get(i, False):
            continue
        if not excluded:
            diagnostic_terminals.add(i)
        else:
            ancestor = nearest_included.get(parent)
            if ancestor is not None and states[ancestor] in ('allocated', 'inherited'):
                diagnostic_terminals.add(ancestor)
                aggregated_terminals.add(ancestor)

    diagnostic_min: Dict[int, Optional[float]] = {}
    diagnostic_max: Dict[int, Optional[float]] = {}
    diagnostic_width: Dict[int, Optional[float]] = {}
    diagnostic_boundary: Dict[int, Optional[int]] = {}
    for i in diagnostic_terminals:
        boundary = nearest_boundary[i]
        diagnostic_boundary[i] = boundary
        if states[i] == 'confirmed':
            diagnostic_min[i] = diagnostic_max[i] = coerce_finite_number(flat_nodes[i].energy)
            diagnostic_width[i] = 0.0 if diagnostic_min[i] is not None else None
        elif states[i] in ('allocated', 'inherited'):
            minimum = downstream_confirmed[i]
            width = region_uncertainty.get(boundary)
            diagnostic_min[i] = minimum
            diagnostic_width[i] = width
            diagnostic_max[i] = coerce_finite_number(
                minimum + width if minimum is not None and width is not None else None
            )
        else:
            diagnostic_min[i] = diagnostic_max[i] = diagnostic_width[i] = None

    measurement_recommended_boundary = {i: False for i in range(len(flat_nodes))}
    boundary_threshold = float(MGMT_CFG.get(
        'measurement_boundary_threshold_kwh', MGMT_CFG_DEFAULTS['measurement_boundary_threshold_kwh']
    ))
    for terminal, width in diagnostic_width.items():
        if width is None or width <= boundary_threshold:
            continue
        candidate = terminal
        while candidate is not None and states[candidate] != 'confirmed':
            uncertainty = group_uncertainty[candidate]
            if (flat_nodes[candidate].calc_method == '按分'
                    and states[candidate] in ('allocated', 'inherited')
                    and not getattr(flat_nodes[candidate], 'measurement_evaluation_excluded', False)
                    and uncertainty is not None and uncertainty > boundary_threshold):
                measurement_recommended_boundary[candidate] = True
                break
            candidate = structure.parent_by_index.get(candidate)

    estimation_accumulation: Dict[int, Optional[float]] = {}
    estimation_accumulation_negative: Dict[int, bool] = {}
    negative_threshold = float(MGMT_CFG.get(
        'negative_anbun_threshold_kwh',
        MGMT_CFG_DEFAULTS['negative_anbun_threshold_kwh']
    ))
    reference_kwh = float(MGMT_CFG.get(
        'estimation_accumulation_reference_kwh',
        MGMT_CFG_DEFAULTS['estimation_accumulation_reference_kwh']
    ))
    if not math.isfinite(reference_kwh) or reference_kwh <= 0:
        reference_kwh = MGMT_CFG_DEFAULTS['estimation_accumulation_reference_kwh']

    for i, node in enumerate(flat_nodes):
        if states[i] == 'confirmed':
            estimation_accumulation[i] = 0.0
            estimation_accumulation_negative[i] = False
            continue
        if states[i] == 'unavailable':
            estimation_accumulation[i] = None
            estimation_accumulation_negative[i] = False
            continue

        parent_index = structure.parent_by_index.get(i)
        parent_negative = bool(estimation_accumulation_negative.get(parent_index, False))
        parent_score = estimation_accumulation.get(parent_index)
        energy = coerce_finite_number(getattr(node, 'energy', 0.0))
        uncertainty = group_uncertainty[i]
        node_negative = (
            getattr(node, 'calc_method', '') == '按分'
            and energy is not None
            and energy <= negative_threshold
        ) or (uncertainty is not None and uncertainty < 0)
        if parent_negative or node_negative:
            estimation_accumulation[i] = None
            estimation_accumulation_negative[i] = True
            continue

        estimation_accumulation_negative[i] = False
        if parent_score is None or energy is None or uncertainty is None:
            estimation_accumulation[i] = None
            continue
        score = float(parent_score)
        if states[i] == 'allocated':
            # log1pで小さい量の精度を保持し、比のオーバーフローも回避する。
            ratio = max(uncertainty, 0.0) / reference_kwh
            addend = (math.log1p(ratio) / math.log(10) if math.isfinite(ratio)
                      else math.log10(uncertainty) - math.log10(reference_kwh))
            score += addend
        estimation_accumulation[i] = coerce_finite_number(score)

    budget_units_under: Dict[int, Set[str]] = {i: set() for i in range(len(flat_nodes))}
    for i in reversed(range(len(flat_nodes))):
        if not structure.has_child_by_index.get(i, False):
            code = normalize_key(get_stored_budget_unit_code(i))
            if code not in ('', BUDGET_UNIT_AGGREGATE, BUDGET_UNIT_POWER):
                budget_units_under[i].add(code)
        parent_index = structure.parent_by_index.get(i)
        if parent_index is not None:
            budget_units_under[parent_index].update(budget_units_under[i])

    at_group_counts: Dict[int, int] = {}
    for parent_index, group_indices in at_indices_by_parent.items():
        units: Set[str] = set()
        for child_index in group_indices:
            units.update(budget_units_under.get(child_index, set()))
        count = len(units) if parent_index is not None and len(group_indices) > 1 else 0
        if parent_index is not None:
            at_group_counts[parent_index] = count

    return ManagementContext(
        estimation_state_by_index=states,
        downstream_confirmed_by_index=downstream_confirmed,
        group_uncertainty_by_index=group_uncertainty,
        terminal_theoretical_max_by_index=terminal_theoretical_max,
        terminal_region_boundary_by_index=terminal_region_boundary,
        measurement_recommended_boundary_by_index=measurement_recommended_boundary,
        estimation_accumulation_by_index=estimation_accumulation,
        estimation_accumulation_negative_by_index=estimation_accumulation_negative,
        budget_units_under_node_by_index=budget_units_under,
        at_allocation_group_budget_unit_count_by_index=at_group_counts,
        diagnostic_terminal_indices=diagnostic_terminals,
        aggregated_diagnostic_terminal_indices=aggregated_terminals,
        diagnostic_region_boundary_by_index=diagnostic_boundary,
        diagnostic_theoretical_min_by_index=diagnostic_min,
        diagnostic_theoretical_max_by_index=diagnostic_max,
        diagnostic_uncertainty_width_by_index=diagnostic_width,
        power_notice_data_by_index=build_power_notice_data(structure),
    )

def get_management_context() -> ManagementContext:
    global _management_context_cache
    if _management_context_cache is None:
        _management_context_cache = build_management_context()
    return _management_context_cache

# 管理列の算出
def compute_management_values(index):
    context = get_management_context()
    if index in context.management_values_by_index:
        return context.management_values_by_index[index]
    node=flat_nodes[index]
    # 親子差大
    children=[flat_nodes[j] for j in get_direct_child_indices(index)]
    has_children=len(children)>0
    child_total=sum(c.energy for c in children)
    m_parent_child=''
    if has_children:
        diff = node.energy - child_total
        threshold = float(MGMT_CFG.get('parent_child_difference_threshold_kwh', MGMT_CFG_DEFAULTS['parent_child_difference_threshold_kwh']))
        if math.isfinite(diff) and abs(diff) >= threshold:
            m_parent_child=f"{diff:.1f} kWh"
    # 過大電力
    m_over=''
    at_num=extract_number(node.at,None)
    if (not is_ratio_called_allocation_node(node)) and at_num is not None and at_num!=0:
        max_e=float(at_num)*math.sqrt(3)*210/1000*24*30
        th_frac=float(MGMT_CFG.get('over_power_threshold_percent_of_max', MGMT_CFG_DEFAULTS['over_power_threshold_percent_of_max']))/100.0
        if math.isfinite(float(node.energy)) and node.energy > th_frac*max_e:
            m_over=f"{(node.energy/max_e)*100:.1f} %"
    # 負按分
    m_neg=''; neg_th=float(MGMT_CFG.get('negative_anbun_threshold_kwh', MGMT_CFG_DEFAULTS['negative_anbun_threshold_kwh']))
    if node.calc_method=='按分' and math.isfinite(float(node.energy)) and node.energy<=neg_th:
        m_neg=format_energy_display(node.energy)
    result = (m_parent_child, m_over, m_neg)
    context.management_values_by_index[index] = result
    return result

def is_at_allocation_node(index:int) -> bool:
    node = flat_nodes[index]
    return (
        node.calc_method == '按分'
        and normalize_value(node.measure_name).strip() == ''
    )

def get_downstream_confirmed(index:int) -> Optional[float]:
    return get_management_context().downstream_confirmed_by_index.get(index)

def get_group_uncertainty(index:int) -> Optional[float]:
    return get_management_context().group_uncertainty_by_index.get(index)

def get_terminal_theoretical_max(index:int) -> Optional[float]:
    return get_management_context().terminal_theoretical_max_by_index.get(index)

def is_measurement_recommended_boundary(index:int) -> bool:
    return get_management_context().measurement_recommended_boundary_by_index.get(index, False)

def get_measurement_investment_kpis() -> Dict[str, Any]:
    context = get_management_context()
    uncertain = [i for i in context.diagnostic_terminal_indices if context.estimation_state_by_index[i] != 'confirmed']
    widths = [context.diagnostic_uncertainty_width_by_index[i] for i in uncertain]
    finite_widths = [value for value in widths if value is not None]
    scores = [context.estimation_accumulation_by_index.get(i) for i in context.diagnostic_terminal_indices]
    finite_scores = [value for value in scores if value is not None]
    unavailable = sum(context.diagnostic_uncertainty_width_by_index[i] is None for i in context.diagnostic_terminal_indices)
    structure = get_tree_structure_index()
    structural_terminals = [i for i in range(len(flat_nodes)) if not structure.has_child_by_index.get(i, False)]
    state = ('評価対象なし' if not context.diagnostic_terminal_indices else
             '算出不能あり' if unavailable else
             '未確定な診断対象なし' if not uncertain else
             '負の推定幅あり' if any(value < 0 for value in finite_widths) else '評価可能')
    return {
        'measurement_recommended_boundary_count': sum(context.measurement_recommended_boundary_by_index.values()),
        # 旧KPIキーは残し、意味を診断対象の推定幅へ移す。
        'terminal_theoretical_max_kwh': max(finite_widths) if finite_widths else None,
        'diagnostic_uncertainty_width_max_kwh': max(finite_widths) if finite_widths else None,
        'diagnostic_width_above_threshold_count': sum(value > MGMT_CFG['measurement_boundary_threshold_kwh'] for value in finite_widths),
        'diagnostic_accumulation_max': max(finite_scores) if finite_scores else None,
        'diagnostic_accumulation_above_display_threshold_count': sum(value >= MGMT_CFG['estimation_accumulation_candidate_threshold'] for value in finite_scores),
        'diagnostic_accumulation_unavailable_count': len(scores) - len(finite_scores),
        'structural_terminal_count': len(structural_terminals),
        'excluded_terminal_count': sum(bool(getattr(flat_nodes[i], 'measurement_evaluation_excluded', False)) for i in structural_terminals),
        'diagnostic_terminal_count': len(context.diagnostic_terminal_indices),
        'aggregated_diagnostic_terminal_count': len(context.aggregated_diagnostic_terminal_indices),
        'diagnostic_width_unavailable_count': unavailable,
        'uncertain_diagnostic_terminal_count': len(uncertain),
        'evaluation_state': state,
    }

def get_estimation_accumulation(index:int) -> Optional[float]:
    return get_management_context().estimation_accumulation_by_index.get(index)

def is_estimation_accumulation_negative(index:int) -> bool:
    return bool(get_management_context().estimation_accumulation_negative_by_index.get(index, False))

def get_estimation_indicator_values(index:int) -> Tuple[Any, Any, Any, Any, Any, int, int]:
    individual: Any = ''
    downstream: Any = ''
    uncertainty: Any = ''
    accumulation: Any = ''
    if get_node_estimation_state(index) in ('allocated', 'inherited'):
        downstream = get_downstream_confirmed(index)
        uncertainty = get_group_uncertainty(index)
        if not getattr(flat_nodes[index], 'measurement_evaluation_excluded', False):
            energy = coerce_finite_number(flat_nodes[index].energy)
            threshold = float(MGMT_CFG.get(
                'measurement_candidate_threshold_kwh', MGMT_CFG_DEFAULTS['measurement_candidate_threshold_kwh']
            ))
            if energy is not None and energy >= threshold:
                individual = float(energy)
    # 個別推定量以外の診断数値は、CSV・Excelへしきい値未満・0・負値も出力する。
    value = get_estimation_accumulation(index)
    if not is_estimation_accumulation_negative(index) and value is not None and math.isfinite(value):
        accumulation = float(value)
    maximum = get_terminal_theoretical_max(index)
    return (individual, downstream if downstream is not None else '',
            uncertainty if uncertainty is not None else '', maximum if maximum is not None else '',
            accumulation, int(is_measurement_recommended_boundary(index)),
            int(bool(getattr(flat_nodes[index], 'measurement_evaluation_excluded', False))))


def format_estimation_indicator_values(index:int) -> Tuple[str, str, str, str, str, str, str]:
    individual, downstream, uncertainty, maximum, accumulation, boundary, excluded = get_estimation_indicator_values(index)
    if excluded:
        return ('', '', '', '', '', '', '☑')
    group_threshold = float(MGMT_CFG.get(
        'measurement_group_threshold_kwh', MGMT_CFG_DEFAULTS['measurement_group_threshold_kwh']
    ))
    if uncertainty != '' and 0 <= uncertainty < group_threshold:
        uncertainty = ''
    accumulation_threshold = float(MGMT_CFG.get(
        'estimation_accumulation_candidate_threshold',
        MGMT_CFG_DEFAULTS['estimation_accumulation_candidate_threshold']
    ))
    if accumulation != '' and accumulation < accumulation_threshold:
        accumulation = ''
    if has_child(index):
        accumulation = ''
    return (
        f'{individual:,.1f}' if individual != '' else '',
        f'{downstream:,.1f}' if downstream != '' else '',
        f'{uncertainty:,.1f}' if uncertainty != '' else '',
        f'{maximum:,.1f}' if maximum != '' else '',
        f'{accumulation:.3f}' if accumulation != '' else '',
        '●' if boundary else '',
        '□',
    )

def format_tree_estimation_indicator_values(index:int) -> Tuple[str, ...]:
    # CSV・Excelおよび既存の値取得APIの順序は維持し、画面だけを並べ替える。
    values = dict(zip(ESTIMATION_INDICATOR_EXPORT_COLUMNS, format_estimation_indicator_values(index)))
    return tuple(values[column] for column in ESTIMATION_INDICATOR_COLUMNS)


def at_allocation_group_budget_unit_count(index:int) -> int:
    return get_management_context().at_allocation_group_budget_unit_count_by_index.get(index, 0)

def at_allocation_group_has_different_budget_units(index:int) -> bool:
    """このAT按分子が、異なる予算単位を含む兄弟AT按分群に属するか。"""
    if not is_at_allocation_node(index):
        return False
    parent_index = get_parent_index(index)
    return parent_index is not None and at_allocation_group_budget_unit_count(parent_index) >= 2

def is_aggregation_candidate_node(index:int) -> bool:
    node = flat_nodes[index]
    if node.calc_method != '按分':
        return False
    children = get_direct_children(index)
    if not children:
        return False
    return all(child.calc_method in ('実測', '合算') for child in children)

def compute_aggregation_candidate(index:int) -> str:
    if not is_aggregation_candidate_node(index):
        return ''
    return '按分から合算への変更を検討できます'

def compute_parent_at_smaller_than_child(index:int) -> str:
    parent_at = extract_number(flat_nodes[index].at, None)
    if parent_at is None:
        return ''

    child_ats: List[float] = []
    for child_index in get_direct_child_indices(index):
        child_at = extract_number(flat_nodes[child_index].at, None)
        if child_at is not None:
            child_ats.append(float(child_at))

    if not child_ats:
        return ''

    return '親AT小' if float(parent_at) < max(child_ats) else ''

def format_parent_at_small_detail(index:int)->str:
    node = flat_nodes[index]
    parent_at = extract_number(node.at, None)
    child_values: List[Tuple[str, float]] = []
    for child_index in get_direct_child_indices(index):
        child_node = flat_nodes[child_index]
        child_at = extract_number(child_node.at, None)
        if child_at is not None:
            child_values.append((child_node.name, float(child_at)))

    max_child_name = ''
    max_child_at: Optional[float] = None
    if child_values:
        max_child_name, max_child_at = max(child_values, key=lambda item: item[1])

    lines = [
        '親ノードのATが、直属の子ノードの最大ATより小さくなっています。',
        '',
        '保護協調不良を断定するものではありません。',
        '上位ブレーカーが下位ブレーカーより先に動作する可能性や、',
        '下位設備の使用可能容量を過大に見積もっていないかを確認してください。',
        '',
        '厳密な確認には、遮断器の種類、整定値、保護協調曲線、',
        '短絡電流、ケーブル条件、現地構成などの確認が必要です。',
    ]
    if parent_at is not None and max_child_at is not None:
        lines.extend([
            '',
            f'親AT: {format_at_display(node.at)}',
            f'直属子最大AT: {max_child_at:g}（{max_child_name}）',
        ])
    return '\n'.join(lines)

def format_parent_child_difference_detail(index:int)->str:
    node=flat_nodes[index]
    child_total=sum(flat_nodes[j].energy for j in get_direct_child_indices(index))
    diff=node.energy-child_total
    return f"親 {node.energy:.1f} - 子合計 {child_total:.1f} = {diff:.1f} kWh"

# 管理（確認事項）：量・比率CSV の未解決を検出
def get_call_unavailable_reasons(index:int)->List[str]:
    node = flat_nodes[index]
    mn_raw = normalize_value(node.measure_name).strip()
    mn_key = normalize_key(node.measure_name).strip()
    reasons: List[str] = []

    if node.calc_method == '実測':
        if mn_raw == '':
            reasons.append('実測ノードの計量名称が空です')
        elif not measure_master:
            reasons.append(f"実測値を取得できません（量・比率CSV未読込）: {mn_raw}")
        elif mn_key not in measure_master:
            reasons.append(f"実測値を取得できません（計量名称未登録）: {mn_raw}")

    return reasons

def get_ratio_call_unavailable_reasons(index:int)->List[str]:
    node = flat_nodes[index]
    mn_raw = normalize_value(node.measure_name).strip()
    mn_key = normalize_key(node.measure_name).strip()
    reasons: List[str] = []

    if node.calc_method == '按分' and mn_raw != '':
        if not measure_master:
            reasons.append(f"按分比率を取得できません（量・比率CSV未読込）: {mn_raw}")
        elif mn_key not in measure_master:
            reasons.append(f"按分比率を取得できません（計量名称未登録）: {mn_raw}")

    return reasons

def compute_call_unavailable(index:int)->str:
    return '呼出不可' if get_call_unavailable_reasons(index) else ''

def _section_tooltip(title:str, detail:str)->str:
    return f'【{title}】\n{detail}'

def find_structure_validation_issues()->List[Dict[str, Any]]:
    return list(get_tree_structure_index().structure_issues)

def get_structure_validation_issues(severity:Optional[str]=None)->List[Dict[str, Any]]:
    issues = find_structure_validation_issues()
    if severity is None:
        return issues
    return [issue for issue in issues if issue.get('severity') == severity]

def validate_structure_before_export()->List[Dict[str, Any]]:
    return find_structure_validation_issues()

def find_critical_calc_structure_errors()->List[Dict[str, Any]]:
    return list(get_tree_structure_index().critical_issues)

def get_critical_calculation_issues_for_node(index:int)->List[Dict[str, Any]]:
    return list(get_tree_structure_index().critical_issue_by_index.get(index, []))

def get_critical_calc_structure_error_for_parent(index:int)->Optional[Dict[str, Any]]:
    return get_tree_structure_index().aggregation_parent_issue_by_index.get(index)

def compute_calc_method_inconsistency(index:int)->str:
    issues = get_critical_calculation_issues_for_node(index)
    return format_critical_issue_display(issues[0]) if issues else ''

def get_calc_method_inconsistency_indices()->List[int]:
    return [
        issue['parent_index']
        for issue in find_critical_calc_structure_errors()
        if issue.get('code') == 'aggregation_parent_has_allocation_child'
    ]

def format_structure_validation_issue_examples(issues:List[Dict[str, Any]], limit:int=10)->List[str]:
    lines: List[str] = []
    for issue in issues[:limit]:
        if issue.get('code') == 'aggregation_parent_has_allocation_child':
            children = [
                f'{row}行目「{name}」'
                for row, name in zip(issue['child_rows'], issue['child_names'])
            ]
            lines.append(
                f'・{issue["row"]}行目「{issue["node_name"]}」'
                f' → 子 {", ".join(children)}'
            )
        elif issue.get('code') in ('allocation_ratio_invalid', 'allocation_ratio_total_zero') and issue.get('child_rows'):
            children = [f'{row}行目' for row in issue.get('child_rows', [])]
            lines.append(
                f'・{issue["row"]}行目「{issue["node_name"]}」'
                f' → 按分対象 {", ".join(children)}'
            )
        else:
            lines.append(f'・{issue["row"]}行目「{issue["node_name"]}」')
        lines.append(f'　{issue["message"]}')
    if len(issues) > limit:
        lines.append(f'ほか {len(issues) - limit} 件')
    return lines

def format_critical_calc_structure_error_load_warning(errors:List[Dict[str, Any]])->str:
    lines = [
        '計算不能につながるクリティカルな不整合を検出しました。',
        '',
        f'クリティカル不整合: {len(errors)}件',
        '',
        'この状態では電力量を正常に決定できないため、正常な計算結果として扱えません。',
        '',
        '読込データは自動修正していません。',
        '管理（確認事項）や構造検証を確認し、構造、算出方法、按分比率を修正してください。',
        '',
        '該当行:',
    ]
    lines.extend(format_structure_validation_issue_examples(errors))
    return '\n'.join(lines)

def format_calc_method_inconsistency_load_warning(indices:List[int])->str:
    errors = [
        error for error in find_critical_calc_structure_errors()
        if (
            error.get('code') == 'aggregation_parent_has_allocation_child'
            and error.get('parent_index') in indices
        )
    ]
    return format_critical_calc_structure_error_load_warning(errors)

def format_critical_calc_structure_error_export_confirm(errors:List[Dict[str, Any]], target_name:str)->str:
    lines = [
        '計算不能につながるクリティカルな不整合があります。',
        '',
        'この状態では電力量を正常に決定できないため、正常な計算結果として出力できません。',
        '',
        f'クリティカル不整合: {len(errors)}件',
        '',
        '該当行:',
    ]
    lines.extend(format_structure_validation_issue_examples(errors))
    lines.extend(['', '入力内容は保持されています。構造、算出方法、按分比率を修正してから再度出力してください。'])
    return '\n'.join(lines)

def format_critical_calc_structure_error_sankey_error(errors:List[Dict[str, Any]])->str:
    lines = [
        'Sankey図CSVを出力できません。',
        '',
        '計算不能につながるクリティカルな不整合があります。',
        '',
        'この状態では電力量を正常に決定できないため、',
        '構造、算出方法、按分比率を修正してから再度出力してください。',
        '',
        f'クリティカル不整合: {len(errors)}件',
        '',
        '該当行:',
    ]
    lines.extend(format_structure_validation_issue_examples(errors))
    return '\n'.join(lines)

def confirm_analysis_export_with_critical_errors(target_name:str)->bool:
    errors = find_critical_calc_structure_errors()
    if not errors:
        return True
    messagebox.showerror(
        f'{target_name}出力エラー',
        format_critical_calc_structure_error_export_confirm(errors, target_name)
    )
    return False

def build_power_notice_data(structure) -> Dict[int, List[Dict[str, str]]]:
    powers = set(get_power_budget_unit_node_indices())
    overlapping = set()
    nearest_power = {}
    meter_nodes = {}
    for i, node in enumerate(flat_nodes):
        parent = structure.parent_by_index.get(i)
        ancestor = nearest_power.get(parent)
        if i in powers:
            if ancestor is not None:
                overlapping.update((i, ancestor))
            nearest_power[i] = i
            key = normalize_key(node.measure_name).strip()
            if node.calc_method == '実測' and key:
                meter_nodes.setdefault(key, []).append(i)
        else:
            nearest_power[i] = ancestor
    duplicated = {i for indices in meter_nodes.values() if len(indices) > 1 for i in indices}
    result = {}
    for i in sorted(powers):
        items = []
        for matches, code, display, detail in (
            (overlapping, 'power_structure_overlap', '電源重複候補：祖先・子孫に電源指定あり',
             '同じツリーの祖先・子孫にも電源指定があります。同一電力量を供給側へ重複集計する可能性があります。PV・蓄電池等の独立した供給元か、対象期間・供給範囲を確認してください。'),
            (duplicated, 'power_measurement_overlap', '電源重複候補：実測計量名称が重複',
             f'複数の実測電源ノードが同じ計量名称「{flat_nodes[i].measure_name}」を参照しています。供給範囲と二重登録を確認してください。'),
        ):
            if i in matches:
                items.append({'code': code, 'label': display, 'display': display,
                              'detail': detail + '\n確認事項であり、クリティカル不整合ではありません。電源は自動除外・補正しません。'})
        result[i] = items
    return result

def get_management_notice_data(index:int)->List[Dict[str, str]]:
    context_getter = globals().get('get_management_context')
    context = context_getter() if callable(context_getter) else None
    if context is not None and index in context.management_notice_data_by_index:
        return context.management_notice_data_by_index[index]

    items: List[Dict[str, str]] = []

    if context is not None:
        items.extend(context.power_notice_data_by_index.get(index, []))

    if context is not None:
        for label, code, value in (
            ('下流未確定量', 'negative_group_uncertainty', context.group_uncertainty_by_index.get(index)),
            ('末端理論最大値', 'negative_terminal_theoretical_max', context.terminal_theoretical_max_by_index.get(index)),
        ):
            if value is not None and value < 0:
                items.append({
                    'code': code,
                    'label': f'{label}:負値',
                    'display': f'{label}:負値',
                    'detail': (
                        f'対象ノード: {index + 1}行目「{flat_nodes[index].name}」\n'
                        f'{label}: {value:,.6f} kWh\n\n'
                        '下流確定フロンティア合計がノードまたは上流確定境界の電力量を超えています。\n'
                        '対象期間、計測境界、二重登録、親子構造、実測・合算関係を確認してください。\n'
                        '負値は調査用に保持し、CSV・Excelにも出力します。'
                    ),
                })

    call_reasons = get_call_unavailable_reasons(index)
    if call_reasons:
        items.append({
            'code': 'measurement_unavailable',
            'label': '計量名称:呼出不可',
            'display': '計量名称:呼出不可',
            'detail': '\n'.join(call_reasons),
        })

    ratio_call_reasons = get_ratio_call_unavailable_reasons(index)
    if ratio_call_reasons:
        node = flat_nodes[index]
        measure_name = normalize_value(node.measure_name).strip()
        items.append({
            'code': 'ratio_unavailable',
            'label': '按分比率:呼出不可',
            'display': '按分比率:呼出不可',
            'detail': (
                '按分比率を取得できません。\n\n'
                f'計量名称: {measure_name}\n\n'
                '量・比率CSVが未読込、または計量名称が登録されていない可能性があります。\n'
                'このノードの按分比率は0として扱われます。\n'
                '同じ親配下の按分比率合計が0以下になる場合は、計算不能につながるクリティカル不整合になります。\n'
                '量・比率CSVと計量名称を確認してください。\n\n'
                + '\n'.join(ratio_call_reasons)
            ),
        })

    budget_mgmt = compute_budget_unit_management(index)
    if budget_mgmt:
        budget_code = get_budget_unit_code(index) or '空欄'
        if budget_mgmt == '未設定':
            detail = (
                '電力量がある末端ノードですが、\n'
                '予算単位コードが設定されていません。\n\n'
                '配賦対象、収支確認用ノード、Sankey除外対象など、\n'
                '意図的な未設定かどうかを確認してください。'
            )
        else:
            detail = (
                '設定された予算単位コードに対応する名称を、\n'
                '予算単位CSVから取得できません。\n\n'
                f'現在の予算単位コード: {budget_code}\n\n'
                '予算単位コードと予算単位CSVを確認してください。'
            )
        items.append({
            'code': 'budget_unit',
            'label': f'予算単位:{budget_mgmt}',
            'display': f'予算単位:{budget_mgmt}',
            'detail': detail,
        })

    parent_at_small = compute_parent_at_smaller_than_child(index)
    if parent_at_small:
        items.append({
            'code': 'parent_at_small',
            'label': '親AT小',
            'display': '親AT小',
            'detail': format_parent_at_small_detail(index),
        })

    if at_allocation_group_has_different_budget_units(index):
        items.append({
            'code': 'different_budget_allocation',
            'label': '異予算按分',
            'display': '異予算按分',
            'detail': (
                'このノードは、同じ親の残電力量を異なる予算単位へ配分するAT按分群に属します。\n'
                '同じ群の各AT按分子ノードに、この確認事項を繰り返し表示しています。\n'
                '原動配賦上の負担先に影響するため、対象の子回路の実測化、\n'
                '按分根拠、設備構成、予算単位を確認してください。異常を断定するものではありません。'
            ),
        })

    aggregation_candidate = compute_aggregation_candidate(index)
    if aggregation_candidate:
        items.append({
            'code': 'aggregation_candidate',
            'label': '合算候補',
            'display': '合算候補',
            'detail': (
                '現在の算出方法は「按分」ですが、\n'
                '直属の子ノードがすべて「実測」または「合算」です。\n\n'
                '子ノードの合計で親ノードの電力量を表せる可能性があるため、\n'
                f'{aggregation_candidate}。\n\n'
                '算出方法は自動変更されません。\n'
                '孫以下は判定対象に含みません。'
            ),
        })

    critical_issues = get_critical_calculation_issues_for_node(index)
    if critical_issues:
        items.append({
            'code': 'critical_calc_structure_error',
            'label': 'クリティカル',
            'display': '／'.join(format_critical_issue_display(issue) for issue in critical_issues),
            'detail': (
                '正常な計算そのものが成立しない不整合です。\n'
                '入力内容は自動修正されません。\n\n'
                + '\n\n'.join(format_critical_issue_detail(issue) for issue in critical_issues)
            ),
        })

    if context is not None:
        context.management_notice_data_by_index[index] = items
    return items

def format_management_notice_display(index:int)->str:
    context_getter = globals().get('get_management_context')
    context = context_getter() if callable(context_getter) else None
    if context is None:
        return '／'.join(item['display'] for item in get_management_notice_data(index))
    if index not in context.management_notice_display_by_index:
        context.management_notice_display_by_index[index] = '／'.join(
            item['display'] for item in get_management_notice_data(index)
        )
    return context.management_notice_display_by_index[index]

def format_management_notice_tooltip(index:int)->str:
    return '\n\n'.join(
        _section_tooltip(item['label'], item['detail'])
        for item in get_management_notice_data(index)
    )

def format_over_power_detail(index:int)->str:
    node = flat_nodes[index]
    at_num = extract_number(node.at, None)
    lines = [
        '過大電力',
        '',
        '月間電力量が、ATから算出した理論最大電力量に対して',
        '設定しきい値以上となっています。',
        '',
        'この判定は、三相210V、24時間×30日連続運転を基準とした簡易判定です。',
        '単相回路、異なる電圧、実際の力率・負荷率・運転時間などは考慮していません。',
        '厳密な設備容量評価を行うものではありません。',
        '',
        'AT、運転時間、電力量、仮想ノード設定、',
        '計量名称の対応、按分比率などを確認してください。',
        '',
        '特に按分ノードでは、同じ親配下に本来存在する',
        '兄弟ノードが抜け、その分まで吸収している可能性があります。',
    ]
    if at_num is not None and at_num != 0:
        max_e = float(at_num) * math.sqrt(3) * 210 / 1000 * 24 * 30
        ratio = (node.energy / max_e) * 100 if max_e else 0.0
        threshold = float(MGMT_CFG.get(
            'over_power_threshold_percent_of_max',
            MGMT_CFG_DEFAULTS['over_power_threshold_percent_of_max']
        ))
        lines.extend([
            '',
            f'AT: {format_at_display(node.at)}',
            f'現在の電力量: {node.energy:,.1f} kWh',
            f'理論最大電力量: {max_e:,.1f} kWh',
            f'理論最大比率: {ratio:.1f} %',
            f'設定しきい値: {threshold:.1f} %',
        ])
    return '\n'.join(lines)

def format_negative_allocation_detail(index:int)->str:
    node = flat_nodes[index]
    neg_th = float(MGMT_CFG.get(
        'negative_anbun_threshold_kwh',
        MGMT_CFG_DEFAULTS['negative_anbun_threshold_kwh']
    ))
    return (
        '負按分\n\n'
        '按分計算の結果が、設定された負按分しきい値以下です。\n\n'
        '親ノードの電力量より、実測・合算済みの子ノード合計が\n'
        '大きい可能性があります。\n\n'
        '同じ親配下に余分な実測・合算ノードがないか、\n'
        '同じ設備や同じ実測値の二重登録がないかを確認してください。\n\n'
        '実測範囲、計量名称、対象期間、親ノードの電力量、\n'
        '按分対象の構成も確認候補です。\n\n'
        f'対象ノードの電力量: {node.energy:,.1f} kWh\n'
        f'設定しきい値: {neg_th:.1f} kWh'
    )

def format_parent_child_difference_tooltip(index:int)->str:
    return (
        '親子差大\n\n'
        f'{format_parent_child_difference_detail(index)}\n\n'
        '親ノードの電力量と、直属の子ノード合計との差が、\n'
        '設定された親子差分しきい値以上です。\n\n'
        '子ノードの不足、不要な子ノードの混入、未登録負荷、\n'
        '計量範囲、対象期間、入力値、損失、\n'
        '測定境界差分などを確認してください。'
    )

def get_management_cell_tooltip(index:int, col_name:str)->str:
    if col_name == '管理（親子差大）':
        return format_parent_child_difference_tooltip(index)
    if col_name == '管理（過大電力）':
        return format_over_power_detail(index)
    if col_name == '管理（負按分）':
        return format_negative_allocation_detail(index)
    if col_name == '管理（確認事項）':
        return format_management_notice_tooltip(index)
    return ''

MANAGEMENT_HEADING_TOOLTIPS = {
    '管理（親子差大）': '親ノード電力量と直属の子ノード合計との差を表示します。\n設定しきい値以上の場合のみ表示します。',
    '管理（過大電力）': 'ATから算出した理論最大電力量に対する比率が、\n設定しきい値以上の場合に表示します。',
    '管理（負按分）': '按分結果が設定された負按分しきい値以下の場合に、\n負の電力量を表示します。',
    '管理（確認事項）': '計量名称、予算単位、親AT小、異予算按分、合算候補、\nクリティカル不整合などの確認事項をまとめて表示します。\nセルにマウスを合わせると詳細を確認できます。',
}

from anbun_reporting import DEFINITIONS as REPORT_DEFINITIONS

ESTIMATION_INDICATOR_HEADING_TOOLTIPS = {
    '計測評価対象外': '末端の按分ノードをダブルクリックで□/☑切替。計測投資診断から除外し、最も近い非除外の未確定祖先へ集約します。配賦計算・管理通知・出力する内部値は維持します。内部ノードは変更できません。',
    '個別推定量': '計測評価対象外でない未確定按分ノード自身の推定電力量(kWh)です。AT・外部比率とも対象です。表示しきい値を適用します。',
    '下流確定量': dict(REPORT_DEFINITIONS)['下流確定量'],
    '下流未確定量': dict(REPORT_DEFINITIONS)['下流未確定量'],
    '末端理論最大値': dict(REPORT_DEFINITIONS)['末端理論最大値'],
    '経路推定累積度': dict(REPORT_DEFINITIONS)['経路推定累積度'],
    '計測推奨境界': dict(REPORT_DEFINITIONS)['計測推奨境界'],
}

REFERENCE_HEADING_TOOLTIPS = {
    '参考_按分kWh差': (
        '按分単位がkWhの外部比率按分ノードについて、\n'
        '按分比率として入力された値と、実際に算出された電力量との差を参考表示します。\n\n'
        '30日換算実測値であることをアプリが保証するものではありません。\n'
        '差が大きい場合でも異常とは限らず、按分根拠の見直し、\n'
        '必要に応じた再測定、常設計測への切替などを検討するための参考値です。'
    ),
}

def get_heading_tooltip(col_name:str)->str:
    if col_name == '算出方法':
        return (
            '残差算出（確定）：親が確定しており、唯一の按分先を残差で決定します。\n'
            '残差算出（推定継承）：唯一の按分先ですが、上流の推定依存を引き継ぎます。\n'
            'いずれも自動判定する状態表示で、内部算出方法と保存値は「按分」です。'
        )
    return ESTIMATION_INDICATOR_HEADING_TOOLTIPS.get(
        col_name, MANAGEMENT_HEADING_TOOLTIPS.get(col_name, REFERENCE_HEADING_TOOLTIPS.get(col_name, ''))
    )

# ---- 自動幅調整 ----
def _measure_text_width(font, text:str)->int: return font.measure(text if text is not None else '')

def auto_size_tree_columns(tv:ttk.Treeview, cols:List[str], clamp_max:Dict[str,int]=None, numeric_cols:List[str]=None,
                           sample_rows:int=SAMPLE_ROWS_FOR_MEASURE,
                           node_name_width_persist:Optional[int]=None,
                           measure_name_width_persist:Optional[int]=None,
                           assign_name_width_persist:Optional[int]=None):
    clamp_max = clamp_max or {}; numeric_cols = numeric_cols or []
    f = tkfont.nametofont('TkDefaultFont')
    if tv==tree:
        header0='ノード名'; max_w0=_measure_text_width(f, header0)
        for iid in tv.get_children(''): max_w0=max(max_w0, _measure_text_width(f, tv.item(iid,'text')))
        measured0=max_w0+PADDING
        width0=min(node_name_width_persist if (node_name_width_persist and node_name_width_persist>0) else measured0, MAX_NODE_NAME_WIDTH)
        tv.column('#0', width=width0, stretch=False)
    all_items = tv.get_children('')
    items_to_check = all_items[:sample_rows] if sample_rows>0 and len(all_items)>sample_rows else all_items
    for col in cols:
        max_w=_measure_text_width(f,get_tree_heading_label(col))
        for iid in items_to_check:
            v=str(tv.set(iid,col)); max_w=max(max_w,_measure_text_width(f,v))
        width=max_w+PADDING
        if col=='計量名称' and (saved_measure_name_width and saved_measure_name_width>0): width = int(saved_measure_name_width)
        if col=='予算単位コード' and (saved_assign_name_width and saved_assign_name_width >0): width = int(saved_assign_name_width)
        if col=='詳細２' and (saved_detail2_width and saved_detail2_width >0): width = int(saved_detail2_width)
        if col in clamp_max: width=min(width, clamp_max[col])
        if col == '予算単位コード': tv.column(col, width=width, stretch=False, anchor='center')
        elif col in numeric_cols: tv.column(col, width=width, stretch=False, anchor='e')
        else: tv.column(col, width=width, stretch=False)

# ---- 描画 ----

def draw_tree(recalculate: bool = True):
    if recalculate:
        calculate_energy()
    tree.delete(*tree.get_children('')); node_ids.clear()
    table_row_no=1
    for i,node in enumerate(flat_nodes):
        parent_index = get_parent_index(i)
        parent_id = node_ids.get(parent_index, '') if parent_index is not None else ''
        budget_code=get_budget_unit_code(i)
        budget_name=get_budget_unit_name(i)
        budget_mgmt=compute_budget_unit_management(i)
        ratio_str=format_ratio_display(node.ratio) if node.calc_method=='按分' else ''
        unit_str=format_ratio_unit_display(node)
        energy_str=format_energy_display(node.energy)
        m1,m2,m3=compute_management_values(i)
        management_notice=format_management_notice_display(i)
        disp_method = get_display_method(i)
        nid=tree.insert(parent_id,'end', text=node.name, values=(
            node.detail1,node.detail2,format_at_tree_display(node),method_with_icon(disp_method),node.measure_name,ratio_str,unit_str,energy_str,
            budget_code,budget_name,node.electric_room,node.transformer,node.category1,node.category2,node.category3,get_effective_sankey_category(i),notes_with_icon(node.notes),m1,m2,m3,management_notice,*format_tree_estimation_indicator_values(i),node.reference_measure_name,format_reference_value_display(node),node.reference_unit,format_signed_kwh_reference_difference(node),table_row_no
        ), tags=(f"depth{node.depth}",))
        tree.item(nid, open=depth_open_state.get(node.depth, True))
        node_ids[i]=nid; table_row_no+=1
    for d in range(MAX_DEPTH+1):
        tree.tag_configure(f'depth{d}', background=_depth_color(d))
    auto_size_tree_columns(
        tree, list(columns),
        clamp_max={'予算単位コード':MAX_ASSIGN_NAME_WIDTH, '計量名称':MAX_MEASURE_NAME_WIDTH, '詳細２':MAX_DETAIL2_WIDTH, '管理（確認事項）':360},
        numeric_cols=['行番号','按分比率','電力量','個別推定量','下流確定量','下流未確定量','末端理論最大値','経路推定累積度','計測推奨境界','計測評価対象外','管理（親子差大）','管理（過大電力）','管理（負按分）','参考値','参考_按分kWh差'],
        sample_rows=SAMPLE_ROWS_FOR_MEASURE,
        node_name_width_persist=saved_node_name_width,
        measure_name_width_persist=saved_measure_name_width,
        assign_name_width_persist=saved_assign_name_width
    )

# ---- Undo/Redo ----
history_stack: List[List[FlatNode]]=[]; redo_stack: List[List[FlatNode]]=[]

def push_history(): history_stack.append(copy.deepcopy(flat_nodes)); redo_stack.clear()

def undo():
    if not history_stack: return
    redo_stack.append(copy.deepcopy(flat_nodes)); prev=history_stack.pop()
    flat_nodes.clear(); flat_nodes.extend(prev)
    invalidate_all_runtime_caches()
    redraw_preserving_state()

def redo():
    if not redo_stack: return
    history_stack.append(copy.deepcopy(flat_nodes)); nxt=redo_stack.pop()
    flat_nodes.clear(); flat_nodes.extend(nxt)
    invalidate_all_runtime_caches()
    redraw_preserving_state()

# ---- 状態保存/復元（選択・スクロール・開閉） ----

def get_selected_indices()->List[int]:
    selected = []
    node_id_values = list(node_ids.values())
    for iid in tree.selection():
        try:
            selected.append(node_id_values.index(iid))
        except ValueError:
            pass
    return sorted(set(selected))

def get_index_for_iid(iid:str)->Optional[int]:
    if not iid:
        return None
    for index, node_iid in node_ids.items():
        if node_iid == iid:
            return index
    return None

def _open_ancestors_for_index(index:int):
    structure = get_tree_structure_index()
    parent_index = structure.parent_by_index.get(index)
    ancestors = []
    visited = set()
    while parent_index is not None and parent_index not in visited:
        visited.add(parent_index)
        ancestors.append(parent_index)
        parent_index = structure.parent_by_index.get(parent_index)
    for ancestor_index in reversed(ancestors):
        iid = node_ids.get(ancestor_index)
        if iid:
            tree.item(iid, open=True)

def jump_to_node_index(index:int)->bool:
    if not (0 <= index < len(flat_nodes)):
        return False
    iid = node_ids.get(index)
    if iid is None:
        draw_tree()
        iid = node_ids.get(index)
    if iid is None:
        return False
    _open_ancestors_for_index(index)
    tree.selection_set(iid)
    tree.focus(iid)
    tree.see(iid)
    tree.focus_set()
    return True

def jump_to_row_number(row_no:int)->bool:
    return jump_to_node_index(row_no - 1)

def _snapshot_tree_state():
    selected_indices = get_selected_indices()
    selected_index = selected_indices[0] if selected_indices else None
    y0, y1 = tree.yview()
    open_state_by_index = {}
    for idx, iid in node_ids.items():
        try:
            open_state_by_index[idx] = bool(tree.item(iid, 'open'))
        except Exception:
            pass
    return {
        'selected_index': selected_index,
        'selected_indices': selected_indices,
        'yview': (y0, y1),
        'open': open_state_by_index,
    }


def _restore_tree_state(state):
    if not state: return
    open_map = state.get('open', {})
    for idx, iid in node_ids.items():
        if idx in open_map:
            try:
                tree.item(iid, open=open_map[idx])
            except Exception:
                pass
    y0, y1 = state.get('yview', (None, None))
    if y0 is not None:
        try:
            tree.yview_moveto(y0)
        except Exception:
            pass
    selected_indices = state.get('selected_indices')
    if selected_indices is None:
        sel_idx = state.get('selected_index', None)
        selected_indices = [] if sel_idx is None else [sel_idx]
    iids = [node_ids[index] for index in selected_indices if index in node_ids]
    if iids:
        tree.selection_set(iids)
        focus_iid = iids[0]
        tree.focus(focus_iid); tree.see(focus_iid); tree.focus_set()

def redraw_preserving_state(state=None):
    if state is None:
        state = _snapshot_tree_state()
    draw_tree()
    _restore_tree_state(state)

def update_node_and_redraw(index:int, updater, preserve_state:bool=True):
    state = _snapshot_tree_state() if preserve_state else None
    push_history()
    updater(flat_nodes[index])
    invalidate_all_runtime_caches()
    redraw_preserving_state(state)

# ---- 1行軽量更新 ----

def refresh_row(index: int):
    if index not in node_ids: return
    apply_budget_unit_structure_rules()
    node = flat_nodes[index]
    iid = node_ids[index]
    budget_code = get_budget_unit_code(index)
    budget_name = get_budget_unit_name(index)
    budget_mgmt = compute_budget_unit_management(index)
    ratio_str = format_ratio_display(node.ratio) if node.calc_method == '按分' else ''
    unit_str = format_ratio_unit_display(node)
    energy_str = format_energy_display(node.energy)
    m1, m2, m3 = compute_management_values(index)
    management_notice = format_management_notice_display(index)
    disp_method = get_display_method(index)
    tree.item(iid, text=node.name)
    tree.set(iid, '詳細１', node.detail1)
    tree.set(iid, '詳細２', node.detail2)
    tree.set(iid, 'AT', format_at_tree_display(node))
    tree.set(iid, '算出方法', method_with_icon(disp_method))
    tree.set(iid, '計量名称', node.measure_name)
    tree.set(iid, '按分比率', ratio_str)
    tree.set(iid, '按分単位', unit_str)
    tree.set(iid, '電力量', energy_str)
    for column, value in zip(ESTIMATION_INDICATOR_COLUMNS, format_tree_estimation_indicator_values(index)):
        tree.set(iid, column, value)
    tree.set(iid, '予算単位コード', budget_code)
    tree.set(iid, '予算単位名称', budget_name)
    tree.set(iid, '属性(Sankey分類)', get_effective_sankey_category(index))
    tree.set(iid, '電気室', node.electric_room)
    tree.set(iid, '変圧器', node.transformer)
    tree.set(iid, '分類１', getattr(node, 'category1',''))
    tree.set(iid, '分類２', getattr(node, 'category2',''))
    tree.set(iid, '分類３', getattr(node, 'category3',''))
    tree.set(iid, '備考', notes_with_icon(node.notes))
    tree.set(iid, '管理（親子差大）', m1)
    tree.set(iid, '管理（過大電力）', m2)
    tree.set(iid, '管理（負按分）', m3)
    tree.set(iid, '管理（確認事項）', management_notice)
    tree.set(iid, '参考計量名称', node.reference_measure_name)
    tree.set(iid, '参考値', format_reference_value_display(node))
    tree.set(iid, '参考単位', node.reference_unit)
    tree.set(iid, '参考_按分kWh差', format_signed_kwh_reference_difference(node))
    tree.set(iid, '行番号', index + 1)

# ---- 編集（ダブルクリック） ----

def toggle_measurement_evaluation_excluded(index:int) -> bool:
    if flat_nodes[index].calc_method != '按分' or has_child(index):
        messagebox.showinfo('計測評価対象外', '初回実装では末端の按分ノードだけを変更できます。内部ノード・実測・合算は対象外です。')
        return False
    state = _snapshot_tree_state()
    push_history()
    node = flat_nodes[index]
    node.measurement_evaluation_excluded = not getattr(node, 'measurement_evaluation_excluded', False)
    invalidate_management_cache()
    draw_tree(recalculate=False)
    _restore_tree_state(state)
    return True


def on_double_click(event):
    global saved_measure_name_width, saved_assign_name_width, saved_detail2_width
    item = tree.identify_row(event.y)
    column = tree.identify_column(event.x)
    if not item:
        return None
    index = list(node_ids.values()).index(item)
    node = flat_nodes[index]

    col_name = get_treeview_column_name(tree, column)
    if col_name is None:
        return 'break'

    if col_name == '計測評価対象外':
        toggle_measurement_evaluation_excluded(index)
        return 'break'

    if col_name == '#0':
        x, y, w, h = tree.bbox(item, column)
        e = tk.Entry(tree)
        e.place(x=x, y=y, width=w, height=h)
        e.insert(0, node.name)
        committed = False
        def commit():
            nonlocal committed
            if committed:
                return
            committed = True
            new_name = e.get()
            if node.name != new_name:
                push_history()
                node.name = new_name
                invalidate_all_runtime_caches()
            e.destroy()
            refresh_row(index)
        e.bind('<Return>', lambda _: commit())
        e.bind('<FocusOut>', lambda _: commit())
        e.focus()
        return 'break'

    attr = column_attr_map.get(col_name)
    x, y, w, h = tree.bbox(item, column)

    if col_name == '詳細２':
        try:
            saved_detail2_width = int(tree.column('詳細２', 'width'))
        except Exception:
            pass

    if col_name in ['行番号','電力量','按分比率','按分単位','予算単位名称',*ESTIMATION_INDICATOR_COLUMNS,'管理（親子差大）','管理（過大電力）','管理（負按分）','管理（確認事項）','参考値','参考単位','参考_按分kWh差']:
        return 'break'
    if attr is None and col_name not in ['算出方法','AT','計量名称','予算単位コード','参考計量名称']:
        return 'break'

    if col_name == '算出方法':
        combo = ttk.Combobox(tree, values=list(CALC_METHOD_CHOICES), state='readonly')
        combo.place(x=x, y=y, width=w, height=h)
        combo.set(node.calc_method)
        def commit():
            new = sanitize_calc_method(combo.get())
            if not new:
                combo.destroy()
                messagebox.showwarning('算出方法の変更', '算出方法が不正なため変更できません。')
                return
            if new == node.calc_method:
                combo.destroy()
                return
            allowed, warning = validate_calc_method_change(index, new)
            if not allowed:
                combo.destroy()
                messagebox.showwarning('算出方法の変更', warning)
                return
            def updater(current: FlatNode):
                current.calc_method = new
                apply_measure_master_to_node(current)
            combo.destroy()
            update_node_and_redraw(index, updater)
        bind_combobox_commit(combo, commit)
        open_combobox_dropdown(combo)
        return 'break'

    elif col_name == 'AT':
        e = tk.Entry(tree)
        e.place(x=x, y=y, width=w, height=h)
        e.insert(0, format_at_display(node.at))
        committed = False
        def commit():
            nonlocal committed
            if committed:
                return
            committed = True
            new_at = e.get()
            num = extract_number(new_at, None)
            new_at = str(int(round(num))) if num is not None else new_at
            if node.at == new_at:
                e.destroy()
                return
            def updater(current: FlatNode):
                current.at = new_at
            e.destroy()
            update_node_and_redraw(index, updater)
        e.bind('<Return>', lambda _: commit())
        e.bind('<FocusOut>', lambda _: commit())
        e.focus()
        return 'break'

    elif col_name == '計量名称':
        try:
            saved_measure_name_width = int(tree.column('計量名称', 'width'))
        except Exception:
            pass
        cand = sorted(measure_master.keys()) if measure_master else sorted(measure_name_options)
        combo = ttk.Combobox(tree, values=cand)
        combo.place(x=x, y=y, width=w, height=h)
        combo.set(normalize_key(node.measure_name))
        def commit():
            raw = normalize_value(combo.get())
            if raw == node.measure_name:
                combo.destroy()
                return
            def updater(current: FlatNode):
                current.measure_name = raw
                apply_measure_master_to_node(current)
            combo.destroy()
            update_node_and_redraw(index, updater)
        bind_combobox_commit(combo, commit)
        combo.focus()
        return 'break'

    elif col_name == '参考計量名称':
        cand = sorted(measure_master.keys()) if measure_master else sorted(measure_name_options)
        combo = ttk.Combobox(tree, values=cand)
        combo.place(x=x, y=y, width=w, height=h)
        combo.set(normalize_key(node.reference_measure_name))
        def commit():
            raw = normalize_value(combo.get())
            if raw == node.reference_measure_name:
                combo.destroy()
                return
            def updater(current: FlatNode):
                current.reference_measure_name = raw
                apply_reference_measure_value_to_node(current)
            combo.destroy()
            update_node_and_redraw(index, updater)
        bind_combobox_commit(combo, commit)
        combo.focus()
        return 'break'

    elif col_name == '予算単位コード':
        try:
            saved_assign_name_width = int(tree.column('予算単位コード', 'width'))
        except Exception:
            pass
        combo = ttk.Combobox(tree, values=get_budget_unit_edit_values(index), state='readonly')
        combo.place(x=x, y=y, width=w, height=h)
        combo.set(format_budget_unit_combo_display(get_effective_budget_unit_code(index)))
        def commit():
            raw = parse_budget_unit_combo_display(combo.get())
            changed = set_budget_unit_code(index, raw)
            combo.destroy()
            if changed:
                redraw_preserving_state()
        bind_combobox_commit(combo, commit)
        open_combobox_dropdown(combo)
        return 'break'

    else:
        e = tk.Entry(tree)
        e.place(x=x, y=y, width=w, height=h)
        e.insert(0, str(getattr(node, attr)))
        committed = False
        def commit():
            nonlocal committed
            if committed:
                return
            committed = True
            try:
                val = e.get()
                if attr in ['ratio','energy']:
                    numeric = float(val)
                    e.destroy()
                    if getattr(node, attr) == numeric:
                        return
                    def updater(current: FlatNode):
                        setattr(current, attr, numeric)
                    update_node_and_redraw(index, updater)
                    return
                else:
                    if getattr(node, attr) != val:
                        push_history()
                        setattr(node, attr, val)
                        invalidate_all_runtime_caches()
            except ValueError:
                pass
            e.destroy()
            refresh_row(index)
        e.bind('<Return>', lambda _: commit())
        e.bind('<FocusOut>', lambda _: commit())
        e.focus()
        return 'break'

tree.bind('<Double-1>', on_double_click)

# === 列幅の手動リサイズを即時保存 ===
_last_widths = {'#0': None, '計量名称': None, '予算単位コード': None, '詳細２': None}

def _snapshot_widths():
    try:
        _last_widths['#0'] = int(tree.column('#0','width'))
        _last_widths['計量名称'] = int(tree.column('計量名称','width'))
        _last_widths['予算単位コード']= int(tree.column('予算単位コード','width'))
        _last_widths['詳細２'] = int(tree.column('詳細２','width'))
    except Exception:
        pass

def _maybe_save_resized_columns(event=None):
    global saved_node_name_width, saved_measure_name_width, saved_assign_name_width, saved_detail2_width
    changed = False
    try:
        w0 = int(tree.column('#0','width'))
        w1 = int(tree.column('計量名称','width'))
        w2 = int(tree.column('予算単位コード','width'))
        w3 = int(tree.column('詳細２','width'))
    except Exception:
        return
    if _last_widths.get('#0') != w0: saved_node_name_width = min(w0, MAX_NODE_NAME_WIDTH); changed = True
    if _last_widths.get('計量名称') != w1: saved_measure_name_width = min(w1, MAX_MEASURE_NAME_WIDTH); changed = True
    if _last_widths.get('予算単位コード')!= w2: saved_assign_name_width = min(w2, MAX_ASSIGN_NAME_WIDTH); changed = True
    if _last_widths.get('詳細２') != w3: saved_detail2_width = min(w3, MAX_DETAIL2_WIDTH); changed = True
    _snapshot_widths()
    if changed:
        try: save_config()
        except Exception: pass

# イベント
tree.bind('<ButtonRelease-1>', _maybe_save_resized_columns)
management_tooltip = TreeviewManagementTooltip(tree)

def _on_root_configure(event):
    # 子ウィジェットの配置イベントではツールチップを閉じない。
    if event.widget is root:
        _snapshot_widths()
        management_tooltip.hide()

root.bind('<Configure>', _on_root_configure)

# ---- 管理行ウィンドウ ----
def show_management_rows_window():
    top=tk.Toplevel(root); top.title('管理行（管理列に該当する行番号と理由＋内容）'); top.geometry('620x600')
    frame=ttk.Frame(top); frame.pack(fill='both', expand=True)
    tv=ttk.Treeview(frame, show='headings')
    vsb=ttk.Scrollbar(frame, orient='vertical', command=tv.yview)
    hsb=ttk.Scrollbar(frame, orient='horizontal', command=tv.xview)
    tv.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    cols=('行番号','理由','内容'); tv['columns']=cols
    for c in cols: tv.heading(c, text=get_tree_heading_label(c))
    tv.grid(row=0,column=0,sticky='nsew'); vsb.grid(row=0,column=1,sticky='ns'); hsb.grid(row=1,column=0,sticky='ew')
    frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)
    def refresh():
        tv.delete(*tv.get_children(''))
        for row_no,_ in enumerate(flat_nodes, start=1):
            idx=row_no-1
            m1,m2,m3=compute_management_values(idx)
            reasons=[]; contents=[]
            if m1:
                reasons.append('親子差大')
                contents.append(format_parent_child_difference_detail(idx))
            if m2:
                reasons.append('過大電力')
                contents.append(format_over_power_detail(idx).replace('\n', ' '))
            if m3:
                reasons.append('負按分')
                contents.append(format_negative_allocation_detail(idx).replace('\n', ' '))
            for item in get_management_notice_data(idx):
                reasons.append(item['label'])
                contents.append(item['detail'].replace('\n', ' '))
            if reasons:
                tv.insert('', 'end', values=(row_no, '／'.join(reasons), ' ／ '.join(contents)))
        auto_size_tree_columns(tv, list(cols), clamp_max={}, numeric_cols=['行番号'], sample_rows=SAMPLE_ROWS_FOR_MEASURE)
    def jump():
        sel=tv.selection()
        if not sel: return
        vals=tv.item(sel[0],'values')
        if not vals: return
        try: idx=int(vals[0])-1
        except (TypeError, ValueError): return
        jump_to_node_index(idx)
    refresh(); btn=ttk.Frame(top); btn.pack(fill='x', padx=8, pady=8)
    ttk.Button(btn, text='更新', command=refresh).pack(side='right')
    ttk.Button(btn, text='ジャンプ', command=jump).pack(side='right', padx=(0,8))
    tv.bind('<Double-1>', lambda e: jump())

def show_structure_validation_window():
    top=tk.Toplevel(root); top.title('構造検証'); top.geometry('760x520')
    frame=ttk.Frame(top); frame.pack(fill='both', expand=True)
    tv=ttk.Treeview(frame, show='headings')
    vsb=ttk.Scrollbar(frame, orient='vertical', command=tv.yview)
    hsb=ttk.Scrollbar(frame, orient='horizontal', command=tv.xview)
    tv.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    cols=('行番号','重大度','種別','ノード名','内容')
    tv['columns']=cols
    for c in cols: tv.heading(c, text=get_tree_heading_label(c))
    tv.grid(row=0,column=0,sticky='nsew'); vsb.grid(row=0,column=1,sticky='ns'); hsb.grid(row=1,column=0,sticky='ew')
    frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)

    def refresh():
        tv.delete(*tv.get_children(''))
        issues = find_structure_validation_issues()
        for issue in issues:
            tv.insert('', 'end', values=(
                issue['row'],
                format_severity_for_display(issue['severity']),
                issue.get('display') or issue['code'],
                issue['node_name'],
                issue['message'],
            ))
        if not issues:
            tv.insert('', 'end', values=('', 'OK', '', '', 'クリティカル不整合はありません'))
        auto_size_tree_columns(tv, list(cols), clamp_max={'内容':420, 'ノード名':240}, numeric_cols=['行番号'], sample_rows=SAMPLE_ROWS_FOR_MEASURE)

    def jump():
        sel=tv.selection()
        if not sel: return
        vals=tv.item(sel[0],'values')
        if not vals or vals[0] in ('', None): return
        try: idx=int(vals[0])-1
        except (TypeError, ValueError): return
        jump_to_node_index(idx)

    refresh(); btn=ttk.Frame(top); btn.pack(fill='x', padx=8, pady=8)
    ttk.Button(btn, text='更新', command=refresh).pack(side='right')
    ttk.Button(btn, text='ジャンプ', command=jump).pack(side='right', padx=(0,8))
    tv.bind('<Double-1>', lambda e: jump())

# ---- 量・比率CSV 読み込み（マスタ表示＋参照回数） ----
def _get_first(d:Dict[str,Any], keys:List[str])->str:
    for k in keys:
        if k in d and d[k] not in (None,''):
            return str(d[k])
    return ''

def parse_measure_quantity_or_error(raw_value:Any, file_path:str, row_no:int, measure_name:str)->Tuple[Optional[float], Optional[str]]:
    text = normalize_value(raw_value)
    if text == '':
        return 0.0, None
    try:
        value = float(text.replace(',', ''))
    except (TypeError, ValueError):
        value = None
    if value is None or not math.isfinite(value):
        return None, (
            f'{os.path.basename(file_path)} {row_no}行目\n'
            f'計量名称: {measure_name}\n'
            f'量・比率: {text}\n\n'
            '量・比率を数値として読み取れません。\n'
            'CSVを修正してから再度読み込んでください。'
        )
    return value, None

def _count_measure_calls_in_table():
    cnt={}
    for n in flat_nodes:
        key=normalize_key(n.measure_name)
        if not key: continue
        cnt[key]=cnt.get(key,0)+1
    return cnt

def format_file_mtime(path:str)->Tuple[str, Optional[str]]:
    try:
        ts = os.path.getmtime(path)
        return datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S'), None
    except FileNotFoundError:
        return '', 'ファイルが見つかりません'
    except OSError as e:
        return '', f'更新日時を取得できません: {e}'

def short_folder_path(path:str, max_len:int=48)->str:
    folder = os.path.dirname(path)
    if not folder:
        return ''
    base = os.path.basename(folder) or folder
    if len(folder) <= max_len:
        return folder
    parent = os.path.basename(os.path.dirname(folder))
    compact = os.path.join('...', parent, base) if parent else os.path.join('...', base)
    return compact if len(compact) <= max_len else '...' + folder[-(max_len-3):]

def is_csv_path(path:str)->bool:
    return os.path.isfile(path) and os.path.splitext(path)[1].lower() == '.csv'

def same_file_path(a:Optional[str], b:Optional[str])->bool:
    if not a or not b:
        return False
    return os.path.abspath(a).lower() == os.path.abspath(b).lower()

def same_file_path_list(a:List[str], b:List[str])->bool:
    if len(a) != len(b):
        return False
    return [os.path.abspath(p).lower() for p in a] == [os.path.abspath(p).lower() for p in b]

def parse_dropped_file_paths(widget, data:str)->List[str]:
    try:
        raw_paths = widget.tk.splitlist(data)
    except tk.TclError:
        raw_paths = re.findall(r'\{([^}]*)\}|(\S+)', data or '')
        raw_paths = [a or b for a, b in raw_paths]
    return [os.path.normpath(p) for p in raw_paths if p]

def looks_like_tree_or_analysis_csv_rows(rows:List[Dict[str, Any]])->bool:
    tree_markers = {'階層', 'ノード名', '算出方法', '電力量'}
    for row in rows[:5]:
        normalized_headers = {normalize_header(header) for header in row.keys()}
        if len(tree_markers & normalized_headers) >= 2:
            return True
    return False

def read_measure_master_csv_files(paths:List[str])->Tuple[Optional[MeasureCsvLoadResult], Optional[str]]:
    new_master: Dict[str, Dict[str, Any]] = {}
    total = 0
    duplicate_count = 0
    file_statuses: List[CsvFileStatus] = []
    for p in paths:
        if not os.path.exists(p):
            return None, f'{os.path.basename(p)}: ファイルが見つかりません'
        if os.path.splitext(p)[1].lower() != '.csv':
            return None, f'{os.path.basename(p)}: CSVファイルではありません'
        rows = read_csv_dicts_with_fallback(p)
        qty_headers = ['量・比率(元)', '量・比率', '量']
        if not looks_like_tree_or_analysis_csv_rows(rows):
            qty_headers.append('按分比率')
        file_rows = 0
        file_dups = 0
        for row_no, r in enumerate(rows, start=2):
            name=_get_first(r,['計量名称(元)','計量名称']).strip()
            if not name: continue
            qty=_get_first(r,qty_headers)
            unit=_get_first(r,['単位(元)','単位','按分単位','unit']).strip()
            basis_note=_get_first(r,[MEASURE_BASIS_NOTE_HEADER])
            qv, quantity_error = parse_measure_quantity_or_error(qty, p, row_no, name)
            if quantity_error:
                return None, quantity_error
            key = normalize_key(name)
            if key in new_master:
                duplicate_count += 1
                file_dups += 1
            new_master[key]={
                '量・比率(元)': qv,
                '単位(元)': unit,
                MEASURE_BASIS_NOTE_HEADER: basis_note,
            }
            total+=1
            file_rows+=1
        result = f'正常、{file_rows:,}件'
        if file_dups:
            result += f'、重複キー{file_dups:,}件、後のファイルを採用'
        file_statuses.append(CsvFileStatus(path=p, status='正常', result=result, row_count=file_rows, duplicate_count=file_dups))
    return MeasureCsvLoadResult(new_master, total, len(new_master), duplicate_count, file_statuses), None

def apply_measure_master_load_result(result:MeasureCsvLoadResult, paths:List[str], show_view:bool=True):
    measure_master.clear()
    measure_master.update(result.master)
    current_input_files["measure"] = list(paths)
    invalidate_all_runtime_caches()
    redraw_preserving_state()
    save_config()
    print('[量・比率] 取り込み件数:', result.total_rows, '/ 一意キー数:', result.unique_count)
    if show_view:
        show_measure_master_window()

def show_measure_master_window():
    norm_map = {}
    for k in measure_master.keys():
        nk = normalize_key(k).lower()
        norm_map.setdefault(nk, []).append(k)
    dup_keys = {nk for nk, lst in norm_map.items() if len(lst) > 1}
    top=tk.Toplevel(root); top.title('量・比率CSV（マスタ表示＋参照回数）'); top.geometry('920x520')
    frame=ttk.Frame(top); frame.pack(fill='both', expand=True)
    tv=ttk.Treeview(frame, show='headings'); vsb=ttk.Scrollbar(frame, orient='vertical', command=tv.yview); hsb=ttk.Scrollbar(frame, orient='horizontal', command=tv.xview)
    tv.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    cols=('計量名称(元)','量・比率(元)','単位(元)','参照回数'); tv['columns']=cols
    for c in cols: tv.heading(c, text=get_tree_heading_label(c))
    tv.grid(row=0,column=0,sticky='nsew'); vsb.grid(row=0,column=1,sticky='ns'); hsb.grid(row=1,column=0,sticky='ew')
    frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)
    tv.tag_configure('dup', background='#ffe6e6')
    def refresh():
        tv.delete(*tv.get_children(''))
        calls=_count_measure_calls_in_table()
        for k,v in sorted(measure_master.items()):
            tags=('dup',) if normalize_key(k).lower() in dup_keys else ()
            tv.insert('', 'end', values=(k, v['量・比率(元)'], v['単位(元)'], calls.get(normalize_key(k),0)), tags=tags)
        auto_size_tree_columns(tv, list(cols), clamp_max={}, numeric_cols=['量・比率(元)','参照回数'], sample_rows=SAMPLE_ROWS_FOR_MEASURE)
    refresh()
    ttk.Button(top, text='更新', command=refresh).pack(anchor='e', padx=8, pady=8)

def load_measure_master_csv():
    paths=filedialog.askopenfilenames(filetypes=[('CSVファイル','*.csv')], title='量・比率CSVを選択')
    if not paths: return
    result, error = read_measure_master_csv_files(list(paths))
    if error:
        messagebox.showerror('実測値・按分比率CSV読込エラー', error)
        return
    apply_measure_master_load_result(result, list(paths), show_view=True)

# ---- 予算単位CSV 読み込み（マスタ表示＋参照回数） ----
def trim_budget_csv_cell(v:Any)->str:
    if v is None:
        return ''
    return str(v).replace('\ufeff','').replace('\u00A0',' ').strip()

def read_budget_unit_master_csv_files(paths)->Tuple[Optional[Dict[str, str]], int, Optional[str]]:
    new_master: Dict[str, str] = {}
    total=0
    for p in paths:
        last_error = None
        loaded = False
        for enc in ('utf-8-sig','cp932','utf-8'):
            try:
                with open(p,'r',encoding=enc,newline='') as f:
                    reader=csv.DictReader(f)
                    for row_no, row in enumerate(reader, start=2):
                        if not row:
                            continue
                        r={normalize_header(k): trim_budget_csv_cell(v) for k,v in row.items() if k is not None}
                        if not any(r.values()):
                            continue
                        code=r.get('予算単位コード','')
                        name=r.get('予算単位名称','')
                        if code == '':
                            return None, total, f'{os.path.basename(p)} {row_no}行目: 予算単位コードが空です'
                        key=normalize_key(code)
                        if key in new_master:
                            return None, total, f'{os.path.basename(p)} {row_no}行目: 予算単位コードが重複しています（{code}）'
                        new_master[key]=name
                        total+=1
                print(f"[CSV] '{p}' 読み込み成功（{enc}）")
                loaded = True
                break
            except Exception as e:
                last_error = e
                print(f"[CSV] '{p}' 読み込み失敗（{enc}）: {e}")
        if not loaded:
            return None, total, f'{os.path.basename(p)} を読み込めませんでした: {last_error}'
    return new_master, total, None

def load_budget_unit_master_from_paths(paths:List[str])->Tuple[Optional[BudgetCsvLoadResult], Optional[str]]:
    for p in paths:
        if not os.path.exists(p):
            return None, f'{os.path.basename(p)}: ファイルが見つかりません'
        if os.path.splitext(p)[1].lower() != '.csv':
            return None, f'{os.path.basename(p)}: CSVファイルではありません'
    new_master, total, error = read_budget_unit_master_csv_files(paths)
    if error:
        return None, error
    return BudgetCsvLoadResult(new_master, total, len(new_master)), None

def apply_budget_unit_master_load_result(result:BudgetCsvLoadResult, path:str, show_view:bool=True):
    global budget_csv_auto_loaded, budget_csv_auto_load_message
    budget_unit_master.clear()
    budget_unit_master.update(result.master)
    current_input_files["budget"] = path
    config_input_file_candidates["budget"] = path
    budget_csv_auto_loaded = False
    budget_csv_auto_load_message = ''
    invalidate_management_cache()
    redraw_preserving_state()
    save_config()
    print('[予算単位] 取り込み件数:', result.total_rows, '/ 一意キー数:', result.unique_count)
    if show_view:
        show_budget_unit_master_window()

def clear_budget_unit_master_selection(show_message:bool=True):
    global budget_csv_auto_loaded, budget_csv_auto_load_message
    budget_unit_master.clear()
    current_input_files["budget"] = None
    config_input_file_candidates["budget"] = None
    budget_csv_auto_loaded = False
    budget_csv_auto_load_message = '予算単位CSVの選択を解除しました。'
    invalidate_management_cache()
    redraw_preserving_state()
    save_config()
    if show_message:
        messagebox.showinfo('予算単位CSV', '予算単位CSVの選択を解除しました。\n必要に応じて、別の予算単位CSVを読み込んでください。')

def auto_load_budget_unit_master_csv_from_config():
    global budget_csv_auto_loaded, budget_csv_auto_load_message
    path = config_input_file_candidates.get("budget")
    budget_csv_auto_loaded = False
    budget_csv_auto_load_message = ''
    if not path:
        return
    if not os.path.exists(path):
        budget_csv_auto_load_message = f'前回の予算単位CSVが見つかりません: {os.path.basename(path)}'
        print('[予算単位] 自動読込スキップ:', budget_csv_auto_load_message)
        current_input_files["budget"] = None
        config_input_file_candidates["budget"] = None
        save_config()
        return
    result, error = load_budget_unit_master_from_paths([path])
    if error:
        budget_csv_auto_load_message = f'前回の予算単位CSVを自動読込できませんでした: {error}'
        print('[予算単位] 自動読込失敗:', budget_csv_auto_load_message)
        current_input_files["budget"] = None
        config_input_file_candidates["budget"] = None
        save_config()
        try:
            messagebox.showwarning('予算単位CSV自動読込', budget_csv_auto_load_message + '\n\n手動で予算単位CSVを選択してください。')
        except Exception:
            pass
        return
    budget_unit_master.clear()
    budget_unit_master.update(result.master)
    current_input_files["budget"] = path
    config_input_file_candidates["budget"] = path
    budget_csv_auto_loaded = True
    budget_csv_auto_load_message = f'前回設定を自動読込: {os.path.basename(path)}'
    apply_budget_unit_structure_rules()
    invalidate_management_cache()
    print('[予算単位] 自動読込:', path, '/', result.unique_count, '件')

def show_budget_unit_master_window():
    top=tk.Toplevel(root); top.title('予算単位CSV（マスタ表示＋参照回数）'); top.geometry('900x520')
    frame=ttk.Frame(top); frame.pack(fill='both', expand=True)
    tv=ttk.Treeview(frame, show='headings'); vsb=ttk.Scrollbar(frame, orient='vertical', command=tv.yview); hsb=ttk.Scrollbar(frame, orient='horizontal', command=tv.xview)
    tv.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    cols=('予算単位コード','予算単位名称','参照回数'); tv['columns']=cols
    for c in cols: tv.heading(c, text=get_tree_heading_label(c))
    tv.grid(row=0,column=0,sticky='nsew'); vsb.grid(row=0,column=1,sticky='ns'); hsb.grid(row=1,column=0,sticky='ew')
    frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)
    def refresh():
        tv.delete(*tv.get_children(''))
        calls=count_budget_unit_calls_in_table()
        for k in sorted(budget_unit_master.keys()):
            tv.insert('', 'end', values=(k, budget_unit_master[k], calls.get(normalize_key(k),0)))
        auto_size_tree_columns(tv, list(cols), clamp_max={}, numeric_cols=['参照回数'], sample_rows=SAMPLE_ROWS_FOR_MEASURE)
    refresh()
    ttk.Button(top, text='更新', command=refresh).pack(anchor='e', padx=8, pady=8)

def load_budget_unit_master_csv():
    path=filedialog.askopenfilename(filetypes=[('CSVファイル','*.csv')], title='予算単位CSVを選択')
    if not path: return
    result, error = load_budget_unit_master_from_paths([path])
    if error:
        messagebox.showerror('予算単位CSV読込エラー', error)
        return
    apply_budget_unit_master_load_result(result, path, show_view=True)

# === 予算単位候補の収集（末端のみ・分析ビュー退避関数用） ===
def _collect_all_units_for_combo():
    all_units = set()
    for i in range(len(flat_nodes)):
        u = get_budget_unit_code(i)
        if u:
            all_units.add(u)
    return sorted(all_units)

# ---- 未使用関数置き場: 分析ビュー（将来復活用） ----
def unused_show_analysis_view():
    base=[]
    for idx,n in enumerate(flat_nodes, start=1):
        i0 = idx - 1
        assign = ''
        disp_method = get_display_method(idx-1)
        base.append({
            '予算単位': get_budget_unit_code(i0),
            '割り振り先': assign,
            TREE_ROW_LABEL: idx,
            'ノード名': n.name,
            '詳細１': n.detail1,
            '詳細２': n.detail2,
            '算出方法': disp_method,
            '電力量': float(round(n.energy,2)),
            '電気室': n.electric_room,
            '変圧器': n.transformer,
            '備考': n.notes,
            '分類１': getattr(n,'category1',''),
            '分類２': getattr(n,'category2',''),
            '分類３': getattr(n,'category3','')
        })
    top=tk.Toplevel(root); top.title('分析ビュー'); top.geometry('1600x820')
    cols=('予算単位','割り振り先',TREE_ROW_LABEL,'ノード名','詳細１','詳細２','算出方法','電力量','備考','電気室','変圧器','分類１','分類２','分類３')
    tree_frame = ttk.Frame(top); tree_frame.pack(fill='both', expand=True)
    tv=ttk.Treeview(tree_frame, show='headings'); vsb=ttk.Scrollbar(tree_frame, orient='vertical', command=tv.yview); hsb=ttk.Scrollbar(tree_frame, orient='horizontal', command=tv.xview)
    tv.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tv['columns']=cols
    for h in cols: tv.heading(h, text=get_tree_heading_label(h))
    tv.grid(row=0,column=0,sticky='nsew'); vsb.grid(row=0,column=1,sticky='ns'); hsb.grid(row=1,column=0,sticky='ew')
    tree_frame.rowconfigure(0,weight=1); tree_frame.columnconfigure(0,weight=1)
    ctrl=ttk.Frame(top); ctrl.pack(fill='x', padx=8, pady=6)
    units = sorted(set(r['予算単位'] for r in base if r['予算単位']))
    assigns= sorted(set(r['割り振り先'] for r in base if r['割り振り先']))
    methods=list(DISPLAY_METHOD_CHOICES)
    cats1 = sorted(set(r['分類１'] for r in base if r['分類１']))
    cats2 = sorted(set(r['分類２'] for r in base if r['分類２']))
    cats3 = sorted(set(r['分類３'] for r in base if r['分類３']))
    ttk.Label(ctrl,text='予算単位').grid(row=0,column=0,sticky='w'); cb_unit=ttk.Combobox(ctrl, values=['']+units, width=18); cb_unit.grid(row=0,column=1,padx=6)
    ttk.Label(ctrl,text='割り振り先').grid(row=0,column=2,sticky='w'); cb_assign=ttk.Combobox(ctrl, values=['']+assigns, width=24); cb_assign.grid(row=0,column=3,padx=6)
    ttk.Label(ctrl,text='算出方法').grid(row=0,column=4,sticky='w'); cb_method=ttk.Combobox(ctrl, values=methods, width=12); cb_method.grid(row=0,column=5,padx=6)
    ttk.Label(ctrl,text='電力量 範囲').grid(row=0,column=6,sticky='w'); en_min=ttk.Entry(ctrl,width=10); en_min.grid(row=0,column=7,padx=4); ttk.Label(ctrl,text='～').grid(row=0,column=8); en_max=ttk.Entry(ctrl,width=10); en_max.grid(row=0,column=9,padx=4)
    show_branch_var = tk.BooleanVar(value=False)
    chk_branch = ttk.Checkbutton(ctrl, text='分岐表示', variable=show_branch_var)
    chk_branch.grid(row=0,column=10, padx=8, sticky='w')
    ttk.Label(ctrl,text='分類１').grid(row=1,column=0,sticky='w'); cb_cat1=ttk.Combobox(ctrl, values=['']+cats1, width=18); cb_cat1.grid(row=1,column=1,padx=6)
    ttk.Label(ctrl,text='分類２').grid(row=1,column=2,sticky='w'); cb_cat2=ttk.Combobox(ctrl, values=['']+cats2, width=18); cb_cat2.grid(row=1,column=3,padx=6)
    ttk.Label(ctrl,text='分類３').grid(row=1,column=4,sticky='w'); cb_cat3=ttk.Combobox(ctrl, values=['']+cats3, width=18); cb_cat3.grid(row=1,column=5,padx=6)
    btn_jump = ttk.Button(ctrl, text='ジャンプ')
    btn_csv = ttk.Button(ctrl, text='CSV出力')
    btn_apply= ttk.Button(ctrl, text='適用')
    btn_clear= ttk.Button(ctrl, text='クリア')
    btn_jump.grid(row=0,column=11, padx=8, sticky='e')
    btn_csv.grid(row=0,column=12, padx=(0,8), sticky='e')
    btn_apply.grid(row=1,column=11, padx=8, sticky='e')
    btn_clear.grid(row=1,column=12, padx=(0,8), sticky='e')

    sort_state={c:'none' for c in cols}
    def _col_key(c,r): return float(r[c]) if c in ('電力量',TREE_ROW_LABEL) else r[c]
    def get_filtered_rows():
        u=cb_unit.get().strip(); a=cb_assign.get().strip(); m=cb_method.get().strip(); k1=cb_cat1.get().strip(); k2=cb_cat2.get().strip(); k3=cb_cat3.get().strip()
        def _num(s):
            try: return float(s.strip()) if s.strip()!='' else None
            except ValueError: return None
        mn=_num(en_min.get()); mx=_num(en_max.get())
        include_branch = show_branch_var.get()
        out=[]
        for r in base:
            if (not include_branch) and r['割り振り先']=='分岐': continue
            if u and r['予算単位']!=u: continue
            if a and r['割り振り先']!=a: continue
            if m and r['算出方法']!=m: continue
            if k1 and r['分類１']!=k1: continue
            if k2 and r['分類２']!=k2: continue
            if k3 and r['分類３']!=k3: continue
            v=float(r['電力量'])
            if (mn is not None and v<mn) or (mx is not None and v>mx): continue
            out.append(r)
        return out
    def apply_sort(rows,column):
        st=sort_state[column]
        if st=='none': sort_state[column]='asc'; rows.sort(key=lambda r:_col_key(column,r))
        elif st=='asc': sort_state[column]='desc'; rows.sort(key=lambda r:_col_key(column,r), reverse=True)
        else: sort_state[column]='none'; rows[:]=get_filtered_rows()
        return rows
    def on_heading_click(column):
        rows=get_filtered_rows(); rows=apply_sort(rows,column); fill(rows)
        for c in cols: tv.heading(c, text=get_tree_heading_label(c), command=lambda cc=c: on_heading_click(cc))
    def fill(rows):
        tv.delete(*tv.get_children('')); total=0.0
        for r in rows:
            total += float(r['電力量'])
            tv.insert('', 'end', values=(r['予算単位'], r['割り振り先'], r[TREE_ROW_LABEL],
                                         r['ノード名'], r['詳細１'], r['詳細２'], r['算出方法'],
                                         format_energy_display(r['電力量']), r['備考'], r['電気室'],
                                         r['変圧器'], r['分類１'], r['分類２'], r['分類３']))
        auto_size_tree_columns(tv, list(cols), clamp_max={'割り振り先': MAX_ASSIGN_NAME_WIDTH, 'ノード名': MAX_NODE_NAME_WIDTH}, numeric_cols=[TREE_ROW_LABEL, '電力量'], sample_rows=SAMPLE_ROWS_FOR_MEASURE)
    def apply_filters():
        rows=get_filtered_rows(); act=[c for c,st in sort_state.items() if st in ('asc','desc')]
        if act:
            col=act[-1]; rev=sort_state[col]=='desc'; rows.sort(key=lambda r:_col_key(col,r), reverse=rev)
        fill(rows)
    def clear_filters():
        for w in (cb_unit,cb_assign,cb_method,cb_cat1,cb_cat2,cb_cat3): w.set('')
        en_min.delete(0,tk.END); en_max.delete(0,tk.END)
        show_branch_var.set(False)
        for c in cols: sort_state[c]='none'
        fill(get_filtered_rows())
    def _get_selected_row_index():
        sel = tv.selection()
        if not sel: return None
        vals = tv.item(sel[0], 'values')
        if not vals or len(vals) < 3: return None
        try: return int(vals[2])
        except Exception: return None
    def jump_from_analysis():
        idx1 = _get_selected_row_index()
        if idx1 is None: return
        jump_to_row_number(idx1)
    def export_csv():
        rows=get_filtered_rows(); act=[c for c,st in sort_state.items() if st in ('asc','desc')]
        if act:
            col=act[-1]; rev=sort_state[col]=='desc'; rows.sort(key=lambda r:_col_key(col,r), reverse=rev)
        path=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSVファイル','*.csv')],title='分析ビューをCSV出力')
        if not path: return
        headers=list(cols)
        with open(path,'w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f); w.writerow(headers)
            total=0.0
            for r in rows:
                total+=float(r['電力量'])
                _t=excel_safe_text
                w.writerow([_t(r['予算単位']),_t(r['割り振り先']),r[TREE_ROW_LABEL],_t(r['ノード名']),_t(r['詳細１']),_t(r['詳細２']),_t(r['算出方法']),f"{float(r['電力量']):.1f}",_t(r['備考']),_t(r['電気室']),_t(r['変圧器']),_t(r['分類１']),_t(r['分類２']),_t(r['分類３'])])
    for c in cols: tv.heading(c, command=lambda cc=c: on_heading_click(cc))
    btn_apply.configure(command=apply_filters)
    btn_clear.configure(command=clear_filters)
    btn_jump.configure(command=jump_from_analysis)
    btn_csv.configure(command=export_csv)
    tv.bind('<Double-1>', lambda e: jump_from_analysis())
    fill(get_filtered_rows())

# ---- 並べ替え/階層/追加削除 ----

def move_node(up=True):
    indices = get_selected_indices()
    if not indices: return
    state = _snapshot_tree_state()
    push_history()
    ok, new_indices, message = move_selected_nodes(indices, up)
    if ok:
        invalidate_all_runtime_caches()
        state['selected_indices'] = new_indices
        state['selected_index'] = new_indices[0] if new_indices else None
        redraw_preserving_state(state)
    else:
        history_stack.pop()
        if message:
            messagebox.showwarning('ノード移動', message)

def change_depth(increase=True):
    indices = get_selected_indices()
    if not indices: return
    state = _snapshot_tree_state()
    ok, message = change_selected_nodes_depth(indices, increase)
    if not ok:
        if message:
            messagebox.showwarning('階層変更', message)
        return
    push_history()
    for index in indices:
        flat_nodes[index].depth += 1 if increase else -1
    invalidate_all_runtime_caches()
    redraw_preserving_state(state)

def add_node():
    idx = get_index_for_iid(tree.focus())
    if idx is None:
        sel=tree.selection()
        idx = get_index_for_iid(sel[0]) if sel else None
    state = _snapshot_tree_state()
    push_history()
    pos = insert_node_after_selection(idx)
    invalidate_all_runtime_caches()
    state['selected_index'] = pos
    state['selected_indices'] = [pos]
    redraw_preserving_state(state)

def delete_node():
    indices = get_selected_indices()
    if not indices: return
    count=len(indices)
    message = (
        '選択ノードを削除します。よろしいですか？'
        if count == 1
        else f'選択した{count}件のノードを削除します。よろしいですか？'
    )
    res=messagebox.askyesnocancel('削除の確認', message + '\n\n［はい］：削除 / ［いいえ］：中止 / ［キャンセル］：何もしない')
    if res is True:
        state = _snapshot_tree_state()
        push_history()
        first_index = indices[0]
        delete_selected_nodes(indices)
        invalidate_all_runtime_caches()
        if first_index >= len(flat_nodes):
            state['selected_index'] = len(flat_nodes) - 1 if flat_nodes else None
            state['selected_indices'] = [] if state['selected_index'] is None else [state['selected_index']]
        else:
            state['selected_index'] = first_index
            state['selected_indices'] = [first_index]
        redraw_preserving_state(state)

# ---- CSV 読み込み/出力（ツリー） ----

ANALYSIS_NODE_METADATA_HEADERS=['ノードID','親ノードID','親ノード名','ノードパス','ノードIDパス','末端判定','子ノード数']
TREE_EXPORT_HEADERS=['階層','ノード名','詳細１','詳細２','AT','算出方法','計量名称','按分比率','按分単位','電力量','予算単位コード','予算単位名称','電気室','変圧器','分類１','分類２','分類３','属性(Sankey分類)','備考','管理（親子差大）','管理（過大電力）','管理（負按分）','管理（確認事項）','個別推定量','下流確定量','下流未確定量','末端理論最大値','経路推定累積度','計測推奨境界','計測評価対象外','参考計量名称','参考値','参考単位','参考_按分kWh差','行番号','対象年月','出力日時'] + ANALYSIS_NODE_METADATA_HEADERS
TREE_EXCEL_HEADERS=list(TREE_EXPORT_HEADERS)
TREE_NUMERIC_HEADERS={'行番号','AT','按分比率','電力量','個別推定量','下流確定量','下流未確定量','末端理論最大値','経路推定累積度','計測推奨境界','計測評価対象外','管理（親子差大）','管理（過大電力）','管理（負按分）','参考値','参考_按分kWh差','階層'}
TREE_CSV_REQUIRED_HEADERS={'階層','ノード名','算出方法'}
UPPER_CONNECTION_EXTRA_HEADERS=[
    '会社名','拠点名','出力種別',
    '参照元算出方法','元ノードID','元親ノードID','元深さ','元ノード名',
    '元親ノード名','元ノードパス','元ノードIDパス',
    '元計量名称','元AT','元按分比率','元按分単位','元電力量',
    '元詳細１','元詳細２','元予算単位コード','元予算単位名称',
    '元電気室','元変圧器','元分類１','元分類２','元分類３',
    '元属性(Sankey分類)','元備考','元管理（親子差大）',
    '元管理（過大電力）','元管理（負按分）','元管理（確認事項）',
    '元参考計量名称','元参考値','元参考単位','元参考_按分kWh差'
]
UPPER_CONNECTION_EXCEL_HEADERS=TREE_EXCEL_HEADERS + UPPER_CONNECTION_EXTRA_HEADERS
UPPER_CONNECTION_NUMERIC_HEADERS=(TREE_NUMERIC_HEADERS - {'階層'}) | {
    'ローカル深さ','接続後階層','子ノード数'
}
UPPER_CONNECTION_LEADING_HEADERS=[
    'ノードID','親ノードID','ノード名','親ノード名',
    'ローカル深さ','接続後階層','末端判定','子ノード数',
    'ノードパス','ノードIDパス'
]
UPPER_CONNECTION_CALC_ATTRIBUTE_HEADERS=[
    'AT','算出方法','計量名称','按分比率','按分単位','電力量',
    '予算単位コード','予算単位名称','電気室','変圧器',
    '分類１','分類２','分類３','属性(Sankey分類)',
    '詳細１','詳細２','備考',
    '管理（親子差大）','管理（過大電力）','管理（負按分）','管理（確認事項）',
    '個別推定量','下流確定量','下流未確定量','末端理論最大値','経路推定累積度','計測推奨境界','計測評価対象外',
    '参考計量名称','参考値','参考単位','参考_按分kWh差',
    '行番号','会社名','拠点名','対象年月','出力日時','出力種別'
]

def get_default_target_month(today=None) -> str:
    if today is None:
        today = datetime.now()
    year = today.year
    month = today.month - 1
    if month == 0:
        year -= 1
        month = 12
    return f"{year:04d}-{month:02d}"

def get_target_month_options(base_date=None, months_back:int=24)->List[str]:
    if base_date is None:
        base_date = datetime.now()

    year = base_date.year
    month = base_date.month - 1
    if month == 0:
        year -= 1
        month = 12

    options = []
    for _ in range(months_back):
        options.append(f"{year:04d}-{month:02d}")
        month -= 1
        if month == 0:
            year -= 1
            month = 12
    return options

def get_output_datetime_text(now=None) -> str:
    if now is None:
        now = datetime.now()
    return now.strftime("%Y-%m-%d %H:%M:%S")

def get_default_analysis_filename(target_month:str, extension:str, purpose:str='分析') -> str:
    """既存の対象年月(YYYY-MM)を保存ダイアログの初期名だけに使用する。"""
    month_part = target_month.replace('-', '')
    return f'{APP_NAME}_{purpose}_{month_part}{extension}'

def ask_target_month() -> Optional[str]:
    options = get_target_month_options()
    if not options:
        return None

    dialog = tk.Toplevel(root)
    dialog.title('対象年月の選択')
    dialog.transient(root)
    dialog.grab_set()
    dialog.resizable(False, False)

    result = {'value': None}

    frame = ttk.Frame(dialog, padding=12)
    frame.pack(fill='both', expand=True)

    ttk.Label(frame, text='出力する分析データの対象年月を選択してください。').pack(anchor='w')

    combo = ttk.Combobox(frame, values=options, state='readonly', width=12)
    combo.set(options[0])
    combo.pack(anchor='w', pady=(8, 12))

    button_frame = ttk.Frame(frame)
    button_frame.pack(fill='x')

    def ok():
        result['value'] = combo.get()
        dialog.destroy()

    def cancel():
        result['value'] = None
        dialog.destroy()

    ttk.Button(button_frame, text='OK', command=ok).pack(side='right')
    ttk.Button(button_frame, text='キャンセル', command=cancel).pack(side='right', padx=(0, 8))

    dialog.protocol('WM_DELETE_WINDOW', cancel)
    combo.focus_set()
    dialog.update_idletasks()
    try:
        x = root.winfo_rootx() + (root.winfo_width() - dialog.winfo_width()) // 2
        y = root.winfo_rooty() + (root.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f'+{max(x, 0)}+{max(y, 0)}')
    except Exception:
        pass
    dialog.wait_window()

    return result['value']

def build_analysis_node_metadata(nodes:Optional[List[FlatNode]]=None)->Dict[int,Dict[str,Any]]:
    """分析出力の行順から、親子関係を表す出力専用メタデータを作る。"""
    if nodes is None:
        nodes = flat_nodes

    # ノードIDは上位連携出力内で親子関係を識別するための一時ID。
    # 構成CSVに保存する永続IDではなく、出力順に応じて毎回生成される。
    metadata: Dict[int, Dict[str, Any]] = {}
    structure = get_tree_structure_index() if nodes is flat_nodes else build_tree_structure_index(nodes)
    child_counts = [0] * len(nodes)

    for index, node in enumerate(nodes):
        node_id = f'N{index + 1:06d}'
        parent_index = structure.parent_by_index.get(index)
        if parent_index is not None:
            child_counts[parent_index] += 1
            parent = metadata[parent_index]
            parent_node_id = parent['ノードID']
            parent_node_name = nodes[parent_index].name
            node_path = f"{parent['ノードパス']} > {node.name}"
            node_id_path = f"{parent['ノードIDパス']}/{node_id}"
        else:
            parent_node_id = ''
            parent_node_name = ''
            node_path = node.name
            node_id_path = node_id

        metadata[index] = {
            'ノードID': node_id,
            '親ノードID': parent_node_id,
            '親ノード名': parent_node_name,
            'ノードパス': node_path,
            'ノードIDパス': node_id_path,
        }

    for index, count in enumerate(child_counts):
        metadata[index]['末端判定'] = '末端' if count == 0 else '親'
        metadata[index]['子ノード数'] = count
    return metadata

def build_tree_export_row(index:int, target_month:str='', output_datetime:str='',
                          node_metadata:Optional[Dict[int,Dict[str,Any]]]=None)->List[Any]:
    n = flat_nodes[index]
    idx = index + 1
    m1, m2, m3 = compute_management_values(index)
    disp_method = n.calc_method
    budget_code = get_budget_unit_code(index)
    budget_name = get_budget_unit_name(index)
    management_notice = format_management_notice_display(index)
    reference_diff = compute_allocation_kwh_reference_difference(n)
    row = [
        n.depth,
        n.name,
        n.detail1,
        n.detail2,
        format_at_display(n.at),
        disp_method,
        n.measure_name,
        n.ratio,
        n.unit,
        n.energy,
        budget_code,
        budget_name,
        n.electric_room,
        n.transformer,
        n.category1,
        n.category2,
        n.category3,
        get_effective_sankey_category(index),
        n.notes,
        m1,
        m2,
        m3,
        management_notice,
        *get_estimation_indicator_values(index),
        n.reference_measure_name,
        get_reference_value_export_value(n),
        n.reference_unit,
        reference_diff,
        idx,
        target_month,
        output_datetime
    ]
    if node_metadata is None:
        node_metadata = build_analysis_node_metadata()
    row.extend(node_metadata[index][header] for header in ANALYSIS_NODE_METADATA_HEADERS)
    return row

def parse_kwh_management_number(value:Any)->Any:
    text = normalize_value(value).replace(',', '')
    if text == '':
        return ''
    text = text.replace('kWh', '').strip()
    try:
        return float(text)
    except (TypeError, ValueError):
        return ''

def build_tree_excel_row(index:int, target_month:Optional[str]=None, output_datetime:Optional[str]=None,
                         node_metadata:Optional[Dict[int,Dict[str,Any]]]=None)->List[Any]:
    row_by_header = dict(zip(TREE_EXPORT_HEADERS, build_tree_export_row(index, target_month, output_datetime, node_metadata)))
    row_by_header['管理（親子差大）'] = parse_kwh_management_number(row_by_header.get('管理（親子差大）', ''))
    row_by_header['管理（負按分）'] = parse_kwh_management_number(row_by_header.get('管理（負按分）', ''))
    return [row_by_header[h] for h in TREE_EXCEL_HEADERS]

def validate_upper_connection_export_options(start_depth:Any, company_name:Any,
                                             site_name:Any, target_month:Any)->Tuple[Optional[Dict[str, Any]], Optional[str]]:
    raw_depth = normalize_value(start_depth)
    try:
        parsed_depth = int(raw_depth)
    except (TypeError, ValueError):
        return None, '接続開始階層は0以上の整数で入力してください。'
    if str(parsed_depth) != raw_depth or parsed_depth < 0:
        return None, '接続開始階層は0以上の整数で入力してください。'
    company = normalize_value(company_name)
    site = normalize_value(site_name)
    month = normalize_value(target_month)
    if not company:
        return None, '会社名を入力してください。'
    if not site:
        return None, '拠点名を入力してください。'
    if not re.fullmatch(r'\d{4}-\d{2}', month):
        return None, '対象月はYYYY-MM形式で入力してください。'
    year, mon = month.split('-')
    if not (1 <= int(mon) <= 12):
        return None, '対象月はYYYY-MM形式で入力してください。'
    return {
        'start_depth': parsed_depth,
        'company_name': company,
        'site_name': site,
        'target_month': month,
    }, None

def sanitize_filename_part(value:Any)->str:
    text = normalize_value(value)
    text = re.sub(r'[\\/:*?"<>|]+', '_', text)
    text = re.sub(r'\s+', ' ', text).strip(' .')
    return text or '未設定'

def make_upper_connection_blank_row(headers:List[str])->Dict[str, Any]:
    return {header: '' for header in headers}

def set_upper_connection_metadata(row:Dict[str, Any], row_no:int, depth:int, name:str,
                                  parent_node_id:str, parent_node_name:str,
                                  parent_node_path:str, parent_node_id_path:str,
                                  is_leaf:bool, child_count:int):
    node_id = f'U{row_no:06d}'
    row['行番号'] = row_no
    row['階層'] = depth
    row['ノードID'] = node_id
    row['親ノードID'] = parent_node_id
    row['親ノード名'] = parent_node_name
    row['ノードパス'] = f'{parent_node_path} > {name}' if parent_node_path else name
    row['ノードIDパス'] = f'{parent_node_id_path}/{node_id}' if parent_node_id_path else node_id
    row['末端判定'] = '末端' if is_leaf else '親'
    row['子ノード数'] = child_count
    return node_id

def _unique_headers(headers:List[str])->List[str]:
    seen = set()
    result = []
    for header in headers:
        if header in seen:
            continue
        seen.add(header)
        result.append(header)
    return result

def build_upper_connection_excel_headers(max_depth:int)->List[str]:
    layer_headers = [f'{depth}層' for depth in range(max_depth + 1)]
    layer_id_headers = [f'{depth}層ID' for depth in range(max_depth + 1)]
    return _unique_headers(
        UPPER_CONNECTION_LEADING_HEADERS
        + layer_headers
        + layer_id_headers
        + UPPER_CONNECTION_CALC_ATTRIBUTE_HEADERS
    )

def build_upper_connection_layer_values(nodes:List[FlatNode],
                                        metadata:Dict[int,Dict[str,Any]]
                                        )->Tuple[Dict[int,List[str]], Dict[int,List[str]], int]:
    structure = get_tree_structure_index() if nodes is flat_nodes else build_tree_structure_index(nodes)
    name_layers: Dict[int, List[str]] = {}
    id_layers: Dict[int, List[str]] = {}
    max_depth = 0
    for index, node in enumerate(nodes):
        parent_index = structure.parent_by_index.get(index)
        if parent_index is not None and parent_index in name_layers:
            names = name_layers[parent_index] + [node.name]
            ids = id_layers[parent_index] + [metadata[index]['ノードID']]
        else:
            names = [node.name]
            ids = [metadata[index]['ノードID']]
        name_layers[index] = names
        id_layers[index] = ids
        max_depth = max(max_depth, len(names) - 1)
    return name_layers, id_layers, max_depth

def apply_upper_connection_layers(row:Dict[str,Any], name_layers:List[str],
                                  id_layers:List[str], max_depth:int):
    for depth in range(max_depth + 1):
        row[f'{depth}層'] = name_layers[depth] if depth < len(name_layers) else ''
        row[f'{depth}層ID'] = id_layers[depth] if depth < len(id_layers) else ''

def validate_upper_connection_standard_rows(rows:List[Dict[str,Any]])->Optional[str]:
    node_ids_seen: Set[str] = set()
    for row in rows:
        node_id = normalize_value(row.get('ノードID', ''))
        parent_node_id = normalize_value(row.get('親ノードID', ''))
        if not node_id:
            return 'ノードIDが空の行があります。'
        if node_id in node_ids_seen:
            return f'ノードIDが重複しています: {node_id}'
        if node_id == parent_node_id:
            return f'自己参照しているノードがあります: {node_id}'
        node_ids_seen.add(node_id)

    for row in rows:
        node_id = normalize_value(row.get('ノードID', ''))
        parent_node_id = normalize_value(row.get('親ノードID', ''))
        if parent_node_id and parent_node_id not in node_ids_seen:
            return f'{node_id} の親ノードIDが存在しません: {parent_node_id}'
        try:
            local_depth = int(row.get('ローカル深さ', 0))
        except (TypeError, ValueError):
            return f'{node_id} のローカル深さが整数ではありません。'
        path_depth = len([part for part in normalize_value(row.get('ノードパス', '')).split(' > ') if part != '']) - 1
        if path_depth != local_depth:
            return f'{node_id} のローカル深さとノードパスが一致しません。'
        try:
            connection_depth = int(row.get('接続後階層', 0))
            start_depth = int(row.get('_接続開始階層', 0))
        except (TypeError, ValueError):
            return f'{node_id} の接続後階層が整数ではありません。'
        if connection_depth != local_depth + start_depth:
            return f'{node_id} の接続後階層がローカル深さ＋接続開始階層と一致しません。'
    return None

def coerce_node_energy_for_export(index:int)->Tuple[Optional[float], Optional[str]]:
    node = flat_nodes[index]
    value = coerce_finite_number(node.energy)
    if value is None:
        return None, f'{format_node_ref(index, flat_nodes)} の電力量が有限数ではありません。'
    return value, None

def calculate_upper_connection_temporary_tree(nodes:List[FlatNode])->Tuple[bool, Optional[str]]:
    """上位接続用Excel専用。参照を固定値として扱い、按分は通常計算と同じ残差配分にする。"""
    structure = build_tree_structure_index(nodes)
    if structure.critical_issues:
        details = '\n'.join(format_structure_validation_issue_examples(structure.critical_issues))
        return False, '上位接続用ツリーにクリティカル不整合があります。\n' + details

    max_depth = max((getattr(node, 'depth', 0) for node in nodes), default=0)
    for depth in reversed(range(max_depth + 1)):
        for index, node in enumerate(nodes):
            if node.depth == depth and node.calc_method == '合算':
                total = sum(nodes[child_index].energy for child_index in structure.direct_children_by_index.get(index, []))
                if not math.isfinite(total):
                    return False, f'{index + 1}行目「{node.name}」の合算結果が有限数ではありません。'
                node.energy = total

    for depth in range(max_depth + 1):
        for index, node in enumerate(nodes):
            if node.depth != depth:
                continue
            children = [nodes[child_index] for child_index in structure.direct_children_by_index.get(index, [])]
            allocation_children = [child for child in children if child.calc_method == '按分']
            if not allocation_children:
                continue
            settled_children = [child for child in children if child.calc_method in ('参照', '実測', '合算')]
            fixed_total = sum(child.energy for child in settled_children)
            ratio_total = sum(child.ratio for child in allocation_children)
            if not math.isfinite(fixed_total):
                return False, f'{index + 1}行目「{node.name}」の確定子ノード合計が有限数ではありません。'
            if not math.isfinite(ratio_total) or ratio_total <= 0:
                return False, f'{index + 1}行目「{node.name}」の按分比率合計が0以下または有限数ではありません。'
            parent_energy = coerce_finite_number(node.energy)
            if parent_energy is None:
                return False, f'{index + 1}行目「{node.name}」の電力量が有限数ではありません。'
            remaining = parent_energy - fixed_total
            for child in allocation_children:
                child.energy = remaining * child.ratio / ratio_total
                if not math.isfinite(child.energy):
                    return False, f'按分子「{child.name}」の電力量が有限数ではありません。'
    return True, None

def build_upper_connection_export_data_legacy_adjusted_tree(options:Dict[str, Any], output_datetime:Optional[str]=None)->Tuple[Optional[Dict[str, Any]], Optional[str]]:
    critical_errors = find_critical_calc_structure_errors()
    if critical_errors:
        return None, format_critical_calc_structure_error_export_confirm(critical_errors, '配賦調整済み・上位ツリー接続用Excel')
    if not has_power_budget_unit_node():
        return None, format_missing_power_budget_unit_error('上位接続Excel')
    if output_datetime is None:
        output_datetime = get_output_datetime_text()

    start_depth = int(options['start_depth'])
    company_name = options['company_name']
    site_name = options['site_name']
    target_month = options['target_month']
    source_metadata = build_analysis_node_metadata()

    power_total = 0.0
    power_rows: List[int] = []
    target_rows: List[Tuple[int, float]] = []
    budget_totals: Dict[str, float] = {}
    budget_names: Dict[str, str] = {}

    for index, node in enumerate(flat_nodes):
        energy, error = coerce_node_energy_for_export(index)
        if error:
            return None, error
        budget_code = get_effective_budget_unit_code(index)
        if budget_code == BUDGET_UNIT_POWER:
            power_total += abs(energy)
            power_rows.append(index)
            continue
        if has_child(index):
            continue
        if budget_code in ('', BUDGET_UNIT_AGGREGATE):
            continue
        target_rows.append((index, energy))
        budget_totals[budget_code] = budget_totals.get(budget_code, 0.0) + energy
        budget_names[budget_code] = get_budget_unit_name(index) or budget_code

    if not power_rows:
        return None, format_missing_power_budget_unit_error('上位接続Excel')
    if not math.isfinite(power_total):
        return None, '電源合計が有限数ではありません。'
    if not target_rows:
        return None, '予算単位が割り当てられた対象末端ノードがありません。'

    terminal_total = sum(value for _index, value in target_rows)
    if not math.isfinite(terminal_total):
        return None, '対象末端ノードの合計電力量が有限数ではありません。'
    if terminal_total <= 0:
        return None, '予算単位別按分の分母となる末端合計が0以下のため、配賦調整量を按分できません。'
    root_name = f'{company_name}_{site_name}_{target_month}_電源合計'

    temp_nodes: List[FlatNode] = [
        FlatNode(root_name, '参照', '', '', 0.0, '', power_total, 0, budget_unit=BUDGET_UNIT_AGGREGATE)
    ]
    temp_source_index_by_source_index: Dict[int, int] = {}
    for source_index, energy in target_rows:
        source = flat_nodes[source_index]
        temp_source_index_by_source_index[source_index] = len(temp_nodes)
        temp_nodes.append(FlatNode(source.name, '参照', source.at, source.measure_name, source.ratio, source.unit, energy, 1, budget_unit=get_effective_budget_unit_code(source_index)))

    adjustment_parent_temp_index = len(temp_nodes)
    temp_nodes.append(FlatNode('配賦調整', '按分', '1', '', 1.0, '残差', 0.0, 1, budget_unit=BUDGET_UNIT_AGGREGATE))
    adjustment_child_temp_index_by_budget: Dict[str, int] = {}
    for code in sorted(budget_totals.keys()):
        budget_total = budget_totals[code]
        if not math.isfinite(budget_total):
            return None, f'予算単位 {code} の末端合計が有限数ではありません。'
        if budget_total < 0:
            return None, f'予算単位 {code} の末端合計が負のため、配賦調整内訳の按分比率として使用できません。'
        budget_name = budget_names.get(code, code)
        node_name = f'配賦調整_{code}_{budget_name}'
        adjustment_child_temp_index_by_budget[code] = len(temp_nodes)
        temp_nodes.append(FlatNode(node_name, '按分', str(budget_total), '', budget_total, 'kWh構成比', 0.0, 2, budget_unit=code))

    ok, calc_error = calculate_upper_connection_temporary_tree(temp_nodes)
    if not ok:
        return None, calc_error

    adjustment_amount = temp_nodes[adjustment_parent_temp_index].energy
    adjustment_children_total = sum(temp_nodes[index].energy for index in adjustment_child_temp_index_by_budget.values())
    tolerance = max(1e-6, abs(power_total) * 1e-9, abs(terminal_total) * 1e-9, abs(adjustment_amount) * 1e-9)
    if abs(power_total - (terminal_total + adjustment_amount)) > tolerance:
        return None, '上位接続用ツリーの検算に失敗しました。電源合計と、元末端合計＋配賦調整が一致しません。'
    if abs(adjustment_amount - adjustment_children_total) > tolerance:
        return None, '上位接続用ツリーの検算に失敗しました。配賦調整と、配賦調整内訳合計が一致しません。'
    if not all(math.isfinite(node.energy) for node in temp_nodes):
        return None, '上位接続用ツリーの計算結果に有限数ではない電力量があります。'
    adjustment_rate = adjustment_amount / power_total * 100.0 if abs(power_total) >= 1e-9 else None

    rows: List[Dict[str, Any]] = []

    def base_row(output_type:str)->Dict[str, Any]:
        row = make_upper_connection_blank_row(UPPER_CONNECTION_EXCEL_HEADERS)
        row['会社名'] = company_name
        row['拠点名'] = site_name
        row['対象年月'] = target_month
        row['出力日時'] = output_datetime
        row['出力種別'] = output_type
        return row

    root_row = base_row('電源合計')
    root_row.update({
        'ノード名': root_name,
        '算出方法': '参照',
        '電力量': temp_nodes[0].energy,
        '予算単位コード': BUDGET_UNIT_AGGREGATE,
        '備考': '予算単位コード「電源」の電力量絶対値合計',
    })
    root_child_count = len(target_rows) + 1
    root_id = set_upper_connection_metadata(root_row, 1, start_depth, root_name, '', '', '', '', False, root_child_count)
    rows.append(root_row)

    root_path = root_row['ノードパス']
    root_id_path = root_row['ノードIDパス']
    next_row_no = 2
    for source_index, energy in target_rows:
        node = flat_nodes[source_index]
        temp_node = temp_nodes[temp_source_index_by_source_index[source_index]]
        meta = source_metadata[source_index]
        row = base_row('元末端')
        budget_code = get_effective_budget_unit_code(source_index)
        budget_name = get_budget_unit_name(source_index) or budget_code
        m1, m2, m3 = compute_management_values(source_index)
        management_notice = format_management_notice_display(source_index)
        reference_diff = compute_allocation_kwh_reference_difference(node)
        row.update({
            'ノード名': node.name,
            '詳細１': node.detail1,
            '詳細２': node.detail2,
            '算出方法': '参照',
            '電力量': temp_node.energy,
            '予算単位コード': budget_code,
            '予算単位名称': budget_name,
            '電気室': node.electric_room,
            '変圧器': node.transformer,
            '分類１': node.category1,
            '分類２': node.category2,
            '分類３': node.category3,
            '属性(Sankey分類)': get_effective_sankey_category(source_index),
            '備考': node.notes,
            '参照元算出方法': node.calc_method,
            '元ノードID': meta.get('ノードID', ''),
            '元親ノードID': meta.get('親ノードID', ''),
            '元深さ': node.depth,
            '元ノード名': node.name,
            '元親ノード名': meta.get('親ノード名', ''),
            '元ノードパス': meta.get('ノードパス', ''),
            '元ノードIDパス': meta.get('ノードIDパス', ''),
            '元計量名称': node.measure_name,
            '元AT': format_at_display(node.at),
            '元按分比率': node.ratio,
            '元按分単位': node.unit,
            '元電力量': energy,
            '元詳細１': node.detail1,
            '元詳細２': node.detail2,
            '元予算単位コード': budget_code,
            '元予算単位名称': budget_name,
            '元電気室': node.electric_room,
            '元変圧器': node.transformer,
            '元分類１': node.category1,
            '元分類２': node.category2,
            '元分類３': node.category3,
            '元属性(Sankey分類)': get_effective_sankey_category(source_index),
            '元備考': node.notes,
            '元管理（親子差大）': m1,
            '元管理（過大電力）': m2,
            '元管理（負按分）': m3,
            '元管理（確認事項）': management_notice,
            '元参考計量名称': node.reference_measure_name,
            '元参考値': get_reference_value_export_value(node),
            '元参考単位': node.reference_unit,
            '元参考_按分kWh差': reference_diff,
        })
        set_upper_connection_metadata(row, next_row_no, start_depth + 1, node.name, root_id, root_name, root_path, root_id_path, True, 0)
        rows.append(row)
        next_row_no += 1

    adjustment_parent = base_row('配賦調整')
    adjustment_parent_name = '配賦調整'
    adjustment_parent.update({
        'ノード名': adjustment_parent_name,
        '算出方法': '按分',
        '按分比率': 1.0,
        '按分単位': '残差',
        '電力量': adjustment_amount,
        '予算単位コード': BUDGET_UNIT_AGGREGATE,
        '備考': '電源合計から元末端ノード合計を差し引いた残差を、通常の按分計算で受け取る配賦調整親ノード。',
    })
    adjustment_parent_id = set_upper_connection_metadata(
        adjustment_parent, next_row_no, start_depth + 1, adjustment_parent_name,
        root_id, root_name, root_path, root_id_path, False, len(budget_totals)
    )
    rows.append(adjustment_parent)
    adjustment_parent_path = adjustment_parent['ノードパス']
    adjustment_parent_id_path = adjustment_parent['ノードIDパス']
    next_row_no += 1

    for code in sorted(budget_totals.keys()):
        budget_total = budget_totals[code]
        budget_name = budget_names.get(code, code)
        adjustment_value = temp_nodes[adjustment_child_temp_index_by_budget[code]].energy
        node_name = f'配賦調整_{code}_{budget_name}'
        row = base_row('配賦調整内訳')
        row.update({
            'ノード名': node_name,
            '算出方法': '按分',
            '按分比率': budget_total,
            '按分単位': 'kWh構成比',
            '電力量': adjustment_value,
            '予算単位コード': code,
            '予算単位名称': budget_name,
            '備考': f'配賦調整量を予算単位別末端合計比率で按分。末端合計={budget_total:.6f} kWh',
        })
        set_upper_connection_metadata(
            row, next_row_no, start_depth + 2, node_name,
            adjustment_parent_id, adjustment_parent_name,
            adjustment_parent_path, adjustment_parent_id_path, True, 0
        )
        rows.append(row)
        next_row_no += 1

    summary = {
        '電源合計': power_total,
        '元末端合計': terminal_total,
        '配賦調整量': adjustment_amount,
        '配賦調整率': adjustment_rate,
        '出力末端ノード数': len(target_rows),
        '予算単位数': len(budget_totals),
        '開始深さ': start_depth,
        '会社名': company_name,
        '拠点名': site_name,
        '対象月': target_month,
        '電源ノード数': len(power_rows),
    }
    return {'headers': UPPER_CONNECTION_EXCEL_HEADERS, 'rows': rows, 'summary': summary}, None

def build_upper_connection_export_data(options:Dict[str, Any], output_datetime:Optional[str]=None)->Tuple[Optional[Dict[str, Any]], Optional[str]]:
    critical_errors = find_critical_calc_structure_errors()
    if critical_errors:
        return None, format_critical_calc_structure_error_export_confirm(critical_errors, '上位連携データExcel')
    if output_datetime is None:
        output_datetime = get_output_datetime_text()

    start_depth = int(options['start_depth'])
    company_name = options['company_name']
    site_name = options['site_name']
    target_month = options['target_month']
    source_metadata = build_analysis_node_metadata()
    name_layers_by_index, id_layers_by_index, max_layer_depth = build_upper_connection_layer_values(flat_nodes, source_metadata)
    headers = build_upper_connection_excel_headers(max_layer_depth)

    for index, _node in enumerate(flat_nodes):
        _energy, error = coerce_node_energy_for_export(index)
        if error:
            return None, error

    rows: List[Dict[str, Any]] = []
    terminal_total = 0.0
    terminal_count = 0
    power_total = 0.0
    power_rows = 0
    budget_codes: Set[str] = set()

    for index, node in enumerate(flat_nodes):
        row = make_upper_connection_blank_row(headers)
        tree_row = build_tree_excel_row(index, target_month, output_datetime, source_metadata)
        row.update(dict(zip(TREE_EXCEL_HEADERS, tree_row)))
        meta = source_metadata[index]
        budget_code = get_effective_budget_unit_code(index)
        budget_name = get_budget_unit_name(index) or budget_code
        row.update({
            '会社名': company_name,
            '拠点名': site_name,
            '対象年月': target_month,
            '出力日時': output_datetime,
            '出力種別': '標準ノード',
            'ローカル深さ': node.depth,
            '接続後階層': node.depth + start_depth,
            '_接続開始階層': start_depth,
        })
        apply_upper_connection_layers(
            row,
            name_layers_by_index.get(index, [node.name]),
            id_layers_by_index.get(index, [meta.get('ノードID', '')]),
            max_layer_depth
        )
        rows.append(row)

        energy = row.get('電力量', 0.0)
        if row.get('末端判定') == '末端':
            terminal_total += energy
            terminal_count += 1
        if budget_code == BUDGET_UNIT_POWER:
            power_total += abs(energy)
            power_rows += 1
        if budget_code and budget_code not in (BUDGET_UNIT_AGGREGATE, BUDGET_UNIT_POWER):
            budget_codes.add(budget_code)

    validation_error = validate_upper_connection_standard_rows(rows)
    if validation_error:
        return None, validation_error

    summary = {
        '電源合計': power_total,
        '末端合計': terminal_total,
        '出力末端ノード数': terminal_count,
        '出力ノード数': len(rows),
        '予算単位数': len(budget_codes),
        '接続開始階層': start_depth,
        '最大ローカル深さ': max_layer_depth,
        '会社名': company_name,
        '拠点名': site_name,
        '対象月': target_month,
        '電源ノード数': power_rows,
    }
    return {'headers': headers, 'rows': rows, 'summary': summary}, None

def write_upper_connection_excel(path:str, export_data:Dict[str, Any]):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        raise RuntimeError('openpyxl がインストールされていません。')

    headers = export_data['headers']
    rows = export_data['rows']
    summary = export_data['summary']

    wb = Workbook()
    ws = wb.active
    ws.title = '上位接続用ツリー'
    ws.append(headers)
    for row in rows:
        ws.append([row.get(header, '') for header in headers])

    header_fill = PatternFill('solid', fgColor='FF305070')
    summary_fill = PatternFill('solid', fgColor='FFE8F1FF')
    header_font = Font(bold=True, color='FFFFFFFF')
    thin = Side(style='thin', color='FFD0D0D0')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    depth_col = headers.index('ローカル深さ') + 1
    node_col = headers.index('ノード名') + 1
    energy_col = headers.index('電力量') + 1
    reference_value_col = headers.index('参考値') + 1
    budget_code_col = headers.index('予算単位コード') + 1
    text_cols = {
        headers.index(h) + 1
        for h in ('ノードID','親ノードID','ノードIDパス')
        if h in headers
    }
    text_cols |= {idx for idx, header in enumerate(headers, start=1) if header.endswith('層ID')}
    numeric_cols = {headers.index(h) + 1 for h in UPPER_CONNECTION_NUMERIC_HEADERS if h in headers}
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = border

    for row_idx in range(2, ws.max_row + 1):
        try:
            depth = int(ws.cell(row=row_idx, column=depth_col).value)
        except (TypeError, ValueError):
            depth = 0
        depth_fill = PatternFill('solid', fgColor='FF' + _depth_color(depth).lstrip('#').upper())
        for col_idx in range(1, ws.max_column + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.fill = depth_fill
            cell.border = border
            if col_idx == depth_col or col_idx == budget_code_col:
                cell.alignment = Alignment(horizontal='center', vertical='center')
            elif col_idx == node_col:
                cell.alignment = Alignment(indent=min(depth, 15), vertical='center')
            elif col_idx in numeric_cols:
                cell.alignment = Alignment(horizontal='right', vertical='center')
            else:
                cell.alignment = Alignment(vertical='center', wrap_text=True)
            if headers[col_idx - 1] in ('計測推奨境界', '計測評価対象外'):
                cell.number_format = '0'
            elif headers[col_idx - 1] == '経路推定累積度':
                cell.number_format = '0.000'
            elif headers[col_idx - 1] in ('個別推定量', '下流確定量', '下流未確定量', '末端理論最大値'):
                cell.number_format = '#,##0.0'
            elif col_idx == energy_col or col_idx == reference_value_col:
                cell.number_format = '#,##0.0'
            elif col_idx in numeric_cols and isinstance(cell.value, (int, float)):
                cell.number_format = '#,##0.000'
            elif col_idx in text_cols:
                cell.number_format = '@'
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    for idx, header in enumerate(headers, start=1):
        width = 14
        if header in ('ノード名','ノードパス','元ノードパス'):
            width = 42
        elif re.fullmatch(r'\d+層', header):
            width = 24
        elif header in ('備考','管理（確認事項）'):
            width = 36
        elif header in ('会社名','拠点名','出力種別'):
            width = 18
        elif header == 'ノードIDパス' or re.fullmatch(r'\d+層ID', header):
            width = 34
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.column_dimensions[get_column_letter(depth_col)].width = 6

    summary_ws = wb.create_sheet('出力確認')
    summary_ws.append(['項目', '値', '単位', '説明'])
    summary_rows = [
        ('電源合計', summary['電源合計'], 'kWh', '予算単位コード「電源」の電力量絶対値合計'),
        ('末端合計', summary['末端合計'], 'kWh', '末端判定=末端の電力量合計。通常の属性別集計では末端ノードのみを集計対象にします。'),
        ('出力ノード数', summary.get('出力ノード数', ''), '件', '1行=1ノードで出力した全ノード数'),
        ('出力末端ノード数', summary['出力末端ノード数'], '件', ''),
        ('予算単位数', summary['予算単位数'], '件', ''),
        ('電源ノード数', summary['電源ノード数'], '件', ''),
        ('接続開始階層', summary['接続開始階層'], '', '接続後階層 = ローカル深さ + 接続開始階層'),
        ('最大ローカル深さ', summary.get('最大ローカル深さ', ''), '', '0層から最大ローカル深さまでローカル階層列を自動生成'),
        ('会社名', summary['会社名'], '', ''),
        ('拠点名', summary['拠点名'], '', ''),
        ('対象月', summary['対象月'], '', ''),
    ]
    for item in summary_rows:
        summary_ws.append(list(item))
    for cell in summary_ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = border
    for row_cells in summary_ws.iter_rows(min_row=2):
        for cell in row_cells:
            cell.border = border
            cell.alignment = Alignment(vertical='top', wrap_text=True)
        row_cells[0].fill = summary_fill
    summary_ws.column_dimensions['A'].width = 18
    summary_ws.column_dimensions['B'].width = 24
    summary_ws.column_dimensions['C'].width = 10
    summary_ws.column_dimensions['D'].width = 48
    wb.save(path)

def ask_upper_connection_export_options() -> Optional[Dict[str, Any]]:
    dialog = tk.Toplevel(root)
    dialog.title('上位接続Excel出力')
    dialog.transient(root)
    dialog.grab_set()
    dialog.resizable(False, False)

    result = {'value': None}
    frame = ttk.Frame(dialog, padding=12)
    frame.pack(fill='both', expand=True)

    ttk.Label(frame, text='上位ツリーへ接続するための出力条件を入力してください。').grid(row=0, column=0, columnspan=2, sticky='w', pady=(0, 10))
    fields = [
        ('接続開始階層', tk.StringVar(value='0')),
        ('会社名', tk.StringVar(value='')),
        ('拠点名', tk.StringVar(value='')),
        ('対象月', tk.StringVar(value=get_default_target_month())),
    ]
    entries = []
    for row_no, (label, var) in enumerate(fields, start=1):
        ttk.Label(frame, text=label).grid(row=row_no, column=0, sticky='w', padx=(0, 8), pady=4)
        entry = ttk.Entry(frame, textvariable=var, width=32)
        entry.grid(row=row_no, column=1, sticky='ew', pady=4)
        entries.append(entry)

    note = (
        '接続開始階層は、上位ツリー側でこの工場ツリーの最上位ノードを置く階層です。\n'
        '接続後階層 = ローカル深さ + 接続開始階層 として出力します。\n'
        '対象月はYYYY-MM形式で入力してください。'
    )
    ttk.Label(frame, text=note, justify='left').grid(row=len(fields)+1, column=0, columnspan=2, sticky='w', pady=(6, 10))

    button_frame = ttk.Frame(frame)
    button_frame.grid(row=len(fields)+2, column=0, columnspan=2, sticky='ew')

    def ok():
        values = {label: var.get() for label, var in fields}
        options, error = validate_upper_connection_export_options(
            values['接続開始階層'], values['会社名'], values['拠点名'], values['対象月']
        )
        if error:
            messagebox.showerror('入力エラー', error, parent=dialog)
            return
        result['value'] = options
        dialog.destroy()

    def cancel():
        result['value'] = None
        dialog.destroy()

    ttk.Button(button_frame, text='OK', command=ok).pack(side='right')
    ttk.Button(button_frame, text='キャンセル', command=cancel).pack(side='right', padx=(0, 8))
    dialog.protocol('WM_DELETE_WINDOW', cancel)
    entries[0].focus_set()
    dialog.update_idletasks()
    try:
        x = root.winfo_rootx() + (root.winfo_width() - dialog.winfo_width()) // 2
        y = root.winfo_rooty() + (root.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f'+{max(x, 0)}+{max(y, 0)}')
    except Exception:
        pass
    dialog.wait_window()
    return result['value']

def format_upper_connection_export_summary(summary:Dict[str, Any])->str:
    return (
        f"会社名: {summary.get('会社名', '')}\n"
        f"拠点名: {summary.get('拠点名', '')}\n"
        f"対象月: {summary.get('対象月', '')}\n"
        f"接続開始階層: {summary.get('接続開始階層', '')}\n"
        f"最大ローカル深さ: {summary.get('最大ローカル深さ', '')}\n"
        f"出力ノード数: {summary.get('出力ノード数', 0):,}件\n"
        f"出力末端ノード数: {summary.get('出力末端ノード数', 0):,}件\n"
        f"電源合計: {summary.get('電源合計', 0.0):,.3f} kWh\n"
        f"末端合計: {summary.get('末端合計', 0.0):,.3f} kWh\n"
        f"予算単位数: {summary.get('予算単位数', 0):,}件"
    )

def export_upper_connection_excel():
    options = ask_upper_connection_export_options()
    if not options:
        return
    export_data, error = build_upper_connection_export_data(options)
    if error:
        messagebox.showerror('上位接続Excel出力エラー', error)
        return
    default_name = (
        f"上位接続_{sanitize_filename_part(options['company_name'])}_"
        f"{sanitize_filename_part(options['site_name'])}_{options['target_month']}.xlsx"
    )
    path = filedialog.asksaveasfilename(
        defaultextension='.xlsx',
        filetypes=[('Excelファイル','*.xlsx')],
        initialfile=default_name,
        title='上位接続Excelの保存先を選択'
    )
    if not path:
        return
    try:
        write_upper_connection_excel(path, export_data)
        messagebox.showinfo(
            '上位接続Excel出力',
            '上位接続Excelを保存しました。\n\n'
            f'{path}\n\n'
            + format_upper_connection_export_summary(export_data['summary'])
        )
    except Exception as e:
        print('上位連携データExcel保存エラー:', e)
        messagebox.showerror('上位接続Excel出力エラー', str(e))

def read_tree_csv_dicts_with_fallback(path:str)->Tuple[List[Dict[str,Any]], List[str]]:
    for enc in ('utf-8-sig','cp932','utf-8'):
        try:
            with open(path,'r',encoding=enc,newline='') as f:
                reader=csv.DictReader(f)
                headers=[normalize_header(h) for h in (reader.fieldnames or []) if h is not None]
                rows=[]
                for row in reader:
                    if not row: continue
                    norm={}; empty=True
                    for k,v in row.items():
                        if k is None: continue
                        nk=normalize_header(k); nv=normalize_value(v)
                        if nv!='': empty=False
                        norm[nk]=nv
                    if not empty:
                        rows.append(norm)
                print(f"[CSV] '{path}' 読み込み成功（{enc}）: {len(rows)}行"); return rows, headers
        except Exception as e:
            print(f"[CSV] '{path}' 読み込み失敗（{enc}）: {e}")
    print(f"[CSV] '{path}' 読み込みに失敗しました。"); return [], []

def validate_tree_csv_headers(headers:List[str])->Optional[str]:
    header_set=set(headers)
    missing=[h for h in TREE_CSV_REQUIRED_HEADERS if h not in header_set]
    if missing:
        return '必須列が不足しています: ' + '、'.join(sorted(missing))
    return None

def parse_tree_depth(row:Dict[str,Any], row_no:int, prev_depth:Optional[int])->Tuple[Optional[int], Optional[str]]:
    raw = normalize_value(row.get('階層', row.get('depth','')))
    if raw == '':
        return None, f'{row_no}行目: 階層が空です'
    try:
        depth = int(raw)
    except (TypeError, ValueError):
        return None, f'{row_no}行目: 階層が整数ではありません（{raw}）'
    if str(depth) != raw:
        return None, f'{row_no}行目: 階層が整数ではありません（{raw}）'
    if depth < 0:
        return None, f'{row_no}行目: 階層は0以上である必要があります'
    if depth > MAX_DEPTH:
        return None, f'{row_no}行目: 階層が最大値 {MAX_DEPTH} を超えています'
    return depth, None

def build_tree_nodes_from_rows(rows:List[Dict[str,Any]])->Tuple[Optional[List[FlatNode]], Optional[Set[str]], Optional[str]]:
    new_nodes: List[FlatNode] = []
    new_measure_options = set()
    prev_depth: Optional[int] = None
    for row_no, row in enumerate(rows, start=1):
        depth, error = parse_tree_depth(row, row_no, prev_depth)
        if error:
            return None, None, error
        prev_depth = depth
        measure_name=normalize_value(row.get('計量名称','') or row.get('measure_name',''))
        if measure_name: new_measure_options.add(measure_name)
        reference_measure_name=normalize_value(row.get('参考計量名称','') or row.get('reference_measure_name',''))
        if reference_measure_name: new_measure_options.add(reference_measure_name)
        budget=normalize_value(row.get('予算単位コード','') or row.get('budget_unit',''))
        raw_method = row.get('算出方法', '') or row.get('calc_method', '')
        try:
            excluded = parse_measurement_evaluation_excluded(row.get('計測評価対象外', False))
        except ValueError as error:
            return None, None, f'{row_no}行目: {error}'
        calc_method, method_error = validate_tree_calc_method(raw_method, row_no)
        if method_error:
            return None, None, method_error
        if '属性(Sankey分類)' in row:
            sankey_category = normalize_value(row.get('属性(Sankey分類)', ''))
        elif 'Sankey分類' in row:
            sankey_category = normalize_value(row.get('Sankey分類', ''))
        else:
            sankey_category = normalize_value(row.get('sankey_category', ''))
        new_nodes.append(FlatNode(
            name=row.get('ノード名','') or row.get('name',''),
            calc_method=calc_method,
            at=normalize_value(row.get('AT','') or row.get('at','')),
            measure_name=measure_name,
            # 按分比率は量・比率CSV、または計量名称未入力時のAT仮値から決める。
            ratio=0.0,
            unit=normalize_value(row.get('按分単位','') or row.get('unit','')),
            # ツリーCSVの電力量は入力値として使わず、毎回再計算する。
            energy=0.0,
            depth=depth,
            assign_name='',
            budget_unit=budget,
            sankey_category=sankey_category,
            electric_room=normalize_value(row.get('電気室','') or row.get('electric_room','')),
            transformer=normalize_value(row.get('変圧器','') or row.get('transformer','')),
            notes=normalize_value(row.get('備考','') or row.get('notes','')),
            detail1=normalize_value(row.get('詳細１','') or row.get('detail1','')),
            detail2=normalize_value(row.get('詳細２','') or row.get('detail2','')),
            category1=normalize_value(row.get('分類１','') or row.get('category1','')),
            category2=normalize_value(row.get('分類２','') or row.get('category2','')),
            category3=normalize_value(row.get('分類３','') or row.get('category3','')),
            reference_measure_name=reference_measure_name,
            reference_value=normalize_value(row.get('参考値','') or row.get('reference_value','')),
            reference_unit=normalize_value(row.get('参考単位','') or row.get('reference_unit','')),
            measurement_evaluation_excluded=excluded,
        ))
    return new_nodes, new_measure_options, None

def load_tree_csv_from_path(path:str)->Tuple[Optional[TreeCsvLoadResult], Optional[str]]:
    if not os.path.exists(path):
        return None, f'{os.path.basename(path)}: ファイルが見つかりません'
    if os.path.splitext(path)[1].lower() != '.csv':
        return None, f'{os.path.basename(path)}: CSVファイルではありません'
    rows, headers=read_tree_csv_dicts_with_fallback(path)
    if not headers:
        return None, f'{os.path.basename(path)} を読み込めませんでした'
    header_error = validate_tree_csv_headers(headers)
    if header_error:
        return None, header_error
    new_nodes, new_options, error = build_tree_nodes_from_rows(rows)
    if error:
        return None, error
    return TreeCsvLoadResult(new_nodes, new_options, len(new_nodes)), None

def apply_tree_csv_load_result(result:TreeCsvLoadResult, path:str, redraw:bool=True):
    flat_nodes.clear()
    flat_nodes.extend(result.nodes)
    measure_name_options.clear()
    measure_name_options.update(result.measure_name_options)
    current_input_files["tree"] = path
    set_sample_mode(False)
    invalidate_all_runtime_caches()
    if redraw:
        redraw_preserving_state()
    save_config()

def load_from_csv():
    p=filedialog.askopenfilename(filetypes=[('CSVファイル','*.csv')], title='構成CSVまたは前回CSVを選択')
    if not p: return
    try:
        result, error = load_tree_csv_from_path(p)
        if error:
            messagebox.showerror('構成CSV読込エラー', error)
            return
        apply_tree_csv_load_result(result, p, redraw=True)
        critical_errors = find_critical_calc_structure_errors()
        if critical_errors:
            messagebox.showwarning(
                '構成CSV読込',
                format_critical_calc_structure_error_load_warning(critical_errors)
            )
        if critical_errors:
            message = (
                f'構成引継ぎ完了：{result.row_count:,}ノード\n\n'
                'クリティカル不整合があるため、電力量は正常な計算結果として確定していません。\n'
                '管理（確認事項）または構造検証を確認して修正してください。'
            )
        else:
            message = (
                f'構成引継ぎ完了：{result.row_count:,}ノード\n\n'
                '前回CSVの計算値は使用せず、量・比率CSVなどから再計算します。'
            )
        messagebox.showinfo('構成CSV読込', message)
    except Exception as e:
        print('読み込みエラー:', e)
        messagebox.showerror('構成CSV読込エラー', str(e))


def export_to_csv():
    if not confirm_analysis_export_with_critical_errors('分析CSV'):
        return
    target_month = ask_target_month()
    if not target_month:
        return
    path = filedialog.asksaveasfilename(
        defaultextension='.csv', filetypes=[('CSVファイル','*.csv')],
        initialfile=get_default_analysis_filename(target_month, '.csv'), title='ツリーCSVの保存先を選択')
    if not path: return
    try:
        apply_budget_unit_structure_rules()
        apply_reference_measure_values()
        output_datetime = get_output_datetime_text()
        node_metadata = build_analysis_node_metadata()
        with open(path,'w',encoding='utf-8-sig',newline='') as f:
            w = csv.writer(f)
            w.writerow(TREE_EXPORT_HEADERS)
            for i, _ in enumerate(flat_nodes):
                w.writerow(build_tree_export_row(i, target_month, output_datetime, node_metadata))
        print('保存しました:', path)
    except Exception as e:
        print('保存エラー:', e)

def export_to_excel():
    if not confirm_analysis_export_with_critical_errors('分析Excel'):
        return
    target_month = ask_target_month()
    if not target_month:
        return
    path = filedialog.asksaveasfilename(
        defaultextension='.xlsx', filetypes=[('Excelファイル','*.xlsx')],
        initialfile=get_default_analysis_filename(target_month, '.xlsx'), title='ツリーExcelの保存先を選択')
    if not path: return
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        messagebox.showerror('ツリーExcel出力エラー', 'openpyxl がインストールされていません。')
        return
    try:
        apply_budget_unit_structure_rules()
        apply_reference_measure_values()
        output_datetime = get_output_datetime_text()
        node_metadata = build_analysis_node_metadata()
        wb = Workbook()
        ws = wb.active
        ws.title = 'ツリー'
        ws.append(TREE_EXCEL_HEADERS)
        for i, _ in enumerate(flat_nodes):
            ws.append(build_tree_excel_row(i, target_month, output_datetime, node_metadata))

        header_fill = PatternFill('solid', fgColor='FF305070')
        header_font = Font(bold=True, color='FFFFFFFF')
        thin = Side(style='thin', color='FFD0D0D0')
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        depth_col = TREE_EXCEL_HEADERS.index('階層') + 1
        node_col = TREE_EXCEL_HEADERS.index('ノード名') + 1
        energy_col = TREE_EXCEL_HEADERS.index('電力量') + 1
        reference_value_col = TREE_EXCEL_HEADERS.index('参考値') + 1
        budget_code_col = TREE_EXCEL_HEADERS.index('予算単位コード') + 1
        text_cols = {TREE_EXCEL_HEADERS.index(h) + 1 for h in ('ノードID','親ノードID','ノードIDパス')}
        numeric_cols = {TREE_EXCEL_HEADERS.index(h) + 1 for h in TREE_NUMERIC_HEADERS if h in TREE_EXCEL_HEADERS}

        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = border

        for row_idx in range(2, ws.max_row + 1):
            node = flat_nodes[row_idx - 2]
            fill_color = 'FF' + _depth_color(node.depth).lstrip('#').upper()
            depth_fill = PatternFill('solid', fgColor=fill_color)
            for col_idx in range(1, ws.max_column + 1):
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.fill = depth_fill
                cell.border = border
                if col_idx == depth_col or col_idx == budget_code_col:
                    cell.alignment = Alignment(horizontal='center', vertical='center')
                elif col_idx == node_col:
                    cell.alignment = Alignment(indent=min(node.depth, 15), vertical='center')
                elif col_idx in numeric_cols:
                    cell.alignment = Alignment(horizontal='right', vertical='center')
                else:
                    cell.alignment = Alignment(vertical='center')
                if TREE_EXCEL_HEADERS[col_idx - 1] in ('計測推奨境界', '計測評価対象外'):
                    cell.number_format = '0'
                elif TREE_EXCEL_HEADERS[col_idx - 1] == '経路推定累積度':
                    cell.number_format = '0.000'
                elif TREE_EXCEL_HEADERS[col_idx - 1] in ('個別推定量', '下流確定量', '下流未確定量', '末端理論最大値'):
                    cell.number_format = '#,##0.0'
                elif col_idx in (energy_col, reference_value_col):
                    cell.number_format = '#,##0.0'
                elif col_idx in text_cols:
                    cell.number_format = '@'

        # 1行目のタイトル行を固定表示する。
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions
        for col_idx in range(1, ws.max_column + 1):
            max_len = 0
            for row_idx in range(1, min(ws.max_row, SAMPLE_ROWS_FOR_MEASURE) + 1):
                value = ws.cell(row=row_idx, column=col_idx).value
                max_len = max(max_len, len(str(value)) if value is not None else 0)
            ws.column_dimensions[get_column_letter(col_idx)].width = min(max(max_len + 2, 10), 36)
        ws.column_dimensions[get_column_letter(depth_col)].width = 6
        ws.column_dimensions[get_column_letter(TREE_EXCEL_HEADERS.index('ノードパス') + 1)].width = 48

        wb.save(path)
        print('保存しました:', path)
    except Exception as e:
        print('Excel保存エラー:', e)
        messagebox.showerror('ツリーExcel出力エラー', str(e))

# ---- Sankey図CSV出力 ----

SANKEY_LINK_HEADERS = [
    'source_id','source_label','target_id','target_label','value',
    'source_layer','target_layer','link_type','対象年月','出力日時','単位'
]
SANKEY_LOG_HEADERS = [
    '区分','項目','値','単位','説明','電気室','Sankey分類','予算単位コード',
    '予算単位名称','集計後電力量','対象行数','対象行番号'
]

class SankeyExportError(ValueError):
    pass

def ask_sankey_export_options() -> Optional[dict]:
    options = get_target_month_options()
    dialog = tk.Toplevel(root)
    dialog.title('Sankey図CSV出力')
    dialog.transient(root); dialog.grab_set(); dialog.resizable(False, False)
    result = {'value': None}
    frame = ttk.Frame(dialog, padding=12); frame.pack(fill='both', expand=True)
    month_var = tk.StringVar(value=options[0] if options else get_default_target_month())
    min_var = tk.StringVar(value='0.0')
    mode_var = tk.StringVar(value='その他にまとめる')
    tolerance_var = tk.StringVar(value='10.0')
    fields = [
        ('対象年月', ttk.Combobox(frame, textvariable=month_var, values=options, state='readonly', width=18)),
        ('最小電力量 (kWh)', ttk.Entry(frame, textvariable=min_var, width=20)),
        ('最小電力量以下の扱い', ttk.Combobox(frame, textvariable=mode_var, values=('無視する','その他にまとめる'), state='readonly', width=18)),
        ('Sankey負値許容値 (kWh)', ttk.Entry(frame, textvariable=tolerance_var, width=20)),
    ]
    for row_no, (label, widget) in enumerate(fields):
        ttk.Label(frame, text=label).grid(row=row_no, column=0, sticky='w', padx=(0,12), pady=4)
        widget.grid(row=row_no, column=1, sticky='w', pady=4)
    buttons = ttk.Frame(frame); buttons.grid(row=len(fields), column=0, columnspan=2, sticky='e', pady=(12,0))
    def ok():
        try:
            min_kwh = float(min_var.get())
            tolerance = float(tolerance_var.get())
            if not math.isfinite(min_kwh) or min_kwh < 0:
                raise ValueError('最小電力量は0以上の有限数にしてください。')
            if not math.isfinite(tolerance) or tolerance < 0:
                raise ValueError('Sankey負値許容値は0以上の有限数にしてください。')
        except ValueError as e:
            messagebox.showerror('Sankey図CSV出力', str(e), parent=dialog)
            return
        result['value'] = {
            'target_month': month_var.get(), 'min_kwh': min_kwh,
            'small_link_mode': mode_var.get(), 'negative_tolerance_kwh': tolerance
        }
        dialog.destroy()
    def cancel():
        dialog.destroy()
    ttk.Button(buttons, text='キャンセル', command=cancel).pack(side='right')
    ttk.Button(buttons, text='OK', command=ok).pack(side='right', padx=(0,8))
    dialog.protocol('WM_DELETE_WINDOW', cancel)
    dialog.bind('<Escape>', lambda _e: cancel())
    dialog.wait_window()
    return result['value']

def _sankey_log_row(section:str, item:str='', value:Any='', unit:str='', description:str='', **extra)->dict:
    row = {h: '' for h in SANKEY_LOG_HEADERS}
    row.update({'区分':section, '項目':item, '値':value, '単位':unit, '説明':description})
    row.update({k:v for k,v in extra.items() if k in row})
    return row

def build_sankey_data(target_month: str, min_kwh: float, small_link_mode: str,
                      negative_tolerance_kwh: float, output_datetime: Optional[str] = None) -> Tuple[List[dict], List[dict], List[str]]:
    """現在の配賦結果から、非負のSankeyリンクと監査用ログを作る。"""
    critical_errors = find_critical_calc_structure_errors()
    if critical_errors:
        raise SankeyExportError(format_critical_calc_structure_error_sankey_error(critical_errors))
    if not has_power_budget_unit_node():
        raise SankeyExportError(format_missing_power_budget_unit_error('Sankey図CSV'))
    if small_link_mode not in ('無視する', 'その他にまとめる'):
        raise SankeyExportError('最小電力量以下の扱いが不正です。')
    for label, value in (('最小電力量', min_kwh), ('Sankey負値許容値', negative_tolerance_kwh)):
        if not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise SankeyExportError(f'{label}は0以上の有限数にしてください。')

    apply_budget_unit_structure_rules()
    if output_datetime is None:
        output_datetime = get_output_datetime_text()
    log_rows: List[dict] = []
    warnings: List[str] = []
    power_by_name: Dict[str, float] = {}
    missing_power_categories = []
    demand_groups: Dict[Tuple[str,str,str], dict] = {}

    for index, node in enumerate(flat_nodes):
        row_no = index + 1
        code = get_effective_budget_unit_code(index)
        category = get_effective_sankey_category(index)
        try:
            energy = float(node.energy)
        except (TypeError, ValueError):
            energy = 0.0
        if code == BUDGET_UNIT_POWER:
            if not category:
                missing_power_categories.append(f'{row_no}行目「{node.name}」')
                log_rows.append(_sankey_log_row('警告', '電源分類空白', '', '',
                    f'{row_no}行目「{node.name}」'))
            else:
                power_by_name[category] = power_by_name.get(category, 0.0) + abs(energy)
            continue
        if code in ('', BUDGET_UNIT_AGGREGATE):
            continue

        room_raw = normalize_value(node.electric_room)
        room = room_raw or '電気室未設定'
        use = category or 'その他用途'
        budget_name = get_budget_unit_name(index)
        if not budget_name:
            budget_name = code
            text = f'{row_no}行目「{node.name}」: 表示名に予算単位コード「{code}」を使用'
            warnings.append(text)
            log_rows.append(_sankey_log_row('警告', '予算単位名称未設定', '', '', text,
                **{'電気室':room, 'Sankey分類':use, '予算単位コード':code, '予算単位名称':budget_name}))
        if not room_raw:
            text = f'{row_no}行目「{node.name}」'
            warnings.append('電気室未設定: ' + text)
            log_rows.append(_sankey_log_row('警告', '電気室未設定', '', '', text,
                **{'電気室':room, 'Sankey分類':use, '予算単位コード':code, '予算単位名称':budget_name}))
        if not category:
            text = f'{row_no}行目「{node.name}」: その他用途として集計'
            warnings.append(text)
            log_rows.append(_sankey_log_row('警告', 'Sankey分類空白', '', '', text,
                **{'電気室':room, 'Sankey分類':use, '予算単位コード':code, '予算単位名称':budget_name}))
        key = (room, use, code)
        group = demand_groups.setdefault(key, {'value':0.0, 'rows':[], 'budget_name':budget_name})
        group['value'] += energy
        group['rows'].append(row_no)
        if group['budget_name'] == code and budget_name != code:
            group['budget_name'] = budget_name

    if missing_power_categories:
        detail = '\n'.join(missing_power_categories[:30])
        raise SankeyExportError('予算単位コードが「電源」なのにSankey分類が空白です。\n' + detail)
    if not power_by_name:
        raise SankeyExportError('Sankey分類が設定された電源ノードが1件もありません。')
    power_total = sum(power_by_name.values())
    if power_total <= 0:
        raise SankeyExportError(f'電源ミックス合計が0以下です（{power_total:,.3f} kWh）。')

    demand_before = sum(float(g['value']) for g in demand_groups.values())
    positive_groups = {k:g for k,g in demand_groups.items() if g['value'] > 0}
    excluded_groups = {k:g for k,g in demand_groups.items() if g['value'] <= 0}
    demand_after = sum(float(g['value']) for g in positive_groups.values())
    excluded_negative_total = sum(float(g['value']) for g in excluded_groups.values())
    for (room, use, code), group in excluded_groups.items():
        log_rows.append(_sankey_log_row(
            '負値除外', description='クロス集計後0以下のため描画用CSVから除外',
            **{'電気室':room, 'Sankey分類':use, '予算単位コード':code,
               '予算単位名称':group['budget_name'], '集計後電力量':group['value'],
               '対象行数':len(group['rows']), '対象行番号':';'.join(map(str, group['rows']))}
        ))
    negative_ok = abs(excluded_negative_total) <= negative_tolerance_kwh
    if excluded_negative_total < 0 and negative_ok:
        warnings.append(f'除外した負値合計 {excluded_negative_total:,.3f} kWh は許容値内です。')
    if not negative_ok:
        details = [f'{r} / {u} / {c}: {g["value"]:,.3f} kWh（行 {";".join(map(str,g["rows"]))}）'
                   for (r,u,c),g in excluded_groups.items() if g['value'] < 0]
        raise SankeyExportError(
            f'除外した負値合計 {excluded_negative_total:,.3f} kWh の絶対値が、'
            f'Sankey負値許容値 {negative_tolerance_kwh:,.3f} kWh を超えています。\n\n' +
            '\n'.join(details[:20]))

    actual_loss = power_total - demand_before
    sankey_loss = power_total - demand_after
    loss_difference = sankey_loss - actual_loss
    if actual_loss < 0:
        warnings.append(f'実配賦ベース補器・損失がマイナスです（{actual_loss:,.3f} kWh）。')
        log_rows.append(_sankey_log_row('警告','実配賦ベース補器・損失がマイナス',actual_loss,'kWh'))
    if sankey_loss < -1e-9:
        log_rows.append(_sankey_log_row('警告','Sankey用補器・損失がマイナス',sankey_loss,'kWh'))
        raise SankeyExportError(
            'Sankey用補器・損失がマイナスのため出力を中止します。\n'
            f'電源ミックス合計: {power_total:,.3f} kWh\n'
            f'負値除外後のSankey需要側合計: {demand_after:,.3f} kWh\n'
            f'Sankey用補器・損失: {sankey_loss:,.3f} kWh')
    if abs(sankey_loss) < 1e-9:
        sankey_loss = 0.0

    raw_links: List[dict] = []
    def add_link(source_id, source_label, target_id, target_label, value,
                 source_layer, target_layer, link_type):
        if value <= 0:
            return
        raw_links.append({
            'source_id':source_id, 'source_label':source_label,
            'target_id':target_id, 'target_label':target_label, 'value':value,
            'source_layer':source_layer, 'target_layer':target_layer,
            'link_type':link_type, '対象年月':target_month,
            '出力日時':output_datetime, '単位':'kWh'
        })
    for name, value in sorted(power_by_name.items()):
        add_link(f'L1_POWER:{name}', name, 'L2_MIX:電源ミックス', '電源ミックス', value, 1, 2, '電源→電源ミックス')
    room_totals: Dict[str,float] = {}
    room_use_totals: Dict[Tuple[str,str],float] = {}
    use_budget_totals: Dict[Tuple[str,str,str],float] = {}
    for (room,use,code), group in positive_groups.items():
        value = float(group['value'])
        room_totals[room] = room_totals.get(room, 0.0) + value
        room_use_totals[(room,use)] = room_use_totals.get((room,use), 0.0) + value
        key = (use,code,group['budget_name'])
        use_budget_totals[key] = use_budget_totals.get(key, 0.0) + value
    for room,value in sorted(room_totals.items()):
        add_link('L2_MIX:電源ミックス','電源ミックス',f'L3_ROOM:{room}',room,value,2,3,'電源ミックス→電気室')
    if sankey_loss > 0:
        add_link('L2_MIX:電源ミックス','電源ミックス','L3_LOSS:補器・損失','補器・損失',sankey_loss,2,3,'電源ミックス→補器・損失')
    for (room,use),value in sorted(room_use_totals.items()):
        add_link(f'L3_ROOM:{room}',room,f'L4_USE:{use}',use,value,3,4,'電気室→用途')
    for (use,code,budget_name),value in sorted(use_budget_totals.items()):
        add_link(f'L4_USE:{use}',use,f'L5_BUDGET:{code}',budget_name,value,4,5,'用途→予算単位')

    small_links = [link for link in raw_links if link['value'] <= min_kwh]
    large_links = [link for link in raw_links if link['value'] > min_kwh]
    threshold_count = len(small_links)
    threshold_total = sum(link['value'] for link in small_links)
    if small_link_mode == 'その他にまとめる':
        replacements = {
            '電源→電源ミックス': ('source','L1_POWER:その他電源','その他電源'),
            '電源ミックス→電気室': ('target','L3_ROOM:その他電気室','その他電気室'),
            '電気室→用途': ('target','L4_USE:その他用途','その他用途'),
            '用途→予算単位': ('target','L5_BUDGET:__OTHER__','その他予算単位'),
        }
        merged: Dict[Tuple,dict] = {}
        for link in small_links:
            item = dict(link)
            replacement = replacements.get(item['link_type'])
            if replacement:
                side, node_id, label = replacement
                item[f'{side}_id'] = node_id; item[f'{side}_label'] = label
            key = tuple(item[h] for h in SANKEY_LINK_HEADERS if h not in ('value','出力日時'))
            if key in merged:
                merged[key]['value'] += item['value']
            else:
                merged[key] = item
        links = large_links + list(merged.values())
        action = 'その他化'
    else:
        links = large_links
        action = '除外'
    if threshold_count:
        text = f'{threshold_count}件、合計 {threshold_total:,.3f} kWh を{action}'
        warnings.append('最小電力量しきい値: ' + text)
        log_rows.append(_sankey_log_row('警告','最小電力量しきい値',threshold_total,'kWh',text))

    summary = [
        ('対象年月',target_month,'',''), ('出力日時',output_datetime,'',''),
        ('電源ミックス合計',power_total,'kWh','電源ノードの絶対値合計'),
        ('負値除外前の需要側合計',demand_before,'kWh','通常予算単位コードを持つ需要側の符号付き合計'),
        ('負値除外後のSankey需要側合計',demand_after,'kWh','クロス集計後の正値合計'),
        ('除外した負値合計',excluded_negative_total,'kWh','クロス集計後0以下となった値の合計'),
        ('実配賦ベース補器・損失',actual_loss,'kWh','電源ミックス合計－負値除外前需要側合計'),
        ('Sankey用補器・損失',sankey_loss,'kWh','電源ミックス合計－負値除外後需要側合計'),
        ('補器・損失の差',loss_difference,'kWh','負値除外による補器・損失への影響'),
        ('Sankey負値許容値',negative_tolerance_kwh,'kWh',''),
        ('負値判定結果','許容値内' if negative_ok else '許容値超過','',''),
        ('最小電力量',min_kwh,'kWh','リンク単位のしきい値'),
        ('最小電力量以下の扱い',small_link_mode,'',''),
        ('しきい値除外件数',threshold_count,'件',action),
        ('しきい値除外合計',threshold_total,'kWh',action),
    ]
    log_rows[0:0] = [_sankey_log_row('サマリー',item,value,unit,desc) for item,value,unit,desc in summary]
    links.sort(key=lambda x:(x['source_layer'],x['target_layer'],x['link_type'],x['source_id'],x['target_id']))
    return links, log_rows, warnings

def write_sankey_links_csv(path: str, links: List[dict]):
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=SANKEY_LINK_HEADERS, extrasaction='ignore')
        writer.writeheader(); writer.writerows(links)

def write_sankey_log_csv(path: str, log_rows: List[dict]):
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=SANKEY_LOG_HEADERS, extrasaction='ignore')
        writer.writeheader(); writer.writerows(log_rows)

def export_sankey_csv():
    critical_errors = find_critical_calc_structure_errors()
    if critical_errors:
        messagebox.showerror(
            'Sankey図CSV出力エラー',
            format_critical_calc_structure_error_sankey_error(critical_errors)
        )
        return
    if not has_power_budget_unit_node():
        messagebox.showerror('Sankey図CSV出力エラー', format_missing_power_budget_unit_error('Sankey図CSV'))
        return
    options = ask_sankey_export_options()
    if not options:
        return
    path = filedialog.asksaveasfilename(
        defaultextension='.csv', filetypes=[('CSVファイル','*.csv')],
        initialfile=get_default_analysis_filename(options['target_month'], '.csv', 'Sankey'),
        title='Sankey描画用CSVの保存先を選択')
    if not path:
        return
    base, extension = os.path.splitext(path)
    if not extension:
        extension = '.csv'; path = base + extension
    log_path = base + '_log' + extension
    try:
        apply_masters_from_csv(); calculate_energy(); apply_budget_unit_structure_rules()
        links, log_rows, warnings = build_sankey_data(**options)
        # 検証完了後に一時ファイルへ書き、完成した2ファイルだけを置換する。
        links_tmp = path + '.tmp'; log_tmp = log_path + '.tmp'
        try:
            write_sankey_links_csv(links_tmp, links)
            write_sankey_log_csv(log_tmp, log_rows)
            os.replace(links_tmp, path); os.replace(log_tmp, log_path)
        finally:
            for tmp in (links_tmp, log_tmp):
                if os.path.exists(tmp):
                    try: os.remove(tmp)
                    except OSError: pass
        message = f'Sankey描画用CSVと集計ログCSVを保存しました。\n\n{path}\n{log_path}'
        if warnings:
            message += f'\n\n警告 {len(warnings)}件（詳細はログCSVを確認してください）\n' + '\n'.join(warnings[:8])
            messagebox.showwarning('Sankey図CSV出力', message)
        else:
            messagebox.showinfo('Sankey図CSV出力', message)
    except SankeyExportError as e:
        messagebox.showerror('Sankey図CSV出力エラー', str(e))
    except Exception as e:
        print('Sankey図CSV保存エラー:', e)
        messagebox.showerror('Sankey図CSV出力エラー', str(e))

# ---- 入力データ一括読み込み ----
class SingleCsvSelector:
    def __init__(self, parent, title:str, select_title:str, initial_path:Optional[str], current_path:Optional[str]):
        self.title = title
        self.select_title = select_title
        self.path = initial_path
        self.current_path = current_path
        self.was_cleared = False
        self.frame = tk.Frame(parent, bg='#f5f5f5', bd=1, relief='solid')
        self.frame.columnconfigure(0, weight=1)
        ttk.Label(self.frame, text=title, font=('', 10, 'bold')).grid(row=0, column=0, sticky='w', padx=10, pady=(8,2))
        self.status_var = tk.StringVar()
        self.name_var = tk.StringVar()
        self.mtime_var = tk.StringVar()
        self.folder_var = tk.StringVar()
        self.result_var = tk.StringVar()
        self.rows_var = tk.StringVar()
        ttk.Label(self.frame, textvariable=self.status_var, width=14, anchor='e').grid(row=0, column=1, sticky='e', padx=10, pady=(8,2))

        body = ttk.Frame(self.frame)
        body.grid(row=1, column=0, columnspan=2, sticky='nsew', padx=10, pady=(2,8))
        body.columnconfigure(0, weight=2, uniform='bulk_selector')
        body.columnconfigure(1, weight=3, uniform='bulk_selector')
        left_frame = ttk.Frame(body)
        right_frame = ttk.Frame(body)
        left_frame.grid(row=0, column=0, sticky='nsew', padx=(0,12))
        right_frame.grid(row=0, column=1, sticky='nsew')
        right_frame.columnconfigure(1, weight=1)
        self.drop_target_frame = left_frame
        self._build_operation_panel(left_frame)
        self._build_information_panel(right_frame)
        self._enable_drop()
        self.refresh()

    def _build_operation_panel(self, parent):
        parent.columnconfigure(0, weight=1)
        self.drop_label = tk.Label(parent, text='CSVをここへドロップ', bg='#ffffff', relief='ridge', height=4)
        self.drop_label.grid(row=0, column=0, sticky='nsew')
        btns = ttk.Frame(parent)
        btns.grid(row=1, column=0, sticky='w', pady=(6,0))
        ttk.Button(btns, text='ファイルを選択', command=self.select_file).pack(side='left')
        ttk.Button(btns, text='選択を解除', command=self.clear).pack(side='left', padx=(6,0))

    def _build_information_panel(self, parent):
        self._add_info_row(parent, 0, 'ファイル名', self.name_var)
        self._add_info_row(parent, 1, '更新日時', self.mtime_var)
        folder_label = self._add_info_row(parent, 2, '保存場所', self.folder_var)
        SimpleTooltip(folder_label, lambda: self.path or '')
        self._add_info_row(parent, 3, '結果', self.result_var)
        self._add_info_row(parent, 4, '読み込み行数', self.rows_var)

    def _add_info_row(self, parent, row:int, label:str, var:tk.StringVar):
        ttk.Label(parent, text=label, width=12).grid(row=row, column=0, sticky='nw', padx=(0,8), pady=1)
        value = ttk.Label(parent, textvariable=var, anchor='w', justify='left', wraplength=520)
        value.grid(row=row, column=1, sticky='ew', pady=1)
        return value

    def _enable_drop(self):
        if not DND_AVAILABLE:
            self.drop_label.configure(text='ドラッグ＆ドロップは利用できません。\nファイル選択を使用してください。')
            return
        for widget in (self.drop_target_frame, self.drop_label):
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind('<<Drop>>', self._on_drop)

    def _on_drop(self, event):
        paths = parse_dropped_file_paths(self.frame, event.data)
        if len(paths) != 1:
            self.set_error('CSVを1ファイルだけ指定してください')
            return
        if os.path.splitext(paths[0])[1].lower() != '.csv':
            self.set_error('CSV以外のファイルは登録できません')
            return
        self.path = paths[0]
        self.was_cleared = False
        self.refresh()

    def select_file(self):
        p = filedialog.askopenfilename(filetypes=[('CSVファイル','*.csv')], title=self.select_title)
        if p:
            self.path = p
            self.was_cleared = False
            self.refresh()

    def clear(self):
        self.path = None
        self.was_cleared = True
        self.refresh()

    def set_error(self, message:str):
        self.result_var.set(message)
        self.status_var.set('エラー')
        self.frame.configure(bg='#fff0f0')

    def set_result(self, status:CsvFileStatus):
        self.result_var.set(status.result or status.error or status.status)
        self.rows_var.set('' if status.row_count is None else f'{status.row_count:,}行')
        self.status_var.set(status.status)
        self.frame.configure(bg='#eef8ee' if status.status == '正常' else '#fff0f0')

    def refresh(self):
        p = self.path
        self.name_var.set(os.path.basename(p) if p else '未選択')
        self.folder_var.set(short_folder_path(p) if p else '')
        self.rows_var.set('')
        if not p:
            self.mtime_var.set('')
            self.result_var.set('未読込')
            self.status_var.set('未選択')
            self.frame.configure(bg='#f5f5f5')
            return
        mtime, error = format_file_mtime(p)
        self.mtime_var.set(mtime or error or '')
        if error:
            self.result_var.set(error)
            self.status_var.set('エラー')
            self.frame.configure(bg='#fff0f0')
            return
        if same_file_path(p, self.current_path):
            if self.title.startswith('予算単位CSV') and budget_csv_auto_loaded:
                self.result_var.set('前回設定を自動読込済み')
            else:
                self.result_var.set('現在使用中、今回変更なし')
            self.status_var.set('現在使用中')
        elif self.current_path:
            self.result_var.set('選択済み')
            self.status_var.set('選択済み')
        else:
            self.result_var.set('前回候補' if p else '未読込')
            self.status_var.set('選択済み')
        self.frame.configure(bg='#eef3fb')

class MultiCsvSelector:
    def __init__(self, parent, title:str, initial_paths:List[str], current_paths:List[str]):
        self.title = title
        self.paths: List[str] = []
        self.current_paths = list(current_paths or [])
        self.status_by_path: Dict[str, CsvFileStatus] = {}
        self.iid_to_path: Dict[str, str] = {}
        self.frame = tk.Frame(parent, bg='#f5f5f5', bd=1, relief='solid')
        self.frame.columnconfigure(0, weight=1)
        top = ttk.Frame(self.frame)
        top.grid(row=0, column=0, columnspan=2, sticky='ew', padx=10, pady=(8,2))
        top.columnconfigure(0, weight=1)
        ttk.Label(top, text=title, font=('', 10, 'bold')).grid(row=0, column=0, sticky='w')
        self.status_var = tk.StringVar()
        ttk.Label(top, textvariable=self.status_var, width=18, anchor='e').grid(row=0, column=1, sticky='e')

        body = ttk.Frame(self.frame)
        body.grid(row=1, column=0, sticky='nsew', padx=10, pady=(2,8))
        body.columnconfigure(0, weight=2, uniform='bulk_selector')
        body.columnconfigure(1, weight=3, uniform='bulk_selector')
        body.rowconfigure(0, weight=1)
        left_frame = ttk.Frame(body)
        table = ttk.Frame(body)
        left_frame.grid(row=0, column=0, sticky='nsew', padx=(0,12))
        table.grid(row=0, column=1, sticky='nsew')
        left_frame.columnconfigure(0, weight=1)
        table.rowconfigure(0, weight=1); table.columnconfigure(0, weight=1)
        self.drop_target_frame = left_frame
        self.drop_label = tk.Label(left_frame, text='CSVをここへドロップ（複数可）', bg='#ffffff', relief='ridge', height=4)
        self.drop_label.grid(row=0, column=0, sticky='nsew')
        btns = ttk.Frame(left_frame)
        btns.grid(row=1, column=0, sticky='w', pady=(6,0))
        ttk.Button(btns, text='ファイルを追加', command=self.add_files).grid(row=0, column=0, sticky='w')
        ttk.Button(btns, text='選択ファイルを解除', command=self.remove_selected).grid(row=0, column=1, sticky='w', padx=(6,0))
        ttk.Button(btns, text='すべて解除', command=self.clear).grid(row=1, column=0, sticky='w', pady=(4,0))
        cols = ('ファイル名','更新日時','保存場所','結果','読み込み行数')
        self.tv = ttk.Treeview(table, columns=cols, show='headings', height=3)
        vsb = ttk.Scrollbar(table, orient='vertical', command=self.tv.yview)
        self.tv.configure(yscrollcommand=vsb.set)
        for c in cols:
            self.tv.heading(c, text=c)
            width = 90 if c == '読み込み行数' else 130
            if c in ('ファイル名', '保存場所'):
                width = 180
            self.tv.column(c, width=width, anchor='w', stretch=True)
        self.tv.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns')
        self.tv.bind('<MouseWheel>', self._on_tree_mousewheel, add='+')
        SimpleTooltip(self.tv, self._selected_full_path)
        self._enable_drop()
        self.add_paths(initial_paths, quiet=True)
        self.refresh()

    def _selected_full_path(self):
        sel = self.tv.selection()
        if not sel:
            return ''
        return self.iid_to_path.get(sel[0], '')

    def _enable_drop(self):
        if not DND_AVAILABLE:
            self.drop_label.configure(text='ドラッグ＆ドロップは利用できません。\nファイル選択を使用してください。')
            return
        for widget in (self.drop_target_frame, self.drop_label):
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind('<<Drop>>', self._on_drop)

    def _on_tree_mousewheel(self, event):
        self.tv.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        return 'break'

    def _on_drop(self, event):
        paths = parse_dropped_file_paths(self.frame, event.data)
        bad = [p for p in paths if os.path.splitext(p)[1].lower() != '.csv']
        if bad:
            self.status_var.set('エラー')
            messagebox.showerror('実測値・按分比率CSV読込エラー', 'CSV以外のファイルは登録できません。\n' + '\n'.join(bad[:5]))
            return
        self.add_paths(paths)

    def add_files(self):
        paths = filedialog.askopenfilenames(filetypes=[('CSVファイル','*.csv')], title='実測値・按分比率CSVを選択')
        self.add_paths(list(paths))

    def add_paths(self, paths:List[str], quiet:bool=False):
        seen = {os.path.abspath(p).lower() for p in self.paths}
        added = 0
        for p in paths:
            key = os.path.abspath(p).lower()
            if key in seen:
                continue
            self.paths.append(p)
            seen.add(key)
            added += 1
        self.refresh()
        if not quiet and added == 0 and paths:
            self.status_var.set('重複のため追加なし')

    def remove_selected(self):
        selected_paths = set()
        for iid in self.tv.selection():
            path = self.iid_to_path.get(iid)
            if path:
                selected_paths.add(path)
        if selected_paths:
            self.paths = [p for p in self.paths if p not in selected_paths]
            self.refresh()

    def clear(self):
        self.paths.clear()
        self.status_by_path.clear()
        self.refresh()

    def set_results(self, statuses:List[CsvFileStatus]):
        self.status_by_path = {s.path: s for s in statuses}
        self.refresh()

    def refresh(self):
        self.tv.delete(*self.tv.get_children(''))
        self.iid_to_path.clear()
        if not self.paths:
            self.status_var.set('未選択')
            self.frame.configure(bg='#f5f5f5')
            return
        any_error = False
        any_normal = False
        for p in self.paths:
            status = self.status_by_path.get(p)
            mtime, mtime_error = format_file_mtime(p)
            result = '現在使用中、今回変更なし' if any(same_file_path(p, cp) for cp in self.current_paths) else '選択済み'
            rows = ''
            if mtime_error:
                result = mtime_error
                any_error = True
            if status:
                result = status.result or status.error or status.status
                rows = '' if status.row_count is None else f'{status.row_count:,}'
                any_error = any_error or status.status == 'エラー'
                any_normal = any_normal or status.status == '正常'
            iid = self.tv.insert('', 'end', values=(os.path.basename(p), mtime or mtime_error or '', short_folder_path(p), result, rows))
            self.iid_to_path[iid] = p
        if any_error:
            self.status_var.set('エラー')
            self.frame.configure(bg='#fff0f0')
        elif any_normal:
            self.status_var.set('正常')
            self.frame.configure(bg='#eef8ee')
        else:
            self.status_var.set('選択済み')
            self.frame.configure(bg='#eef3fb')

def count_management_notice_rows()->int:
    count = 0
    for i, _node in enumerate(flat_nodes):
        m1, m2, m3 = compute_management_values(i)
        notice = format_management_notice_display(i)
        if m1 or m2 or m3 or notice:
            count += 1
    return count

def count_management_flags()->Dict[str, Any]:
    counts = {
        'measurement_individual': 0,
        'group_uncertainty_nodes': 0,
        'measurement_accumulation': 0,
        'over_power': 0,
        'parent_child_difference': 0,
    }
    for i, _node in enumerate(flat_nodes):
        m_parent_child, m_over_power, _m_negative = compute_management_values(i)
        if m_parent_child:
            counts['parent_child_difference'] += 1
        if m_over_power:
            counts['over_power'] += 1
        individual, _downstream, uncertainty, _maximum, accumulation, _boundary, _excluded = format_estimation_indicator_values(i)
        if individual != '':
            counts['measurement_individual'] += 1
        if uncertainty != '':
            counts['group_uncertainty_nodes'] += 1
        if accumulation != '':
            counts['measurement_accumulation'] += 1
    counts.update(get_measurement_investment_kpis())
    return counts

def build_bulk_success_message(tree_path:str, tree_rows:int, measure_paths:List[str], measure_unique:int,
                               budget_path:str, budget_unique:int, reused:List[str],
                               notice_count:Optional[int]=None)->str:
    critical_count = len(find_critical_calc_structure_errors())
    lines = [
        (
            '入力データを読み込みましたが、クリティカル不整合のため計算結果は確定していません。'
            if critical_count else
            '入力データを読み込み、計算を実行しました。'
        ),
        '前回CSVまたは構成CSVから構成・属性・設定を引き継ぎました。',
        '前回CSVの計算値は使用せず、今回の入力値から再計算しています。',
        '',
        '構成CSV（構成引継ぎ元）：',
        os.path.basename(tree_path) if tree_path else '現在の画面データ',
        f'{tree_rows:,}ノード',
        '',
        '実測値・按分比率CSV：',
        f'{len(measure_paths):,}ファイル',
        f'{measure_unique:,}件',
        '',
        '予算単位CSV：',
        os.path.basename(budget_path) if budget_path else '未指定',
        f'{budget_unique:,}件',
    ]
    if reused:
        lines += ['', '現在使用中のデータを継続利用：', '、'.join(reused)]
    if critical_count:
        lines += ['', f'クリティカル不整合：{critical_count:,}件', '管理（確認事項）または構造検証を確認してください。']
    if notice_count is None:
        notice_count = count_management_notice_rows()
    if notice_count:
        lines += ['', f'管理上の確認事項がある行：{notice_count:,}件']
    return '\n'.join(lines)

def build_bulk_success_summary(tree_rows:int, measure_unique:int, budget_unique:int, notice_count:int)->str:
    critical_count = len(find_critical_calc_structure_errors())
    if critical_count:
        return (
            f'構成引継ぎ完了：{tree_rows:,}ノード／'
            f'クリティカル不整合{critical_count:,}件／'
            f'要確認行{notice_count:,}件'
        )
    return (
        f'構成引継ぎ完了：{tree_rows:,}ノード／'
        f'実測値{measure_unique:,}件／予算単位{budget_unique:,}件／'
        f'要確認行{notice_count:,}件'
    )

def show_bulk_input_window():
    global bulk_input_window
    if bulk_input_window is not None and bulk_input_window.winfo_exists():
        bulk_input_window.lift()
        bulk_input_window.focus_force()
        return

    top = tk.Toplevel(root)
    bulk_input_window = top
    top.title('入力データの読み込み')
    screen_w = top.winfo_screenwidth()
    screen_h = top.winfo_screenheight()
    width = min(1180, max(900, screen_w - 100))
    height = min(700, max(520, screen_h - 160))
    width = min(width, max(640, screen_w - 40))
    height = min(height, max(420, screen_h - 80))
    x = max(0, (screen_w - width) // 2)
    y = max(0, (screen_h - height) // 2)
    top.geometry(f'{width}x{height}+{x}+{y}')
    top.minsize(min(860, width), min(500, height))
    top.transient(root)
    top.columnconfigure(0, weight=1)
    top.rowconfigure(0, weight=1)

    outer = ttk.Frame(top)
    outer.grid(row=0, column=0, sticky='nsew')
    outer.rowconfigure(0, weight=1); outer.columnconfigure(0, weight=1)
    canvas = tk.Canvas(outer, highlightthickness=0)
    scrollbar = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    content = ttk.Frame(canvas)
    window_id = canvas.create_window((0, 0), window=content, anchor='nw')
    canvas.grid(row=0, column=0, sticky='nsew'); scrollbar.grid(row=0, column=1, sticky='ns')
    content.columnconfigure(0, weight=1)
    content.bind('<Configure>', lambda _e: canvas.configure(scrollregion=canvas.bbox('all')))
    canvas.bind('<Configure>', lambda e: canvas.itemconfigure(window_id, width=e.width))
    def _on_mousewheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')
    canvas.bind('<MouseWheel>', _on_mousewheel)
    content.bind('<MouseWheel>', _on_mousewheel)
    def _bind_canvas_mousewheel(widget):
        if isinstance(widget, ttk.Treeview):
            return
        widget.bind('<MouseWheel>', _on_mousewheel, add='+')
        for child in widget.winfo_children():
            _bind_canvas_mousewheel(child)

    tree_initial = current_input_files.get("tree") or config_input_file_candidates.get("tree")
    measure_initial = current_input_files.get("measure") or config_input_file_candidates.get("measure") or []
    budget_initial = current_input_files.get("budget") or config_input_file_candidates.get("budget")
    tree_selector = SingleCsvSelector(content, '構成CSV（前回CSVから構成引継ぎ可）', '構成CSVまたは前回CSVを選択', tree_initial, current_input_files.get("tree"))
    measure_selector = MultiCsvSelector(content, '実測値・按分比率CSV', list(measure_initial), current_input_files.get("measure") or [])
    budget_selector = SingleCsvSelector(content, '予算単位CSV', '予算単位CSVを選択', budget_initial, current_input_files.get("budget"))
    for pane in (tree_selector.frame, measure_selector.frame, budget_selector.frame):
        pane.pack(fill='x', expand=True, padx=10, pady=5)

    initial_message = '前回CSVまたは構成CSVから構成・属性・設定を引き継ぎ、今回の入力値で再計算します。'
    if budget_csv_auto_load_message:
        initial_message += '\n' + budget_csv_auto_load_message
    result_var = tk.StringVar(value=initial_message)
    ttk.Label(content, textvariable=result_var, wraplength=1060, justify='left').pack(fill='x', padx=12, pady=(2,6))
    _bind_canvas_mousewheel(content)

    buttons = ttk.Frame(top)
    buttons.grid(row=1, column=0, sticky='ew', padx=10, pady=10)
    buttons.columnconfigure(0, weight=1)

    def close_window():
        global bulk_input_window
        bulk_input_window = None
        top.destroy()

    def run_load():
        try:
            selected_tree = tree_selector.path
            selected_measure = list(measure_selector.paths)
            selected_budget = budget_selector.path
            reused = []

            tree_result = None
            measure_result = None
            budget_result = None
            final_nodes = copy.deepcopy(flat_nodes)
            final_measure_options = set(measure_name_options)
            final_measure_master = dict(measure_master)
            final_budget_master = dict(budget_unit_master)

            current_tree_path = current_input_files.get("tree")
            current_measure_paths = list(current_input_files.get("measure") or [])
            current_budget_path = current_input_files.get("budget")

            if selected_tree and not same_file_path(selected_tree, current_tree_path):
                tree_result, error = load_tree_csv_from_path(selected_tree)
                if error:
                    tree_selector.set_error(error)
                    messagebox.showerror('構成CSV読込エラー', error)
                    return
                tree_selector.set_result(CsvFileStatus(selected_tree, '正常', '正常', tree_result.row_count))
                final_nodes = tree_result.nodes
                final_measure_options = tree_result.measure_name_options
            elif current_tree_path:
                selected_tree = current_tree_path
                reused.append('構成CSV')
            else:
                messagebox.showerror('構成CSV読込エラー', '構成CSVが未指定です。')
                tree_selector.set_error('未指定')
                return

            if selected_measure and not same_file_path_list(selected_measure, current_measure_paths):
                measure_result, error = read_measure_master_csv_files(selected_measure)
                if error:
                    measure_selector.status_var.set('エラー')
                    messagebox.showerror('実測値・按分比率CSV読込エラー', error)
                    return
                measure_selector.set_results(measure_result.file_statuses)
                final_measure_master = measure_result.master
            elif current_measure_paths:
                selected_measure = current_measure_paths
                reused.append('実測値・按分比率CSV')
            else:
                messagebox.showerror('実測値・按分比率CSV読込エラー', '実測値・按分比率CSVが未指定です。')
                measure_selector.status_var.set('エラー')
                return

            if budget_selector.was_cleared:
                selected_budget = None
                final_budget_master = {}
            elif selected_budget and not same_file_path(selected_budget, current_budget_path):
                budget_result, error = load_budget_unit_master_from_paths([selected_budget])
                if error:
                    budget_selector.set_error(error)
                    messagebox.showerror('予算単位CSV読込エラー', error)
                    return
                budget_selector.set_result(CsvFileStatus(selected_budget, '正常', '正常', budget_result.total_rows))
                final_budget_master = budget_result.master
            elif current_budget_path:
                selected_budget = current_budget_path
                reused.append('予算単位CSV')
            else:
                messagebox.showerror('予算単位CSV読込エラー', '予算単位CSVが未指定です。')
                budget_selector.set_error('未指定')
                return

            state = _snapshot_tree_state()
            flat_nodes.clear(); flat_nodes.extend(final_nodes)
            measure_name_options.clear(); measure_name_options.update(final_measure_options)
            measure_master.clear(); measure_master.update(final_measure_master)
            budget_unit_master.clear(); budget_unit_master.update(final_budget_master)
            current_input_files["tree"] = selected_tree
            current_input_files["measure"] = list(selected_measure)
            current_input_files["budget"] = selected_budget
            set_sample_mode(False)
            if budget_selector.was_cleared:
                config_input_file_candidates["budget"] = None
            invalidate_all_runtime_caches()
            redraw_preserving_state(state)
            save_config()

            tree_rows = tree_result.row_count if tree_result else len(flat_nodes)
            measure_unique = measure_result.unique_count if measure_result else len(measure_master)
            budget_unique = budget_result.unique_count if budget_result else len(budget_unit_master)
            notice_count = count_management_notice_rows()
            result_var.set(build_bulk_success_summary(tree_rows, measure_unique, budget_unique, notice_count))
            message = build_bulk_success_message(
                selected_tree, tree_rows, selected_measure, measure_unique,
                selected_budget, budget_unique, reused, notice_count=notice_count
            )
            critical_errors = find_critical_calc_structure_errors()
            if critical_errors:
                messagebox.showwarning(
                    '入力データの読み込み',
                    format_critical_calc_structure_error_load_warning(critical_errors)
                )
            messagebox.showinfo('入力データの読み込み', message)
        except Exception as e:
            messagebox.showerror('入力データ読込エラー', str(e))

    ttk.Button(buttons, text='キャンセル', command=close_window).pack(side='right')
    ttk.Button(buttons, text='読み込み・計算', command=run_load).pack(side='right', padx=(0,8))
    top.bind('<Escape>', lambda _e: close_window())
    top.protocol('WM_DELETE_WINDOW', close_window)

# ---- コントロール群 ----

def build_analysis_summary_data(target_month=None, company_name='', site_name='', analysis_datetime=None, snapshot=None):
    from anbun_reporting import build_summary_data
    return build_summary_data(sys.modules[__name__], target_month, company_name, site_name, analysis_datetime, snapshot=snapshot)

def show_analysis_summary_window():
    from anbun_report_ui import show_summary_window
    return show_summary_window(sys.modules[__name__])

def ask_integrated_export_options():
    from anbun_report_ui import ask_integrated_options
    return ask_integrated_options(sys.modules[__name__])

def build_integrated_analysis_data(options, output_datetime=None):
    from anbun_reporting import build_integrated_data
    return build_integrated_data(sys.modules[__name__], options, output_datetime)

def export_integrated_analysis_excel():
    from anbun_report_ui import export_integrated_excel
    return export_integrated_excel(sys.modules[__name__])

def _make_toolbar_row(label_text:str, parent=None)->ttk.Frame:
    if parent is None:
        parent = toolbar_frame
    row=ttk.Frame(parent)
    row.pack(fill='x', pady=(0,3))
    ttk.Label(row, text=label_text, width=8, anchor='w').pack(side='left', padx=(0,8))
    return row

def _toolbar_gap(row:ttk.Frame, width:int=12):
    ttk.Frame(row, width=width).pack(side='left')

def _add_flow_arrow(row:ttk.Frame):
    ttk.Label(row, text='→').pack(side='left', padx=(6,0))

show_advanced_toolbar = False
advanced_toolbar_frame = ttk.Frame(toolbar_frame)
row_jump_var = tk.StringVar()
tree_search_var = tk.StringVar()

def toggle_advanced_toolbar():
    global show_advanced_toolbar
    show_advanced_toolbar = not show_advanced_toolbar
    if show_advanced_toolbar:
        advanced_toolbar_frame.pack(fill='x')
        advanced_toggle_button.configure(text='詳細操作を隠す')
    else:
        advanced_toolbar_frame.pack_forget()
        advanced_toggle_button.configure(text='詳細操作を表示')

def jump_to_entered_row(_event=None):
    total = len(flat_nodes)
    if total <= 0:
        messagebox.showwarning('行番号移動', '現在ノードがありません。')
        return 'break'
    text = row_jump_var.get().strip()
    try:
        row_no = int(text)
    except (TypeError, ValueError):
        messagebox.showwarning('行番号移動', f'1～{total}の行番号を入力してください。')
        return 'break'
    if row_no < 1 or row_no > total:
        messagebox.showwarning('行番号移動', f'1～{total}の行番号を入力してください。')
        return 'break'
    jump_to_row_number(row_no)
    return 'break'

def search_tree_nodes(direction:int=1):
    query = tree_search_var.get().strip()
    if not query:
        messagebox.showwarning('検索', '検索文字列を入力してください。')
        return 'break'
    total = len(flat_nodes)
    if total <= 0:
        messagebox.showwarning('検索', '現在ノードがありません。')
        return 'break'
    focus_index = get_index_for_iid(tree.focus())
    selected_indices = get_selected_indices()
    current = focus_index if focus_index is not None else (selected_indices[0] if selected_indices else None)
    if direction < 0:
        start = total - 1 if current is None else current - 1
    else:
        start = 0 if current is None else current + 1
    needle = query.casefold()
    for offset in range(total):
        index = (start + direction * offset) % total
        node = flat_nodes[index]
        name = (node.name or '').casefold()
        measure_name = (node.measure_name or '').casefold()
        if needle in name or needle in measure_name:
            jump_to_node_index(index)
            return 'break'
    messagebox.showwarning('検索', '一致するノードがありません。')
    return 'break'

def show_management_settings_window():
    top = tk.Toplevel(root)
    top.title('管理しきい値設定')
    top.geometry('760x700')
    top.transient(root)

    outer = ttk.Frame(top, padding=12)
    outer.pack(fill='both', expand=True)
    ttk.Label(
        outer,
        text='管理フラグの判定しきい値と推定指標の表示しきい値を変更します。保存するとJSONへ反映し、現在のツリーを再判定します。',
        wraplength=720,
    ).pack(anchor='w', pady=(0, 10))

    form = ttk.LabelFrame(outer, text='しきい値')
    form.pack(fill='x')
    entries: Dict[str, tk.StringVar] = {}
    ordered_keys = [
        'measurement_candidate_threshold_kwh',
        'measurement_group_threshold_kwh',
        'estimation_accumulation_candidate_threshold',
        'estimation_accumulation_reference_kwh',
        'measurement_boundary_threshold_kwh',
        'over_power_threshold_percent_of_max',
        'parent_child_difference_threshold_kwh',
        'negative_anbun_threshold_kwh',
    ]
    for row, key in enumerate(ordered_keys):
        ttk.Label(form, text=MGMT_CFG_LABELS.get(key, key), anchor='w').grid(row=row, column=0, sticky='w', padx=8, pady=5)
        var = tk.StringVar(value=f"{float(MGMT_CFG.get(key, MGMT_CFG_DEFAULTS[key])):g}")
        entries[key] = var
        entry = ttk.Entry(form, textvariable=var, width=16, justify='right')
        entry.grid(row=row, column=1, sticky='w', padx=8, pady=5)
    form.columnconfigure(2, weight=1)

    count_var = tk.StringVar()
    count_frame = ttk.LabelFrame(outer, text='現在の該当件数')
    count_frame.pack(fill='x', pady=(12, 0))
    ttk.Label(count_frame, textvariable=count_var, justify='left').pack(anchor='w', padx=8, pady=8)

    def refresh_counts():
        invalidate_management_cache()
        counts = count_management_flags()
        maximum = counts['terminal_theoretical_max_kwh']
        maximum_text = f'{maximum:,.1f} kWh' if maximum is not None else '対象なし / 算出不能'
        count_var.set(
            f"個別推定量 該当：{counts['measurement_individual']:,}件\n"
            f"下流未確定量 該当：{counts['group_uncertainty_nodes']:,}件\n"
            f"経路推定累積度 該当：{counts['measurement_accumulation']:,}件\n"
            f"計測推奨境界：{counts['measurement_recommended_boundary_count']:,}点\n"
            f"診断対象 推定幅の最大：{maximum_text}\n"
            f"過大電力：{counts['over_power']:,}件\n"
            f"親子差大：{counts['parent_child_difference']:,}件"
        )

    def parse_entries() -> Optional[Dict[str, float]]:
        values: Dict[str, float] = {}
        for key, var in entries.items():
            text = var.get().strip()
            try:
                value = float(text)
            except (TypeError, ValueError):
                messagebox.showwarning('管理しきい値設定', f'{MGMT_CFG_LABELS.get(key, key)}には数値を入力してください。')
                return None
            if not math.isfinite(value):
                messagebox.showwarning('管理しきい値設定', f'{MGMT_CFG_LABELS.get(key, key)}には有限の数値を入力してください。')
                return None
            if key == 'estimation_accumulation_reference_kwh' and value <= 0:
                messagebox.showwarning('管理しきい値設定', f'{MGMT_CFG_LABELS.get(key, key)}には0より大きい数値を入力してください。')
                return None
            if key != 'negative_anbun_threshold_kwh' and value < 0:
                messagebox.showwarning('管理しきい値設定', f'{MGMT_CFG_LABELS.get(key, key)}には0以上の数値を入力してください。')
                return None
            values[key] = value
        return values

    def apply_values(values: Dict[str, float], close_after: bool = False):
        MGMT_CFG.update(values)
        invalidate_management_cache()
        redraw_preserving_state()
        save_config()
        refresh_counts()
        if close_after:
            top.destroy()

    def save_and_rejudge():
        values = parse_entries()
        if values is None:
            return
        apply_values(values)
        messagebox.showinfo('管理しきい値設定', '設定を保存し、管理フラグを再判定しました。')

    def reset_defaults():
        if not messagebox.askyesno('初期値に戻す', '管理しきい値をアプリ既定値へ戻しますか？'):
            return
        for key in ordered_keys:
            entries[key].set(f"{float(MGMT_CFG_DEFAULTS[key]):g}")
        apply_values({key: float(MGMT_CFG_DEFAULTS[key]) for key in ordered_keys})

    refresh_counts()

    buttons = ttk.Frame(outer)
    buttons.pack(fill='x', pady=(12, 0))
    ttk.Button(buttons, text='初期値に戻す', command=reset_defaults).pack(side='left')
    ttk.Button(buttons, text='閉じる', command=top.destroy).pack(side='right')
    ttk.Button(buttons, text='保存して再判定', command=save_and_rejudge).pack(side='right', padx=(0, 8))
    ttk.Button(buttons, text='件数更新', command=refresh_counts).pack(side='right', padx=(0, 8))
    top.bind('<Escape>', lambda _e: top.destroy())

def layout_flow_buttons(frame, widgets, available=None, right_widget=None, wide_gap_widget=None):
    """操作順を保って折り返す。右側ステータスもボタンと重ねない。"""
    available = max(available if available is not None else frame.winfo_width(), 1)
    x = y = row_height = 0
    for widget in widgets:
        width, height = widget.winfo_reqwidth(), widget.winfo_reqheight()
        gap = 28 if widget is wide_gap_widget and x else 0
        if x and x + gap + width > available:
            y += row_height + 6
            x = row_height = 0
            gap = 0
        widget.place(x=x + gap, y=y + 3)
        x += gap + width + 6
        row_height = max(row_height, height)
    if right_widget is not None:
        if str(right_widget.cget('text')):
            width, height = right_widget.winfo_reqwidth(), right_widget.winfo_reqheight()
            if x and x + width > available:
                y += row_height + 6
                row_height = 0
            right_widget.place(x=max(0, available - width), y=y + 3)
            row_height = max(row_height, height)
        else:
            right_widget.place_forget()
    height = y + row_height + 6
    frame.configure(height=height)
    return height


basic_row = ttk.Frame(toolbar_frame)
basic_row.pack(fill='x', pady=2)
basic_buttons = []
basic_flow_widgets = []
for label, command in (
    ('入力データをまとめて読み込む', show_bulk_input_window),
    ('構造検証', show_structure_validation_window),
    ('要確認行を見る', show_management_rows_window),
    ('管理しきい値設定', show_management_settings_window),
    ('分析CSV出力', export_to_csv),
    ('統合解析Excel出力', export_integrated_analysis_excel),
    ('解析結果サマリー', show_analysis_summary_window),
    ('詳細操作を表示', toggle_advanced_toolbar),
):
    if label in ('構造検証', '分析CSV出力'):
        basic_flow_widgets.append(ttk.Label(basic_row, text='→'))
    button = ttk.Button(basic_row, text=label, command=command)
    basic_buttons.append(button)
    basic_flow_widgets.append(button)
advanced_toggle_button = basic_buttons[-1]
sample_status_label = ttk.Label(basic_row, textvariable=sample_status_var, foreground='#8a5a00')

def layout_basic_toolbar(_event=None):
    layout_flow_buttons(basic_row, basic_flow_widgets, right_widget=sample_status_label,
                        wide_gap_widget=advanced_toggle_button)

basic_row.bind('<Configure>', layout_basic_toolbar)
sample_status_layout_job = None

def schedule_basic_toolbar_layout(*_args):
    # StringVarの変更がラベルへ反映され、要求幅が更新された後に配置する。
    global sample_status_layout_job
    if sample_status_layout_job is not None:
        root.after_cancel(sample_status_layout_job)
    def apply():
        global sample_status_layout_job
        sample_status_layout_job = None
        layout_basic_toolbar()
    sample_status_layout_job = root.after_idle(apply)

def cancel_basic_toolbar_layout(event):
    global sample_status_layout_job
    if event.widget is root and sample_status_layout_job is not None:
        root.after_cancel(sample_status_layout_job)
        sample_status_layout_job = None

sample_status_var.trace_add('write', schedule_basic_toolbar_layout)
root.bind('<Destroy>', cancel_basic_toolbar_layout, add='+')
layout_basic_toolbar()

# Windows標準のメニューを使用し、従来のコールバックへ直接接続する。
menubar = tk.Menu(root, tearoff=False)
operation_menus = {}
for heading, specs in (
    ('出力', (
        ('単独ツリーExcel出力', export_to_excel),
        ('上位接続Excel出力', export_upper_connection_excel),
        ('Sankey図CSV出力', export_sankey_csv))),
    ('読込', (
        ('構成CSVを読み込む', load_from_csv),
        ('実測値・比率を読み込む', load_measure_master_csv),
        ('予算単位CSVを読み込む', load_budget_unit_master_csv))),
    ('説明', (
        ('使い方・設計思想', show_help_usage),
        ('AI解析用仕様', show_ai_analysis_spec),
        ('開発・質問', show_developer_contact))),
):
    menu = tk.Menu(menubar, tearoff=False)
    for label, command in specs:
        menu.add_command(label=label, command=command)
    menubar.add_cascade(label=heading, menu=menu)
    operation_menus[heading] = menu
root.configure(menu=menubar)

view_row=_make_toolbar_row('表示：', advanced_toolbar_frame)
ttk.Button(view_row, text='全展開', width=8, command=lambda: expand_all_depths()).pack(side='left', padx=(0,12))
ttk.Label(view_row, text='階層表示: ').pack(side='left', padx=(0,2))
depth_buttons: Dict[int, tk.Button] = {}
for d in range(1, MAX_DEPTH+1):
    btn = tk.Button(view_row, text=str(d), width=3, bg=_depth_color(d), activebackground=_depth_color(d), command=lambda dd=d: toggle_depth_view(dd))
    btn.pack(side='left', padx=2)
    depth_buttons[d] = btn
_toolbar_gap(view_row, 18)
ttk.Button(view_row, text='属性列 表示/非表示', command=lambda: toggle_attribute_columns()).pack(side='left')
ttk.Button(view_row, text='管理列 表示/非表示', command=lambda: toggle_management_columns()).pack(side='left', padx=(6,0))
ttk.Button(view_row, text='推定指標列 表示/非表示', command=lambda: toggle_estimation_indicator_columns()).pack(side='left', padx=(6,0))
ttk.Button(view_row, text='参考列 表示/非表示', command=lambda: toggle_reference_columns()).pack(side='left', padx=(6,0))
ttk.Button(view_row, text='再描画', command=lambda: (lambda s=_snapshot_tree_state(): (draw_tree(), _restore_tree_state(s)))()).pack(side='left', padx=(6,0))

def toggle_depth_view(d:int):
    depth_open_state[d]=not depth_open_state.get(d,True)
    for i,nid in node_ids.items():
        if flat_nodes[i].depth==d: tree.item(nid, open=depth_open_state[d])

def expand_all_depths():
    for d in range(MAX_DEPTH+1): depth_open_state[d]=True
    for i,nid in node_ids.items(): tree.item(nid, open=True)

def toggle_attribute_columns():
    global show_attribute_columns
    show_attribute_columns = not show_attribute_columns
    apply_display_columns()

def toggle_estimation_indicator_columns():
    global show_estimation_indicator_columns
    show_estimation_indicator_columns = not show_estimation_indicator_columns
    apply_display_columns()

def toggle_management_columns():
    global show_management_columns
    show_management_columns = not show_management_columns
    apply_display_columns()

def toggle_reference_columns():
    global show_reference_columns
    show_reference_columns = not show_reference_columns
    apply_display_columns()

edit_row=_make_toolbar_row('編集：', advanced_toolbar_frame)
ttk.Button(edit_row, text='＋ ノード追加', command=add_node).pack(side='left')
ttk.Button(edit_row, text='－ ノード削除', command=delete_node).pack(side='left')
_toolbar_gap(edit_row)
ttk.Button(edit_row, text='← 階層減', command=lambda: change_depth(False)).pack(side='left')
ttk.Button(edit_row, text='→ 階層増', command=lambda: change_depth(True)).pack(side='left')
_toolbar_gap(edit_row)
ttk.Button(edit_row, text='↑ 上へ', command=lambda: move_node(True)).pack(side='left')
ttk.Button(edit_row, text='↓ 下へ', command=lambda: move_node(False)).pack(side='left')
_toolbar_gap(edit_row)
ttk.Button(edit_row, text='元に戻す', command=undo).pack(side='left')
ttk.Button(edit_row, text='やり直し', command=redo).pack(side='left')
ttk.Label(edit_row, text='｜').pack(side='left', padx=(14,10))
ttk.Label(edit_row, text='行番号').pack(side='left', padx=(0,2))
row_jump_entry = ttk.Entry(edit_row, textvariable=row_jump_var, width=7)
row_jump_entry.pack(side='left')
row_jump_entry.bind('<Return>', jump_to_entered_row)
ttk.Button(edit_row, text='移動', command=jump_to_entered_row).pack(side='left', padx=(3,0))
_toolbar_gap(edit_row, 10)
ttk.Label(edit_row, text='検索').pack(side='left', padx=(0,2))
tree_search_entry = ttk.Entry(edit_row, textvariable=tree_search_var, width=20)
tree_search_entry.pack(side='left')
tree_search_entry.bind('<Return>', lambda e: search_tree_nodes(1))
tree_search_entry.bind('<Shift-Return>', lambda e: search_tree_nodes(-1))
SimpleTooltip(tree_search_entry, 'ノード名・計量名称を部分一致で検索します。Enterで次へ、Shift+Enterで前方向へ移動します。')
ttk.Button(edit_row, text='次へ', command=lambda: search_tree_nodes(1)).pack(side='left', padx=(3,0))



for flow_row in (view_row, edit_row):
    flow_widgets = flow_row.winfo_children()
    for widget in flow_widgets:
        widget.pack_forget()
    flow_row.bind('<Configure>', lambda _event, frame=flow_row, widgets=flow_widgets:
                  layout_flow_buttons(frame, widgets))
    layout_flow_buttons(flow_row, flow_widgets)

# ---- 起動/終了 ----

def on_close():
    save_config()
    root.destroy()

load_config()
if not is_sample_mode:
    auto_load_budget_unit_master_csv_from_config()
root.geometry('1600x900')
draw_tree()
_snapshot_widths()
root.protocol('WM_DELETE_WINDOW', on_close)

if __name__ == '__main__':
    root.mainloop()
